<?php
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
#
#  Config for remote server, dev location
#
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 


error_reporting(E_ALL ^ E_NOTICE);

global $config;

$config['env'] = 'dev';

$config['db_host'] = 'localhost';
$config['db_user'] = 'blockdev';
$config['db_pass'] = 'ImgSRC0977';
$config['db_database'] = 'James';



/* developer IP */
#$config['dev_ip'] = '46.101.167.244';  // VPN
$config['dev_ip'] = '185.159.163.212';  // ISP


$config['uploads']['root_dir'] = '/var/www/html/dev/files/';
$config['uploads']['url'] = 'http://35.224.164.208/dev/files/';

