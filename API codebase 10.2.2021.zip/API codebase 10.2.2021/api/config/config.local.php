<?php
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
#
#  Config for my local server
#
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 


error_reporting(E_ALL ^ E_NOTICE);


global $config;

$config['env'] = 'local';

$config['db_host'] = 'localhost';
$config['db_user'] = 'root';
$config['db_pass'] = '';
$config['db_database'] = 'james';



/* developer IP */
$config['dev_ip'] = '127.0.0.1';




$config['uploads']['root_dir'] = 'D:/disk-h/james/api/files/';
$config['uploads']['url'] = 'http://james/api/files/';




