<?php

date_default_timezone_set('UTC');


define('EVENT_TYPE_RUN', 2);   // Run=2  (doesn't match event_types table!!)
define('EVENT_TYPE_GAME', 1);  // Game=1  (doesn't match event_types table!!)


global $config;

$config = [];

$config['google_api_key'] = 'AIzaSyDWT8jYR4J5oUXqLYoFznHLPi-oB5aWLEI';

$config['stripe_api_key_publishable'] = 'pk_test_51InPZ0CGjKmUtmBDtE8d5yIxxYTL1Yra9FKa9lc5D3QYFGFZZELQ3iLYiRfEqOpb2hwVgi8JVrYikXibra4CiJyh00lnZLm9Eb';
$config['stripe_api_key_secret'] = 'sk_test_51InPZ0CGjKmUtmBDGd8auAiuhJzsWoq2jWRPSxRYHhbGitq6YfacM7GMkD9upefdAz2IeKninlgGt0mbUvRuIQPb00jxunFHSh';
$config['stripe_webhook_secret'] = 'whsec_mhpe3QBq4Kecv2nSvOyLopYmWcP4TrHk';






$config['tests'] = [];
$config['tests']['base_uri'] = 'http://james/api/';
#$config['tests']['base_uri'] = 'http://35.224.164.208/dev/';
#$config['tests']['base_uri'] = 'http://35.224.164.208/api/';


$config['uploads'] = [];

$config['uploads']['types'] = 
[
    'teamScoreBook' => [],
];



if (!isset($_SERVER['SERVER_NAME']) || $_SERVER['SERVER_NAME'] == 'james')
{
    # local server of if !isset($_SERVER['SERVER_NAME']) that means testing from command line

    require_once(__DIR__ . '/config.local.php');
}
else
{
    # remote server

    if (preg_match('/^\/api\//i',$_SERVER['REQUEST_URI']) || preg_match('/^\/staging\//i',$_SERVER['REQUEST_URI']))
    {
        # prod location

        require_once(__DIR__ . '/config.prod.php');
    }
    else
    {
        # dev location

        require_once(__DIR__ . '/config.dev.php');
    }
}

/* DB tables */
define('DB_PREFIX',''); //james_

define('DB_TABLE_MEMBER_TYPES', DB_PREFIX. 'member_type');

define('DB_TABLE_USERS',        DB_PREFIX. 'users');
define('DB_TABLE_USER_ACCOUNT', DB_PREFIX. 'user_account');
define('DB_TABLE_USER_DETAIL',  DB_PREFIX. 'user_detail');
define('DB_TABLE_USER_SKILLS',  DB_PREFIX. 'user_skills');

define('DB_TABLE_RUNS',         DB_PREFIX. 'runs');
define('DB_TABLE_RUN_GAME',     DB_PREFIX. 'run_game');
define('DB_TABLE_RUN_USER',     DB_PREFIX. 'run_user');

define('DB_TABLE_SKILLS',       DB_PREFIX. 'skills');


/* default user level when adding user */
define('DEFAULT_USER_LEVEL', 3);

/* baller skill ID from ballers table */
define('BALLER_SKILL_ID', 5);




/* skill ID from skills table */
define('SKILL_RUN_ORGANIZING', 3);
define('SKILL_GAME_ORGANIZING', 38);






