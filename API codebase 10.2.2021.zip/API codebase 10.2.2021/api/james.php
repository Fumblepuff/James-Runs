<?php
require_once(__DIR__ . '/vendor/autoload.php');


/*
//header("Access-Control-Allow-Credentials: false");
//header("Access-Control-Allow-Credentials: true");

header("Access-Control-Allow-Headers: Date,Server,X-Powered-By,Content-Length,Keep-Alive,Connection,Content-Type");
header("Access-Control-Allow-Methods: GET, HEAD, POST, PUT, DELETE, CONNECT, OPTIONS, TRACE, PATCH");

//header("Access-Control-Allow-Origin: *");
//header("Access-Control-Allow-Origin: http://james");
//header("Access-Control-Allow-Origin: https://james-1891.stoplight.io/");
//header("Access-Control-Allow-Origin: https://stoplight.io/");
//header("Access-Control-Allow-Origin: https://js.stoplight.io/");

    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
    }

header("Access-Control-Expose-Headers: Date, Server, X-Powered-By, Content-Length, Keep-Alive, Connection, Content-Type");
*/

/*
function cors() {
    
    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }
    
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
        
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    
        exit(0);
    }
    
    echo "You have CORS!";
}

//header("Access-Control-Allow-Origin: *");
//header('Access-Control-Allow-Origin: *');
//"Access-Control-Allow-Origin": "https://www.example.com",

cors();

echo 'qwerty';

exit;
*/

use App\Models\Court;


define('IS_API', true);


apiLogRequest();

global $config;

if (strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0) {
    returnResponseAsString('Request method must be POST!', 400);
    exit;
}


$debug = (($_SERVER['REMOTE_ADDR'] == $config['dev_ip']) || ($config['env'] != 'prod')) ? true : false;
ini_set('display_errors', $debug);


$content = trim(file_get_contents("php://input")); 
$apiRequest = json_decode($content, true);

if (!is_array($apiRequest) || empty($apiRequest))
{
    returnResponseAsString('Received content contained invalid JSON!', 400);
    exit;
}


$apiRequestData = isset($apiRequest['data']) ? $apiRequest['data'] : [];

$apiRequestType = isset($apiRequest['type']) ? $apiRequest['type'] : '';

if (!$apiRequestType)
{
    _e('Type missing.');
}




$db = my_app('db');


switch ($apiRequestType) {

    case 'stripeGetPublicKey':
    case 'paymentIntent':


    case 'addNewCourt':
    case 'searchCourts':

    case 'addNewTeam':
    case 'searchTeams':

    case 'addNewEventRequest':
    case 'referPotentialStaffer':
    case 'getGameRequestForm1Data':
    case 'getGameRequestForm2Data':
    case 'getGameRequestForm3Data':
    case 'setGameRequestForm1Data':
    case 'setGameRequestForm2Data':
    case 'setGameRequestForm3Data':
    case 'referPotentialStaffer':

        $className = '\App\Actions\\' . requestTypeToActionClassName($apiRequestType);

        $obj = new $className($apiRequest);
        $obj->apiExecuteCommand();
        break;


    case 'editRunGame':
    case 'deleteRunGame':
    case 'addNewRun':
    case 'getUpcomingRuns':
    case 'getRunDetail':            
    case 'getUpcomingCourtRuns':
    case 'getUser':
    case 'getLeaderboard':
    case 'reserveSpot':
    case 'removeSpot':
    case 'registerUser':
    case 'updateUser':
    case 'getAllUpcomingRuns':
    case 'updateUserPermissions':
    case 'listUserPermissions':
    case 'ballerCheckin':
    case 'newRun':

        require_once(__DIR__ . '/src/Blocks/' . $apiRequestType . '.php');
        break;


    case 'checkUser':  // _refactor_ to getUserByEmail  should return not just id, but more fields

        $check = $db->selectQuery('select id from users where email = "'. $apiRequestData['email'].'"');

        returnResponseAsJson($check);

        break;



    case 'searchBallers':

        $search = $apiRequestData['search'];
        $limit = $apiRequestData['page'];

        if(!$limit){
            $limit = 0;
        }

        $ballers = $db->selectQuery('select * from users where firstName like "%'.$search.'%" or lastName like "%'.$search.'%" or email like "%'.$search.'%" order by firstName asc limit '.$limit.',10');            

        returnResponseAsJson($ballers);

        break;


    case 'getRuns':

        $type = $apiRequestData['type'];

        if (!$type)
        {
            $type = 1;
        }

        $runs = $db->selectQuery(<<<SQL
SELECT 
courts.*, 
runs.id as runId, 
runs.runScheduleUtc as timeStamp, 
runs.runEnd 

FROM 
runs 

INNER JOIN 

courts on runs.courtId = courts.id 

WHERE 
runs.type = :type

ORDER BY 
runs.runScheduleUtc asc
SQL
, [[':type', $type]]);


        adjustRunScheduleForAListOfRuns($runs);

        returnResponseAsJson($runs);

        break;

    case 'getMyRuns':

        $user = $apiRequestData['user'];
        $type = $apiRequestData['type'];

        if (!$type)
        {
            $type = 1;
        }

///echo 'here:'. "$user#$type";


        $runs = $db->selectQuery(<<<SQL
SELECT 
courts.*, 
runs.id as runId, 
runs.runScheduleUtc as timeStamp, 
runs.runEnd 

FROM 
runs 

INNER JOIN courts on runs.courtId = courts.id 
INNER JOIN run_user on run_user.runId = runs.id 

WHERE 

runs.active = 1 
  AND 
run_user.reserve = 1 
  AND 
runs.type = '{$type}'
  AND 
run_user.userId = {$user}
  AND 
DATE(runs.runScheduleUtc) >= DATE(NOW()) 

ORDER BY 
runs.runScheduleUtc asc
SQL
);

// vicvk:  , [[':t', $type], [':u', $user]]);   this params binding mysteriously didn't return results while it should

//print_r($runs);

        adjustRunScheduleForAListOfRuns($runs);

        returnResponseAsJson($runs);

        break;


    case 'getPastCourtRuns':

        $court = $apiRequestData['court'];

        $runs = $db->selectQuery(<<<SQL
SELECT 
courts.*, 
runs.id as runId, 
runs.runScheduleUtc as timeStamp, 
runs.runEnd, 
runs.active, 
runs.type 

FROM 
runs 

INNER JOIN courts ON runs.courtId = courts.id 

WHERE 
runs.courtId = :court
  AND  
DATE(runs.runScheduleUtc) < DATE(NOW()) 

ORDER BY 
runs.runScheduleUtc asc

SQL
, [[':court', $court]]);


        adjustRunScheduleForAListOfRuns($runs);

        returnResponseAsJson($runs);

        break;


    case 'getPastRuns':

        $type = (int)$apiRequestData['type'];

        if (!$type)
        {
            $type = 1;
        }
      
       
        $runs = $db->selectQuery(<<<SQL
SELECT 
courts.*, 
runs.id as runId, 
runs.runScheduleUtc as timeStamp, 
runs.runEnd 

FROM 
runs 

INNER JOIN courts ON runs.courtId = courts.id 

WHERE 
(runs.type = :type)
  AND 
(runs.active = 1)
  AND 
((runs.runEnd = 1) OR (DATE(runs.runScheduleUtc) < DATE(NOW())))

ORDER BY 
runs.runScheduleUtc desc

SQL
, [[':type', $type]]);

        adjustRunScheduleForAListOfRuns($runs);

        returnResponseAsJson($runs);

        break;

    case 'getCourts':

        $page = $apiRequestData['page'];

        if (!$page)
        {
            $page = 0;
        }

        $courts = $db->selectQuery(<<<SQL
SELECT 
* 

FROM 
courts 

WHERE 
active = 1 
  AND 
name != "" 

ORDER BY 
name asc 

LIMIT :page, 10

SQL
, [[':page', $page, \PDO::PARAM_INT]]);

        returnResponseAsJson($courts);

        break;

    case 'getMemberTypes':
        $sql = 'SELECT `id` AS `memberTypeId`, `name`, `description` FROM `'.DB_TABLE_MEMBER_TYPES.'` WHERE `id` > 0 ORDER BY `id` ASC';

        returnResponseAsJson( $db->selectQuery($sql) );
        die();

        break;

    case 'getMemberSkills':  // refactor  should be: getMemberTypeSkills  or getSkills (with optional by memberType search)

        $memberTypeId = 0;

        if (!empty($apiRequestData['memberTypeId'])){
            $memberTypeId = (int)$apiRequestData['memberTypeId'];
        }

        //$sql = 'SELECT `id`, `longName`, `description`,`reserve`,`report` FROM `'.DB_TABLE_SKILLS.'`'; 
        $sql = 'SELECT * FROM `'.DB_TABLE_SKILLS.'`'; 
        if ($memberTypeId > 0){
            $sql .= 'AND `memberTypeId` = '.$memberTypeId.' ';
        }

        $sql .= 'ORDER BY longName ASC';

        returnResponseAsJson( $db->selectQuery($sql) );
        die();

        break;            

    case 'getCourt':

        $courtId = $apiRequestData['id'];

        if(!$limit){
            $limit = 0;
        }

        $court = $db->selectQuery('select * from courts where active = 1 and name != "" and id = '.$courtId);            

        returnResponseAsJson($court[0]);

        break;
    case 'getBallers':

        $limit = $apiRequestData['page'];

        if(!$limit){
            $limit = 0;
        }

        $ballers = $db->selectQuery('select * from users order by firstName asc limit '.$limit.',10');            

        returnResponseAsJson($ballers);

        break;

    case 'getSingleRunBaller':

        $run     = (int)$apiRequestData['run'];
        $id     = (int)$apiRequestData['user'];

        $ballers = $db->selectQuery(
            'SELECT `checkIn`,`reserve` 
            FROM  `'.DB_TABLE_USERS.'` 
            INNER JOIN `'.DB_TABLE_RUN_USER.'` 
            ON `'.DB_TABLE_USERS.'`.`id` = `'.DB_TABLE_RUN_USER.'`.`userId` 
            WHERE `runId` = '.$run.' AND  `userId` = '.$id.' AND `skillId` = '.BALLER_SKILL_ID);

        returnResponseAsJson($ballers[0]);

        break;

    case 'getRunBallers':

        $run = (int)$apiRequestData['run'];
        if ($run < 1){
            $run = (int)$apiRequestData['runId'];
        }

        if ($run < 1){
            _e('Invalid game');
        }

        $ballers = $db->selectQuery(
            'SELECT 
                `'.DB_TABLE_USERS.'`.`id`,`firstName`,`lastName`,`city`,`state`,`imageName`,
                `checkIn`,`checkInDate`,`reserve`,`bench`,`next`,`'.DB_TABLE_RUN_USER.'`.`active`
            FROM  `'.DB_TABLE_USERS.'` 
            INNER JOIN `'.DB_TABLE_RUN_USER.'` 
                ON `'.DB_TABLE_USERS.'`.`id` = `'.DB_TABLE_RUN_USER.'`.`userId` 
            WHERE `runId` = '.$run.' AND (`reserve` = 1 OR `checkIn` = 1) 
                 AND `skillId` = '.BALLER_SKILL_ID.' 
            ORDER BY `reserveDate`, `checkInDate` ASC
        ');

        returnResponseAsJson($ballers);

        break;

    case 'getNextBallers':

        $run = (int)$apiRequestData['run'];

        $sql = 'SELECT 
            `'.DB_TABLE_USERS.'`.`id`,`firstName`,`lastName`,`city`,`state`,`imageName`,
            `checkIn`,`checkInDate`,`reserve`,`bench`,`next`
        FROM  `'.DB_TABLE_USERS.'` 
        INNER JOIN `'.DB_TABLE_RUN_USER.'` 
            ON `'.DB_TABLE_USERS.'`.`id` = `'.DB_TABLE_RUN_USER.'`.`userId`             
        WHERE `runId` = '.$run.' AND `checkIn` = 1 
            AND `bench` = 0 
            AND `'.DB_TABLE_RUN_USER.'`.`active` = 0
            AND `skillId` = '.BALLER_SKILL_ID;

        $and = ' AND `next` = 1';

        $order = ' ORDER BY `lastGamePlayed`,`checkInDate` ASC LIMIT 5';

        $next = $db->selectQuery($sql.$and.$order);    

        if(!$next){
            $next = $db->selectQuery($sql.$order);
        }        

        returnResponseAsJson($next);

        break;

    case 'disableRun':

        $run = $apiRequestData['run'];
        $active = $apiRequestData['active'];

        $db->updateValue('runs', 'active', $active, $run);            

        break;

    case 'setLastGamePlayed':

        $run = $apiRequestData['run'];
        $game = $apiRequestData['game'];
        
        $players = $db->selectQuery('select * from user_team where gameId = '.$game);
        
        foreach($players as $player){
            $db->selectQuery('update run_user set lastGamePlayed = NOW() where runId = "'.$run.'" and userId = '.$player['userId']);
        }

        break;


    case 'getBenchBallers':

        $run = $apiRequestData['run'];

        $bench = $db->selectQuery('select users.id,users.firstName,users.lastName,users.city,users.state,users.imageName,run_user.checkIn,run_user.checkInDate,run_user.reserve,run_user.bench,run_user.next from users inner join run_user on users.id = run_user.userId where run_user.runId = "'.$run.'" and run_user.bench = 1 order by run_user.lastGamePlayed, run_user.checkInDate asc');            

        returnResponseAsJson($bench);

        break;


    case 'startRun':

        $run = $apiRequestData['run'];

        // check that run exists

        $runData = lookupRunById($run);

        if (!is_array($runData))
        {
            _e("Run doesn't exist");
        }

        // check that run is not ended

        if ($runData['runEnd'] == 1)
        {
            _e("Run already ended");
        }

        $courtData = lookupCourtById($runData['courtId']);

        if (!is_array($courtData))
        {
            _e("Court with courtId={$runData['courtId']} which is associated with this run (runId={$runId}) is missing in database");
        }

        // check that runScheduleUtc is in the past
        if (strcmp($runData['runScheduleUtc'], getCurrentDateTimeUtc()) > 0) // $runData['runScheduleUtc'] must be less than current datetime in order to pass this check
        {
            $shouldStartAt = convertDateTimeToAnotherTimeZone($runData['runScheduleUtc'], 'UTC', $courtData['timezone']);

            _e("It is too early to start this run, the run is scheduled for: {$shouldStartAt} ({$courtData['timezone']})");
        }

        // only insert a new game if this run doesn't yet contain any games.

        $games = $db->selectQuery('select * from run_game where runId = :runId', [[':runId', $run]]);

        if (!isset($games[0]))
        {
            $game = [];

            $game['runId'] = $run;
            $db->insertValue('run_game', $game);

            $games = $db->selectQuery('select * from run_game where runId = :runId', [[':runId', $run]]);
        }

        returnResponseAsJson($games);

        break;


    case 'getRunGame':

        $run = $apiRequestData['run'];

        $games = $db->selectQuery('select * from run_game where runId = :runId', [[':runId', $run]]);

        returnResponseAsJson($games);

        break;

    case 'checkActiveRunGame':

        $run = $apiRequestData['run'];

        $game = $db->selectQuery('select active from run_game where runId = "'.$run.'" and active = 1 limit 1');            

        if($game[0]){

            returnResponseAsString(1);
        }else{

            returnResponseAsString(0);
        }

        break;
    case 'getUserStats':

        $user = $apiRequestData['user'];

        $stats = getUserStats($user);

        if($stats){

            returnResponseAsJson($stats);
        }
        break;


    case 'addUserTeam':

        $run  = (int)$apiRequestData['run'];
        $user = (int)$apiRequestData['user'];
        $game = $apiRequestData['game'];
        $team = $apiRequestData['team'];

        $insert['runId'] = $run;
        $insert['userId'] = $user;
        $insert['team'] = $team;
        $insert['gameId'] = $game;

        $check = $db->selectQuery('select id,userId from user_team where gameId = '.$game.' and userId = '.$user);

        $fix_record_id = 0;
        $fix_id = $db->selectQuery('SELECT id FROM `'.DB_TABLE_RUN_USER.'` WHERE userId='.$user.' AND runId='.$run);
        if (empty($fix_id)){

            /* auto adding record, if its missing; 
               addSquad should be used to assing users to teams, then fix_ code will be not needed;
               NOT using $db->insert_id, as durint execution more records can be inserted!
            */            
            $db->selectQuery('INSERT INTO `'.DB_TABLE_RUN_USER.'` (userId,runId) VALUES ('.$user.','.$run.')');
            $fix_id = $db->selectQuery('SELECT id FROM `'.DB_TABLE_RUN_USER.'` WHERE userId='.$user.' AND runId='.$run);
        } 

        $fix_record_id = $fix_id[0]['id'];    

        if($check){
            $removeBaller = $db->deleteValue('user_team', 'id', $check[0]['id']);                
            $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 0 WHERE `id` = '.(int)$fix_record_id);
        }

        if($team != "Clear"){
            $db->insertValue('user_team', $insert);            
            $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 1, `next` = 0, `bench` = 0 WHERE `id` = '.(int)$fix_record_id);                            
        }

        if($team == "Clear"){        
            $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 0, `next` = 0, `bench` = 1 WHERE `id` = '.(int)$fix_record_id);
        }

        $home = $db->selectQuery('select users.* from users inner join user_team on user_team.userId = users.id where user_team.gameId = '.$game.' and user_team.team = "Home"');
        $guest = $db->selectQuery('select users.* from users inner join user_team on user_team.userId = users.id where user_team.gameId = '.$game.' and user_team.team = "Guest"');

        $update['home'] = $home;
        $update['guest'] = $guest;


        returnResponseAsJson($update);
        break;

    case 'getUserTeam':

        $run = $apiRequestData['run'];
        $user = $apiRequestData['user'];
        $squad = $apiRequestData['squad'];
        $game = $apiRequestData['game'];

        $check = $db->selectQuery('select id,userId,team from user_team where gameId = '.$game.' and userId = '.$user);
        
        if($check){

            returnResponseAsJson($check[0]);
        }
        break;

    case 'getGameTeams':

        $run = $apiRequestData['run'];
        $game = $apiRequestData['game'];

        $home = $db->selectQuery('select users.* from users inner join user_team on user_team.userId = users.id where user_team.gameId = '.$game.' and user_team.team = "Home"');
        $guest = $db->selectQuery('select users.* from users inner join user_team on user_team.userId = users.id where user_team.gameId = '.$game.' and user_team.team = "Guest"');

        $status = $db->selectQuery('select * from run_game where id = '.$game);
        
        $update['home'] = $home;
        $update['guest'] = $guest;
        $update['game'] = $status[0];

        returnResponseAsJson($update);

        break;


    case 'showRunGame':

        $run = $apiRequestData['run'];
        $gameId = $apiRequestData['game'];

        $game = $db->selectQuery('select * from run_game where id = '.$gameId);
        $complete = $game[0]['complete'];

        if($complete != 1){
            $db->updateValue('run_game', 'active', 1, $gameId);
        }

        returnResponseAsJson($game[0]);

        break;
    case 'runPoint':

        $team = str_replace(" ", "", $apiRequestData['team']);
        $point = $apiRequestData['points'];
        $gameId = $apiRequestData['gameId'];

        $db->updateValue('run_game', $team, $point, $gameId);

        break;
    case 'endRun':

        $id = $apiRequestData['id'];
        
        $db->updateValue('runs', 'runEnd', 1, $id);
        $db->selectQuery('update run_user set checkIn = 0, reserve = 0, bench = 0, next = 0 where runId = '.$id.' AND skillId='.BALLER_SKILL_ID);
        
        break;


    case 'checkConfirm':

        $run = $apiRequestData['run'];
        $user = $apiRequestData['user'];
        
        $check = $db->selectQuery('select reserve from run_user where userId = '.$user.' and runId = '.$run);
        
        if($check){

            returnResponseAsString($check[0]['reserve']);
        }
        
        break;
    case 'checkWinner':

        $runId = $apiRequestData['run'];
        $gameId = $apiRequestData['game'];

        $run = $db->selectQuery('select Home, Guest from run_game where id = '.$gameId);

        $db->updateValue('run_game', 'complete', 1, $gameId);
        $db->updateValue('run_game', 'active', 0, $gameId);


        $teamA = $run[0]['Home'];
        $teamB = $run[0]['Guest'];

        if($teamA > $teamB){

            $winner["winner"] = "Home";
            $winner["Home"] = $teamA;
            $winner["Guest"] = $teamB;

            //update winners
            $winners = $db->selectQuery('select userId from user_team where gameId = '.$gameId.' and team = "Home"');
            foreach ($winners as $baller) {

                //check if the user stats are already being recorded
                $winnerCheck = [];
                $insertWinner = [];
                $winnerCheck = $db->selectQuery('select * from user_streak where userId = '.$baller["userId"]);
                
                if($winnerCheck){
                    
                    $id = $winnerCheck[0]['id'];
                    $wins = $winnerCheck[0]['wins'] + 1;
                    $streak = $winnerCheck[0]['streak'] + 1;

                    $db->updateValue('user_streak', 'wins', $wins, $id);
                    $db->updateValue('user_streak', 'streak', $streak, $id);

                    $rating = getUserStats($id);
                    $db->updateValue('user_streak', 'jamesRating', $rating['jamesRating'], $id);

                }else{
                    
                    $insertWinner['userId'] = $baller['userId'];
                    $insertWinner['wins'] = 1;
                    $insertWinner['streak'] = 1;
                    $rating = getUserStats($id);
                    $insertWinner['jamesRating'] = $rating['jamesRating'];

                    $db->insertValue('user_streak', $insertWinner);

                }

            }

            // update loosers
            $loosers = $db->selectQuery('select userId from user_team where gameId = '.$gameId.' and team = "Guest"');
            foreach ($loosers as $baller) {
                
                //check if the user stats are already being recorded
                $looserCheck = [];
                $insertLooser = [];
                $looserCheck = $db->selectQuery('select * from user_streak where userId = '.$baller["userId"]);
                if($looserCheck){
                    
                    $id = $looserCheck[0]['id'];
                    $losses = $looserCheck[0]['losses'] + 1;
                    $db->updateValue('user_streak', 'losses', $losses, $id);
                    $db->updateValue('user_streak', 'streak', 0, $id);

                    $rating = getUserStats($id);
                    $db->updateValue('user_streak', 'jamesRating', $rating['jamesRating'], $id);

                }else{

                    $insertLooser['userId'] = $baller['userId'];
                    $insertLooser['losses'] = 1;
                    $insertLooser['streak'] = 0;
                    $rating = getUserStats($id);
                    $insertWinner['jamesRating'] = $rating['jamesRating'];

                    $db->insertValue('user_streak', $insertLooser);

                }

            }

            returnResponseAsJson($winner);

        }else if($teamA == $teamB){

            $winner["winner"] = "Tie";
            $winner["Home"] = $teamA;
            $winner["Guest"] = $teamB;

            returnResponseAsJson($winner);

        }else{

            $winner["winner"] = "Guest";
            $winner["Home"] = $teamA;
            $winner["Guest"] = $teamB;

            //update winners
            $winners = $db->selectQuery('select userId from user_team where gameId = '.$gameId.' and team = "Guest"');
            foreach ($winners as $baller) {

                //check if the user stats are already being recorded
                $winnerCheck = [];
                $insertWinner = [];
                $winnerCheck = $db->selectQuery('select * from user_streak where userId = '.$baller["userId"]);
                
                if($winnerCheck){
                    
                    $id = $winnerCheck[0]['id'];
                    $wins = $winnerCheck[0]['wins'] + 1;
                    $streak = $winnerCheck[0]['streak'] + 1;

                    $db->updateValue('user_streak', 'wins', $wins, $id);
                    $db->updateValue('user_streak', 'streak', $streak, $id);

                    $rating = getUserStats($id);
                    $db->updateValue('user_streak', 'jamesRating', $rating['jamesRating'], $id);

                }else{

                    $insertWinner['userId'] = $baller['userId'];
                    $insertWinner['wins'] = 1;
                    $insertWinner['streak'] = 1;
                    $rating = getUserStats($id);
                    $insertWinner['jamesRating'] = $rating['jamesRating'];

                    $db->insertValue('user_streak', $insertWinner);

                }

            }

            // update loosers
            $insert = [];
            $check = [];
            $loosers = $db->selectQuery('select userId from user_team where gameId = '.$gameId.' and team = "Home"');
            foreach ($loosers as $baller) {
                
                //check if the user stats are already being recorded
                $looserCheck = [];
                $insertLooser = [];
                $looserCheck = $db->selectQuery('select * from user_streak where userId = '.$baller["userId"]);
                if($looserCheck){
                    
                    $id = $looserCheck[0]['id'];
                    $losses = $looserCheck[0]['losses'] + 1;
                    $db->updateValue('user_streak', 'losses', $losses, $id);
                    $db->updateValue('user_streak', 'streak', 0, $id);

                    $rating = getUserStats($id);
                    $db->updateValue('user_streak', 'jamesRating', $rating['jamesRating'], $id);

                }else{

                    $insertLooser['userId'] = $baller['userId'];
                    $insertLooser['losses'] = 1;
                    $insertLooser['streak'] = 0;
                    $rating = getUserStats($id);
                    $insertWinner['jamesRating'] = $rating['jamesRating'];

                    $db->insertValue('user_streak', $insertLooser);

                }

            }

            returnResponseAsJson($winner);

        }

        break;

   
    default:

        _e('Invalid type specified');
        break;

}  // switch ($apiRequestType)





