<?php
require_once(__DIR__ . '/vendor/autoload.php');

# From Dainius: 
# 
# logs square payment data. I did not log any calls to this url.
# 

use App\Square;   // <-- move to dependancy container

apiLogRequest();


//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    returnResponseAsString('Request method must be POST!', 400);
    exit;
}
 
//Make sure that the content type of the POST request has been set to application/json
// $contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
// print_r($contentType);
// if(strcasecmp($contentType, 'application/json') != 0){
//     throw new Exception('Content type must be: application/json');
// } 
 
//Receive the RAW post data.
$content = trim(file_get_contents("php://input"));
 
//Attempt to decode the incoming RAW post data from JSON.
$apiRequest = json_decode($content, true);

 
//If json_decode failed, the JSON is invalid.
if(!is_array($apiRequest)){
    returnResponseAsString('Received content contained invalid JSON!', 400);
    exit;
}

if($apiRequest['type']) {

    $type = $apiRequest['type'];
    $squarePayment = new Square();

    $db = my_app('db');

    switch ($type) {
        case 'getLocations':
            $squarePayment->locations();
            break;

        case 'newCustomer':
            $data = $apiRequest['data'];
            $user = $data['user'];

            $customerID = $squarePayment->newCustomer($user);

            returnResponseAsString($customerID);
            break;

        case 'addCustomerCard':
            $data = $apiRequest['data'];
            $customer = $data['customer'];
            $cardNonce = $data['cardNonce'];
            $user = $data['user'];

            $account = $squarePayment->newCard($customer, $cardNonce);

            $account['customerID'] = $customer;
            $account['userID'] = $user;

            $check = $db->selectQuery('select * from user_account where userID = '.$user);

            if($check[0]){
                $db->updateValue('user_account', 'customerCard', $account['customerCard'], $check[0]['id']);
                $db->updateValue('user_account', 'cardBrand', $account['cardBrand'], $check[0]['id']);
                $db->updateValue('user_account', 'last4', $account['last4'], $check[0]['id']);
            }else{
                $db->insertValue('user_account', $account);
            }

            returnResponseAsJson($account);
            
            break;

        case 'chargeCustomerCard':


            $data = $apiRequest['data'];
            $card = $data['card'];
            $run = $data['run'];
            $customer = $data['customer'];
            $user = $data['user'];
            $key = $data['key'];
            // $amount = $data['cost'];


            $amount = 500;
            
            $charge = $squarePayment->chargeCard($card, $amount, $run, $user, $customer, $key);
            
            $db->insertValue('user_transactions', $charge);

            returnResponseAsJson($charge);

            break;
        
        default:
            # code...
            break;
    }
}

