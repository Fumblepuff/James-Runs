<?php
namespace App\Actions;

use App\Models\Court;
use App\Models\Run;

class AddNewCourt extends BaseAction
{
    protected $skipLoggedInUserIdCheck = true;

    protected $court;
    protected $schedule;


    public function __construct(Array $params=[])
    {
        $this->court = extractParam($params['data'], 'court');
        $this->schedule = extractParam($params['data'], 'schedule', []);
    }


    protected function apiAccessControl()
    {

    }

    public function validateParams()
    {

/*

must be required:

latitude
longitude

*/

// NYI do not allow duplicate names, duplicate addresses

// NYI: some required values:
/*
Array
(
    [type] => addNewCourt
    [data] => Array
        (
            [court] => Array
                (
                    [adminId] => 2512
                    [name] => Asda Park Royal Superstore
                    [address] => 2-20 Western Road
                    [longitude] => -0.2696693
                    [latitude] => 51.5285728
                    [city] => London
                    [state] => England
                    [zipcode] => NW10 7LW
                    [imageType] => google
                    [imageName] => https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=ATtYBwLwXCrId9XfC-0mlJZNOpwhQrtedJEel-kk5x38oMniSEuEJoPbQeG805xAVrf9MC1RHThllT4yeJsz5L_GMR1ZRW_PMpyUz9DMUrja9w6pDbslzrsqkV2GGmrfgJCcyT6Xln0Di5fjVoLkvdiKQAI3zfSQAxF1Izj3RuxyLBPL9Muq&key=AIzaSyDWT8jYR4J5oUXqLYoFznHLPi-oB5aWLEI
                    [placeId] => ChIJb_iYL-4RdkgRfILoKI4ebYM
                    [active] => 1
                )

        )

)
*/

    }

    public function execute()
    {
//echo 'here';

        $court = new Court;

        $court->adminId = $this->court['adminId'];
        $court->name = $this->court['name'];
        $court->address = $this->court['address'];
        $court->longitude = $this->court['longitude'];
        $court->latitude = $this->court['latitude'];
        $court->city = $this->court['city'];
        $court->state = $this->court['state'];
        $court->zipcode = $this->court['zipcode'];
        $court->imageType = $this->court['imageType'];
        $court->imageName = $this->court['imageName'];
        $court->placeId = $this->court['placeId'];
        $court->active = $this->court['active'];

        $court->timezone = resolveGeoCoordinatesToTimeZone($this->court['latitude'], $this->court['longitude']);

        $court->save();

        $this->result['court'] = $court;
        $this->result['runs'] = [];


        if (isset($apiRequestData['schedule']) && is_array($apiRequestData['schedule']))
        {
            foreach ($apiRequestData['schedule'] as $run) 
            {
                $this->result['runs'][] = Run::createNewRun($court, $run['id']); // _refector_ $run['id'] should become $run['datetime']
            }
        }
    }


    protected function apiReturnResultAsResponse()
    {
        returnResponseAsJson($this->result['court']->id); // _refactor_ must return ['courtId'=>123,  'result' => 'success']
    }
    
}
