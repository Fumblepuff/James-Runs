<?php
namespace App\Actions;

use App\Models\Court;
use App\Models\EventRequest;
use App\Models\Skill;
use App\Models\User;
use DateTime;
use DateTimeZone;

class AddNewEventRequest extends BaseAction
{
    protected $eventTypeId;
    protected $courtId;
    protected $court;
    protected $eventDateTime;
    protected $eventDateTimeObj;

    public function __construct(Array $params=[])
    {
        $this->eventTypeId = extractParam($params, 'eventTypeId');
        $this->courtId = extractParam($params, 'courtId');
        $this->eventDateTime = extractParam($params, 'eventDateTime');
    }


    protected function apiAccessControl()
    {
        if ($this->eventTypeId == EVENT_TYPE_RUN)
        {
            if (!$this->apiLoggedInUser->hasSkill(Skill::find(SKILL_RUN_ORGANIZING)))
            {
                _e('You must have run organizing skill to submit this request', 403);
            }
        }
        elseif ($this->eventTypeId == EVENT_TYPE_GAME)
        {
            if (!$this->apiLoggedInUser->hasSkill(Skill::find(SKILL_GAME_ORGANIZING)))
            {
                _e('You must have game organizing skill to submit this request', 403);
            }
        }
    }


    protected function validateParams()
    {
        if (empty2($this->eventTypeId))
        {
            $this->addError('eventTypeId is required', 'eventTypeId', 422);
        }

        if (($this->eventTypeId == 1) || ($this->eventTypeId == 2))
        {
            // all ok
        }
        else
        {
            $this->addError('invalid value for eventTypeId. It can be either =1 for runs and =2 or games', 'eventTypeId', 422);
        }

        if (empty2($this->courtId))
        {
            $this->addError('Court is required', 'courtId', 422);
        }
        else
        {
            $this->court = Court::find($this->courtId);

            if (!$this->court)
            {
                $this->addError('courtId is not found in database', 'courtId', 422);
            }
        }


        if (preg_match('/^20\d\d\-\d\d\-\d\d \d\d\:\d\d\:\d\d$/', $this->eventDateTime))
        {
            $timezone = new DateTimeZone($this->court->timezone);

            $this->eventDateTimeObj = DateTime::createFromFormat ('Y-m-d H:i:s', $this->eventDateTime, $timezone);

            if ($this->eventDateTimeObj === false)
            {
                $this->addError('Invalid format for eventDateTime. Should be like: 2025-05-17 14:20:00', 'eventDateTime', 422);
            }
            else
            {
                // datetime 72 hours in future

                if (($this->eventDateTimeObj->getTimestamp() - time()) < 3600 * 24 * 3)
                {
                    $this->addError('eventDateTime should be at least 72 hours in future from now', 'eventDateTime', 422);
                }
            }
        }
        else
        {
            $this->addError('Invalid format for eventDateTime. Should be like: 2025-05-17 14:20:00', 'eventDateTime', 422);
        }





    }

    public function execute()
    {
//echo 'execute';
//$this->result = ['ok'];


// NYI - check proximity

        $e = new EventRequest;

        $e->ownerUserId = $this->apiLoggedInUser->id;
        $e->eventTypeId = $this->eventTypeId;
        $e->courtId = $this->courtId;


        $this->eventDateTimeObj->setTimezone(new DateTimeZone('UTC'));
        $dt = $this->eventDateTimeObj->format('Y-m-d H:i:s');

        $e->eventDateTime = setZeroSecondsOnDateTime($dt);

        $radiusMiles = 30;
        $staffersExist = User::staffersExistWithinMilesRadius(['latitude' => $this->court->latitude, 'longitude' => $this->court->longitude], $radiusMiles);

        if ($staffersExist)
        {
            $e->fulfillmentStatus = EventRequest::FULFILLMENT_STATUS_CREATING;
        }
        else
        {
            $e->fulfillmentStatus = EventRequest::FULFILLMENT_STATUS_NO_STAFFERS;
        }

        $e->save();


        $this->result['success'] = 'Success';
        $this->result['staffersExistInThisZone'] = $staffersExist ? 'Yes' : 'No';

        $this->result['eventRequest'] = [];
        $this->result['eventRequest']['id'] = $e->id;
        $this->result['eventRequest']['eventTypeId'] = $e->eventTypeId;
        $this->result['eventRequest']['courtId'] = $e->courtId;
        $this->result['eventRequest']['eventDateTime'] = $e->eventDateTime;
    }



    
}

