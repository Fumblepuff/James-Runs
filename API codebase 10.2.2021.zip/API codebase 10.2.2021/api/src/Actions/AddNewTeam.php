<?php
namespace App\Actions;

use App\Models\Team;
use App\Models\Skill;


class AddNewTeam extends BaseAction
{
    protected $name;
    protected $shortName;

    public function __construct(Array $params=[])
    {
        $this->name = extractParam($params, 'name');
        $this->shortName = extractParam($params, 'shortName');
    }


    protected function apiAccessControl()
    {
        if (!$this->apiLoggedInUser->hasSkill(Skill::find(SKILL_GAME_ORGANIZING)))
        {
            _e('You must have game organizing skill to submit this request', 403);
        }
    }


    protected function validateParams()
    {
        if (empty2($this->name))
        {
            $this->addError('Name is required', 'name', 422);
        }
        else
        {
            $existing = Team::byExactNameCaseInsensitive($this->name)->get();

            if (count($existing) > 0)
            {
                $this->addError('Team with this name already exists', 'name', 422);
            }
        }

        if (empty2($this->shortName))
        {
            $this->addError('Short name is required', 'name', 422);
        }
    }


    public function execute()
    {
        $e = new Team;

        $e->name = $this->name;
        $e->shortName = $this->shortName;

        $e->save();


        $this->result['success'] = 'Success';
        $this->result['team'] = $e->toArray();
    }



    
}

