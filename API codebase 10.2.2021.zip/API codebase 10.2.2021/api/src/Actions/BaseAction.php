<?php
namespace App\Actions;

use App\Models\User;
use App\DataValidationException;

abstract class BaseAction
{
    protected $apiLoggedInUser = null;

    protected $skipLoggedInUserIdCheck = false;


    protected $result = [];
    protected $validationErrors = [];


    // should extract all necessary input data from $params
    abstract public function __construct(Array $params=[]);


    abstract protected function validateParams();

    protected function addError($errorMsg, $paramName='', $httpStatus=400)
    {
        $this->validationErrors[] = ['errorMsg' => $errorMsg, 'paramName' => $paramName, 'httpStatus' => $httpStatus];
    }

    public function hasValidationErrors()
    {
        return (count($this->validationErrors) > 0);
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }

    public function getResult()
    {
        return $this->result;
    }

    abstract public function execute();



    protected function apiDetectLoggedInUser()
    {
        $loggedInUserId = apiRequest('loggedInUserId');


        if ($loggedInUserId === null)
        {
            $loggedInUserId = apiRequestData('userId');
        }

///echo '#'.$loggedInUserId.'#';

        if (empty2($loggedInUserId))
        {
            if (!$this->skipLoggedInUserIdCheck)
            {
                _e('loggedInUserId is required', 403);
            }
            return;
        }

        $this->apiLoggedInUser = User::find($loggedInUserId);

        if (!$this->apiLoggedInUser)
        {
            _e('loggedInUserId is not found in database', 403);
            return;
        }
    }

    abstract protected function apiAccessControl();


    public function apiExecuteCommand()
    {
        $this->apiDetectLoggedInUser();

        $this->validateParams();

        if ($this->hasValidationErrors())
        {
            $this->apiReturnValidationErrorsAsResponse();
            return;
        }

        $this->apiAccessControl();

        $this->execute();

        $this->apiReturnResultAsResponse();
    }


    protected function apiReturnValidationErrorsAsResponse()
    {
        if (isset($this->validationErrors[0]))
        {
            _e($this->validationErrors[0]['errorMsg'], $this->validationErrors[0]['httpStatus']);
            return;
        }
    }

    protected function apiReturnResultAsResponse()
    {
        returnResponseAsJson($this->result);
    }




    public function executeCommand()
    {
        $this->validateParams();

        if ($this->hasValidationErrors())
        {
            $vErrors = $this->getValidationErrors();
            throw new DataValidationException($vErrors[0]['errorMsg']);
        }

        $this->execute();
    }

}

