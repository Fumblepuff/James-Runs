<?php
namespace App\Actions;

use App\Models\EventRequest;


class GetGameRequestForm2Data extends BaseAction
{
    protected $eventRequestId;
    protected $eventRequest;

    public function __construct(Array $params=[])
    {
        $this->eventRequestId = extractParam($params, 'eventRequestId');
    }


    protected function apiAccessControl()
    {
        if (!$this->eventRequest->isOwnedBy($this->apiLoggedInUser))
        {
            _e('You don\'t have rights to access this event request', 403);
        }
    }


    protected function validateParams()
    {
        if (empty2($this->eventRequestId))
        {
            $this->addError('eventRequestId is required', 'eventRequestId', 422);
        }
        else
        {
            $this->eventRequest = EventRequest::find($this->eventRequestId);

            if (!$this->eventRequest)
            {
                $this->addError('eventRequestId is not found in database', 'eventRequestId', 422);
            }
        }
    }

    public function execute()
    {
        $this->result['homeTeamId'] = ['value' => $this->eventRequest->homeTeam->id, 'label' => $this->eventRequest->homeTeam->name];
        $this->result['homeTeamColor'] = ['value' => $this->eventRequest->homeTeamColor];
        $this->result['homeTeamRosterUrl'] = ['value' => $this->eventRequest->homeTeamRosterUrl];

        $this->result['guestTeamId'] = ['value' => $this->eventRequest->guestTeam->id, 'label' => $this->eventRequest->guestTeam->name];
        $this->result['guestTeamColor'] = ['value' => $this->eventRequest->guestTeamColor];
        $this->result['guestTeamRosterUrl'] = ['value' => $this->eventRequest->guestTeamRosterUrl];

        $orderTotals = $this->eventRequest->calculateOrderTotalsWithAllServices();
        $this->result['orderTotals'] = $orderTotals;
    }





    
}

