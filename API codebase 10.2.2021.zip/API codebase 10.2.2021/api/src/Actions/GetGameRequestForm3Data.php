<?php
namespace App\Actions;

use App\Models\EventRequest;


class GetGameRequestForm3Data extends BaseAction
{
    protected $eventRequestId;
    protected $eventRequest;

    public function __construct(Array $params=[])
    {
        $this->eventRequestId = extractParam($params, 'eventRequestId');
    }


    protected function apiAccessControl()
    {
        if (!$this->eventRequest->isOwnedBy($this->apiLoggedInUser))
        {
            _e('You don\'t have rights to access this event request', 403);
        }
    }


    protected function validateParams()
    {
        if (empty2($this->eventRequestId))
        {
            $this->addError('eventRequestId is required', 'eventRequestId', 422);
        }
        else
        {
            $this->eventRequest = EventRequest::find($this->eventRequestId);

            if (!$this->eventRequest)
            {
                $this->addError('eventRequestId is not found in database', 'eventRequestId', 422);
            }
        }
    }

    public function execute()
    {
        $this->result['videoLink'] = ['value' => $this->eventRequest->videoLink];
        $this->result['discountCode'] = ['value' => $this->eventRequest->discountCode];
        $this->result['specialNotes'] = ['value' => $this->eventRequest->specialNotes];


        if ($this->eventRequest->homeTeamScoreBookFile)
        {
            $this->result['homeTeamScoreBookFileId'] = 
            [
                'value' => $this->eventRequest->homeTeamScoreBookFileId, 
                'label' => $this->eventRequest->homeTeamScoreBookFile->originalName
            ];
        }


        if ($this->eventRequest->guestTeamScoreBookFile)
        {
            $this->result['guestTeamScoreBookFileId'] = 
            [
                'value' => $this->eventRequest->guestTeamScoreBookFileId, 
                'label' => $this->eventRequest->guestTeamScoreBookFile->originalName
            ];
        }

        $orderTotals = $this->eventRequest->calculateOrderTotalsWithAllServices();
        $this->result['orderTotals'] = $orderTotals;
    }

   
}

