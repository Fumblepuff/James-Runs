<?php
namespace App\Actions;

use App\Models\EventRequest;
use App\Models\UserTransaction;

class PaymentIntent extends BaseAction
{
    protected $whatIsPurchased;
    protected $purchaseDetailsJson;
    protected $purchaseDetails = [];

    public function __construct(Array $params=[])
    {
        $this->whatIsPurchased = extractParam($params, 'whatIsPurchased');
        $this->purchaseDetailsJson = extractParam($params, 'purchaseDetailsJson');
    }


    protected function validateParams()
    {
        $this->purchaseDetails = json_decode($this->purchaseDetailsJson, true);

        if (!is_array($this->purchaseDetails) || empty($this->purchaseDetails))
        {
            _e('purchaseDetailsJson contained invalid JSON!', 422); // should terminate script execution
        }

        switch ($this->whatIsPurchased)
        {
            case 'GameRequest':
            case 'RunRequest':
                $this->validateParamsEventRequest();
                break;

            default: 
                _e('whatIsPurchased contains unsupported value', 422);  // should terminate script execution
                break;
        }

        $ut = UserTransaction::findByPurchase($this->whatIsPurchased, $this->purchaseDetails);

        if ($ut && ($ut->status != 'Canceled'))
        {
            $this->addError("There is already a user_transaction record (with status={$ut->status}) in database for this order", 'purchaseDetailsJson', 422);
        }
    }

    protected function apiAccessControl()
    {
        switch ($this->whatIsPurchased)
        {
            case 'GameRequest':
            case 'RunRequest':
                $this->apiAccessControlEventRequest();
                break;
        }
    }


    public function execute()
    {
        $stripe = my_app('stripe');

        try 
        {
            $metadata = [];
            $metadata['whatIsPurchased'] = $this->whatIsPurchased;
            $metadata['purchaseDetailsJson'] = $this->purchaseDetailsJson;
            $metadata['userId'] = $this->apiLoggedInUser->id;



            $attr = 
            [
                'currency' => 'usd',

                'customer' => $this->apiLoggedInUser->getStripeCustomer()->id,  // $customer->id,

                'metadata' => $metadata,

                // indicates that you intend to make future payments with this PaymentIntent�s payment method.
                // on_session Use on_session if you intend to only reuse the payment method when your customer is present in your checkout flow.
                // off_session Use off_session if your customer may or may not be present in your checkout flow.
                'setup_future_usage' => 'off_session',

                 //  'payment_method_types' => ['card'],
            ];

            if (($this->whatIsPurchased == 'GameRequest') || ($this->whatIsPurchased == 'RunRequest'))
            {
                $attr['amount'] = $this->purchaseDetails['eventRequest']->grandTotalValue * 100;
            }

            // if need to put a hold on this amount instead of immediately making a charge
            if ($this->whatIsPurchased == 'GameRequest')
            {
                $attr['capture_method'] = 'manual';
            }
            else
            {
                $attr['capture_method'] = 'automatic';
            }


            if ($this->apiLoggedInUser->stripePaymentMethod)
            {
                $attr['payment_method'] = $this->apiLoggedInUser->stripePaymentMethod;
            }

            $paymentIntent = $stripe->paymentIntents->create($attr);



            global $config;

            $this->result['publicKey'] = $config['stripe_api_key_publishable'] ;

            $this->result['paymentIntent']['id'] = $paymentIntent->id;
            $this->result['paymentIntent']['clientSecret'] = $paymentIntent->client_secret;
        }
        catch (Error $e)
        {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }




    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    protected function validateParamsEventRequest()
    {
        if (isset($this->purchaseDetails['eventRequestId']))
        {
            $this->purchaseDetails['eventRequest'] = EventRequest::find($this->purchaseDetails['eventRequestId']);

            if (!$this->purchaseDetails['eventRequest'])
            {
                $this->addError('purchaseDetails.eventRequestId is not found in database', 'purchaseDetailsJson', 422);
            }
            else
            {
                if ($this->purchaseDetails['eventRequest']->eventTypeId == EVENT_TYPE_GAME)
                {
                    if ($this->whatIsPurchased != 'GameRequest')
                    {
                        $this->addError('whatIsPurchased should be equal to GameRequest for this payment', 'whatIsPurchased', 422);
                    }
                }
                elseif ($this->purchaseDetails['eventRequest']->eventTypeId == EVENT_TYPE_RUN)
                {
                    if ($this->whatIsPurchased != 'RunRequest')
                    {
                        $this->addError('whatIsPurchased should be equal to RunRequest for this payment', 'whatIsPurchased', 422);
                    }
                }
            }
        }
        else
        {
            $this->addError('purchaseDetails.eventRequestId is required', 'purchaseDetailsJson', 422);
        }
    }

    protected function apiAccessControlEventRequest()
    {
        if (!$this->purchaseDetails['eventRequest']->isOwnedBy($this->apiLoggedInUser))
        {
            _e('You don\'t have rights to access this event request', 403);
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
}

