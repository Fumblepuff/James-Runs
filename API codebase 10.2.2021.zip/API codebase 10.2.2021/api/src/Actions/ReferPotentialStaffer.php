<?php
namespace App\Actions;

use App\Models\EventRequest;
use App\Models\PotentialStafferReferral;


class ReferPotentialStaffer extends BaseAction
{
    protected $firstName;
    protected $lastName;
    protected $email;
    protected $phoneNumber;

    protected $eventRequestId;
    protected $eventRequest;

    public function __construct(Array $params=[])
    {
        $this->firstName = extractParam($params, 'firstName');
        $this->lastName = extractParam($params, 'lastName');
        $this->email = extractParam($params, 'email');
        $this->phoneNumber = extractParam($params, 'phoneNumber');
        $this->eventRequestId = extractParam($params, 'eventRequestId');
    }


    protected function apiAccessControl()
    {
        # submitting a staff referral probably doesn't require any special skills

///        if ($this->eventTypeId == 1) // Run
///        {
///            if (!$this->apiLoggedInUser->hasSkill(Skill::find(SKILL_RUN_ORGANIZING)))
///            {
///                _e('You must have run organizing skill to submit this request', 403);
///            }
///        }
///        elseif ($this->eventTypeId == 2) // Game
///        {
///            if (!$this->apiLoggedInUser->hasSkill(Skill::find(SKILL_GAME_ORGANIZING)))
///            {
///                _e('You must have game organizing skill to submit this request', 403);
///            }
///        }
    }


    protected function validateParams()
    {
        if (empty2($this->firstName))
        {
            $this->addError('First name is required', 'firstName', 422);
        }

        if (empty2($this->lastName))
        {
            $this->addError('Last name is required', 'lastName', 422);
        }

        if (empty2($this->email))
        {
            $this->addError('Email is required', 'email', 422);
        }
        else
        {
            if (!validEmail($this->email))
            {
                $this->addError('Email format is invalid', 'email', 422);
            }
        }

        if (empty2($this->phoneNumber))
        {
            $this->addError('Phone number is required', 'phoneNumber', 422);
        }


        if (!empty2($this->eventRequestId))
        {
            $this->eventRequest = EventRequest::find($this->eventRequestId);

            if (!$this->eventRequest)
            {
                $this->addError('eventRequestId is not found in database', 'eventRequestId', 422);
            }
        }

    }

    public function execute()
    {
        $e = new PotentialStafferReferral;

        $e->referrerUserId = $this->apiLoggedInUser->id;
        $e->eventRequestId = $this->eventRequestId;
        $e->firstName = $this->firstName;
        $e->lastName = $this->lastName;
        $e->email = $this->email;
        $e->phoneNumber = $this->phoneNumber;

        $e->save();

        $this->result['success'] = 'Success';
        $this->result['potentialStafferReferral'] = $e->toArray();
    }



    
}

