<?php
namespace App\Actions;

use App\Models\Court;
///use App\Resources\CourtResource;
///use Illuminate\Http\JsonResponse;
///use Illuminate\Http\Request;

class SearchCourts extends BaseAction
{
    protected $skipLoggedInUserIdCheck = true;

    protected $search;

    protected $limitOffset;
    protected $limitRowCount;


    public function __construct(Array $params=[])
    {
        $this->search = extractParam($params['data'], 'search');

        $this->limitOffset = extractParam($params['data'], 'page', 0);  // _refactor_ to limitOffset
        $this->limitRowCount = extractParam($params['data'], 'limitRowCount', 10);
    }


    protected function apiAccessControl()
    {

    }


    public function validateParams()
    {

    }

    public function execute()
    {
//echo 'here';

        $this->result = Court
            ::byName($this->search)
            ->isActive()
            ->hasAName()

            ->orderBy('name', 'ASC')
            ->skip($this->limitOffset)
            ->take($this->limitRowCount)

            ->get()
            ->toArray();
    }


/*
    protected function apiReturnResultAsResponse()
    {

//($data = null, $status = 200, $headers = [], $options = 0)

//echo new JsonResponse(['a'=>'b']);

//echo CourtResource::collection(Court::all())->toResponse(new Request);

//CourtResource

        returnResponseAsJson($this->result);
    }
*/

    
}


