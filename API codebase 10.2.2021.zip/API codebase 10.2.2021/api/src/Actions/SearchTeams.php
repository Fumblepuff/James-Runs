<?php
namespace App\Actions;

use App\Models\Team;


class SearchTeams extends BaseAction
{
    protected $search;

    protected $limitOffset;
    protected $limitRowCount;


    public function __construct(Array $params=[])
    {
        $this->search = extractParam($params, 'search');

        $this->limitOffset = extractParam($params, 'limitOffset', 0);
        $this->limitRowCount = extractParam($params, 'limitRowCount', 100);
    }


    protected function apiAccessControl()
    {

    }


    public function validateParams()
    {

    }

    public function execute()
    {
//echo 'here';

        $this->result = Team
            ::byName($this->search)
            ->isActive()
            ->hasAName()

            ->orderBy('name', 'ASC')
            ->skip($this->limitOffset)
            ->take($this->limitRowCount)

            ->get()
            ->toArray();
    }

    
}


