<?php
namespace App\Actions;

use App\Models\EventRequest;
use App\Models\Team;

class SetGameRequestForm2Data extends BaseAction
{
    protected $eventRequestId;
    protected $eventRequest;

    protected $homeTeamId;
    protected $homeTeam;
    protected $homeTeamColor;
    protected $homeTeamRosterUrl;

    protected $guestTeamId;
    protected $guestTeam;
    protected $guestTeamColor;
    protected $guestTeamRosterUrl;

    protected $commitForm;

    public function __construct(Array $params=[])
    {
        $this->eventRequestId = extractParam($params, 'eventRequestId');
 
        $this->homeTeamId = extractParam($params, 'homeTeamId');
        $this->homeTeamColor = extractParam($params, 'homeTeamColor');
        $this->homeTeamRosterUrl = extractParam($params, 'homeTeamRosterUrl');

        $this->guestTeamId = extractParam($params, 'guestTeamId');
        $this->guestTeamColor = extractParam($params, 'guestTeamColor');
        $this->guestTeamRosterUrl = extractParam($params, 'guestTeamRosterUrl');

        $this->commitForm = extractParam($params, 'commitForm');
    }


    protected function apiAccessControl()
    {
        if (!$this->eventRequest->isOwnedBy($this->apiLoggedInUser))
        {
            _e('You don\'t have rights to access this event request', 403);
        }
    }


    protected function validateParams()
    {
        if (empty2($this->eventRequestId))
        {
            $this->addError('eventRequestId is required', 'eventRequestId', 422);
        }
        else
        {
            $this->eventRequest = EventRequest::find($this->eventRequestId);

            if (!$this->eventRequest)
            {
                $this->addError('eventRequestId is not found in database', 'eventRequestId', 422);
            }
        }

        if (!empty2($this->homeTeamId))
        {
            $this->homeTeam = Team::find($this->homeTeamId);

            if (!$this->homeTeam)
            {
                $this->addError('homeTeamId is not found in database', 'homeTeamId', 422);
            }
        }


        if (!empty2($this->guestTeamId))
        {
            $this->guestTeam = Team::find($this->guestTeamId);

            if (!$this->guestTeam)
            {
                $this->addError('guestTeamId is not found in database', 'guestTeamId', 422);
            }
        }


        if (!empty2($this->homeTeamRosterUrl) && !validWebUrl($this->homeTeamRosterUrl))
        {
            $this->addError('Home team roster is not a valid URL', 'homeTeamRosterUrl', 422);
        }


        if (!empty2($this->guestTeamRosterUrl) && !validWebUrl($this->guestTeamRosterUrl))
        {
            $this->addError('Guest team roster is not a valid URL', 'guestTeamRosterUrl', 422);
        }

    }

    protected function validateWholeForm()
    {
        if (empty2($this->eventRequest->homeTeamId))
        {
            $this->addError('Home team is required', 'homeTeamId', 422);
        }

        if (empty2($this->eventRequest->homeTeamColor))
        {
            $this->addError('Home team color is required', 'homeTeamColor', 422);
        }

        if (empty2($this->eventRequest->homeTeamRosterUrl))
        {
            $this->addError('Home team roster is required', 'homeTeamRosterUrl', 422);
        }




        if (empty2($this->eventRequest->guestTeamId))
        {
            $this->addError('Guest team is required', 'guestTeamId', 422);
        }

        if (empty2($this->eventRequest->guestTeamColor))
        {
            $this->addError('Guest team color is required', 'guestTeamColor', 422);
        }

        if (empty2($this->eventRequest->guestTeamRosterUrl))
        {
            $this->addError('Guest team roster is required', 'guestTeamRosterUrl', 422);
        }


        if (!empty2($this->eventRequest->homeTeamId) && ($this->eventRequest->homeTeamId == ($this->eventRequest->guestTeamId)))
        {
            $this->addError('Home team and guest team cannot be the same', 'guestTeamId', 422);
        }


    }

    public function execute()
    {
        foreach(['homeTeamId', 'homeTeamColor', 'homeTeamRosterUrl', 'guestTeamId', 'guestTeamColor', 'guestTeamRosterUrl'] as $property)
        {
            if (!empty2($this->$property))
            {
                $this->eventRequest->$property = $this->$property;
            }
        }


        $this->eventRequest->save();


        if ($this->commitForm == 'Yes')
        {
            $this->validateWholeForm();
        }

        if ($this->hasValidationErrors())
        {
            $this->apiReturnValidationErrorsAsResponse();
            return;
        }

        if ($this->commitForm == 'Yes')
        {
            $this->eventRequest->form2Commited = 'Yes';
            $this->eventRequest->save();
        }


        ////////////////////////////////////////////////////////////////////

        $params = [
          'eventRequestId' => $this->eventRequest->id,
          'loggedInUserId' => $this->apiLoggedInUser->id,
        ];

        $obj = new GetGameRequestForm2Data($params);
        $obj->executeCommand();

        $this->result =
        [
          'success' => 'Success',
          'getGameRequestForm2Data' => $obj->getResult()
        ];


    }


}

