<?php
namespace App\Actions;

use App\Models\EventRequest;
use App\Models\Team;
use App\Models\File;

class SetGameRequestForm3Data extends BaseAction
{
    protected $eventRequestId;
    protected $eventRequest;

    protected $videoLink;
    protected $discountCode;
    protected $specialNotes;


    protected $homeTeamScoreBookFileId;
    protected $homeTeamScoreBookFile;

    protected $guestTeamScoreBookFileId;
    protected $guestTeamScoreBookFile;

    protected $commitForm;

    public function __construct(Array $params=[])
    {
        $this->eventRequestId = extractParam($params, 'eventRequestId');
 
        $this->videoLink = extractParam($params, 'videoLink');
        $this->discountCode = extractParam($params, 'discountCode');
        $this->specialNotes = extractParam($params, 'specialNotes');


        $this->homeTeamScoreBookFileId = extractParam($params, 'homeTeamScoreBookFileId');
        $this->guestTeamScoreBookFileId = extractParam($params, 'guestTeamScoreBookFileId');


        $this->commitForm = extractParam($params, 'commitForm');
    }


    protected function apiAccessControl()
    {
        if (!$this->eventRequest->isOwnedBy($this->apiLoggedInUser))
        {
            _e('You don\'t have rights to access this event request', 403);
        }
    }


    protected function validateParams()
    {
        if (empty2($this->eventRequestId))
        {
            $this->addError('eventRequestId is required', 'eventRequestId', 422);
        }
        else
        {
            $this->eventRequest = EventRequest::find($this->eventRequestId);

            if (!$this->eventRequest)
            {
                $this->addError('eventRequestId is not found in database', 'eventRequestId', 422);
            }
        }

        if (!empty2($this->videoLink) && !validWebUrl($this->videoLink))
        {
            $this->addError('Video link is not a valid URL', 'videoLink', 422);
        }


        if (!empty2($this->homeTeamScoreBookFileId))
        {
            $this->homeTeamScoreBookFile = File::find($this->homeTeamScoreBookFileId);

            if (!$this->homeTeamScoreBookFile)
            {
                $this->addError('homeTeamScoreBookFileId is not found in database', 'homeTeamScoreBookFileId', 422);
            }
            else
            {
                if (!$this->homeTeamScoreBookFile->isOwnedBy($this->apiLoggedInUser))
                {
                    $this->addError("You are not an owner of file with id={$this->homeTeamScoreBookFileId}", 'homeTeamScoreBookFileId', 422);
                }
                elseif (!$this->homeTeamScoreBookFile->isOfUploadType('teamScoreBook'))
                {
                    $this->addError("The file uploaded to homeTeamScoreBookFileId must be of fileType=teamScoreBook", 'homeTeamScoreBookFileId', 422);
                }
            }
        }


        if (!empty2($this->guestTeamScoreBookFileId))
        {
            $this->guestTeamScoreBookFile = File::find($this->guestTeamScoreBookFileId);

            if (!$this->guestTeamScoreBookFile)
            {
                $this->addError('guestTeamScoreBookFileId is not found in database', 'guestTeamScoreBookFileId', 422);
            }
            else
            {
                if (!$this->guestTeamScoreBookFile->isOwnedBy($this->apiLoggedInUser))
                {
                    $this->addError("You are not an owner of file with id={$this->guestTeamScoreBookFileId}", 'guestTeamScoreBookFileId', 422);
                }
                elseif (!$this->guestTeamScoreBookFile->isOfUploadType('teamScoreBook'))
                {
                    $this->addError("The file uploaded to guestTeamScoreBookFileId must be of fileType=teamScoreBook", 'guestTeamScoreBookFileId', 422);
                }
            }
        }


        if (!empty2($this->homeTeamScoreBookFileId) && !empty2($this->guestTeamScoreBookFileId))
        {
            if ($this->homeTeamScoreBookFileId === $this->guestTeamScoreBookFileId)
            {
                $this->addError("guestTeamScoreBookFileId cannnot be equal to homeTeamScoreBookFileId", 'guestTeamScoreBookFileId', 422);
            }
        }
    }


    protected function validateWholeForm()
    {
        if ($this->eventRequest->form1Commited != 'Yes')
        {
            $this->addError("You must commit Form1 before you can commit this form", '', 422);
        }


        if ($this->eventRequest->form2Commited != 'Yes')
        {
            $this->addError("You must commit Form2 before you can commit this form", '', 422);
        }
    }

    public function execute()
    {
        foreach(['videoLink', 'discountCode', 'specialNotes', 'homeTeamScoreBookFileId', 'guestTeamScoreBookFileId'] as $property)
        {
            if (!empty2($this->$property))
            {
                $this->eventRequest->$property = $this->$property;
            }
        }


        $this->eventRequest->save();


        if ($this->commitForm == 'Yes')
        {
            $this->validateWholeForm();
        }

        if ($this->hasValidationErrors())
        {
            $this->apiReturnValidationErrorsAsResponse();
            return;
        }

        if ($this->commitForm == 'Yes')
        {
            $this->eventRequest->form3Commited = 'Yes';
            $this->fulfillmentStatus = EventRequest::FULFILLMENT_STATUS_CREATED;


            $orderTotals = $this->eventRequest->calculateOrderTotalsWithAllServices();

            $this->eventRequest->subTotalValue = $orderTotals['subTotal'];
            $this->eventRequest->discountValue = $orderTotals['discount'];
            $this->eventRequest->taxValue = $orderTotals['tax'];
            $this->eventRequest->grandTotalValue = $orderTotals['grandTotal'];

            $this->eventRequest->save();
        }


        ////////////////////////////////////////////////////////////////////

        $params = [
          'eventRequestId' => $this->eventRequest->id,
          'loggedInUserId' => $this->apiLoggedInUser->id,
        ];

        $obj = new GetGameRequestForm3Data($params);
        $obj->executeCommand();

        $this->result =
        [
          'success' => 'Success',
          'getGameRequestForm3Data' => $obj->getResult()
        ];


    }


}

