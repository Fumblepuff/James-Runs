<?php
namespace App\Actions;

use App\Models\EventRequest;


class StripeGetPublicKey extends BaseAction
{
    public function __construct(Array $params=[])
    {

    }


    protected function apiAccessControl()
    {

    }


    protected function validateParams()
    {

    }

    public function execute()
    {
        global $config;

        $this->result['publicKey'] = $config['stripe_api_key_publishable'] ;
    }



    
}

