<?php
namespace App\Actions;



/// Move to EventRequest->fulfill()


class FulfillEventRequest extends BaseAction
{

/*

Different services may resolve to the same skill:

`service` table:
id   name                skillId
11   Production            35
24   Game Highlights       35
25   Baller Highlights     35

So when for example serviceId=11 and serviceId=24 are requested, two spots with skillId=35 should be created
	
*/


    
}

