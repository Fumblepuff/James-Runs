<?php
namespace App\Actions;

use App\Models\EventRequest;
use App\Models\League;
use App\Models\EventLevel;
use App\Models\Service;

class GetGameRequestForm1Data extends BaseAction
{
    protected $eventRequestId;
    protected $eventRequest;

    public function __construct(Array $params=[])
    {
        $this->eventRequestId = extractParam($params, 'eventRequestId');
    }


    protected function apiAccessControl()
    {
        if (!$this->eventRequest->isOwnedBy($this->apiLoggedInUser))
        {
            _e('You don\'t have rights to access this event request', 403);
        }
    }


    protected function validateParams()
    {
        if (empty2($this->eventRequestId))
        {
            $this->addError('eventRequestId is required', 'eventRequestId', 422);
        }
        else
        {
            $this->eventRequest = EventRequest::find($this->eventRequestId);

            if (!$this->eventRequest)
            {
                $this->addError('eventRequestId is not found in database', 'eventRequestId', 422);
            }
        }
    }

    public function execute()
    {
        $this->result['leagueId'] = $this->getLeagueIdStruct();
        $this->result['eventLevelId'] = $this->getEventLevelIdStruct();
        $this->result['services'] = $this->getServicesStruct();

        $orderTotals = $this->eventRequest->calculateOrderTotalsWithAllServices();
        $this->result['orderTotals'] = $orderTotals;
    }


    protected function getLeagueIdStruct()
    {
        $result = [];
        $result['value'] = $this->eventRequest->leagueId;

        $leagues = League::getAllActive();

        $result['options'] = [];

        foreach($leagues as $league)
        {
            $option = [];

            $option['id'] = $league->id;
            $option['name'] = $league->name;
            $option['shortName'] = $league->shortName;
            $option['eventLevelId'] = $league->eventLevelId;
            $option['isSelected'] = ($result['value'] === $league->id) ? 'Yes' : 'No';

            $result['options'][] = $option;
        }

        return $result;
    }


    protected function getEventLevelIdStruct()
    {
        $result = [];
        $result['value'] = $this->eventRequest->eventLevelId;

        $eventLevels = EventLevel::getAllActive();

        $result['options'] = [];

        foreach($eventLevels as $eventLevel)
        {
            $option = [];

            $option['id'] = $eventLevel->id;
            $option['name'] = $eventLevel->name;
            $option['shortName'] = $eventLevel->shortName;
            $option['isSelected'] = ($result['value'] === $eventLevel->id) ? 'Yes' : 'No';

            $result['options'][] = $option;
        }

        return $result;
    }


    protected function getServicesStruct()
    {
        if ($this->eventRequest->eventLevelId === null)
        {
            return [];
        }

        if ($this->eventRequest->eventLevel === null)
        {
            return [];
        }


        $services = $this->eventRequest->eventLevel->getEventLevelServices();


        $ris = $this->eventRequest->items;

        $requestItems = [];

        foreach($ris as $ri)
        {
            $requestItems[$ri->serviceId] = $ri;
        }

//return $services;

//return $requestItems;

        $result = [];

        foreach($services as $service)
        {
            $r = [];

            $r['id'] = $service->service->id;
            $r['name'] = $service->service->name;
            $r['isSelected'] = isset($requestItems[$r['id']]) ? 'Yes' : 'No';
            $r['price'] =  $service->price;

            if (isset($requestItems[$r['id']]))
            {
                $selectedOptions = $requestItems[$r['id']]->options;
            }
            else
            {
                $selectedOptions = [];
            }

            $ao = Service::getAvailableOptions($r['id']);

            $availableOptions = $ao['options'];

            $options = [];

            foreach($availableOptions as $avo)
            {
                $o = [];
                $o['id'] = $avo['id'];
                $o['name'] = $avo['name'];
                $o['isSelected'] = in_array($avo['id'], $selectedOptions) ? 'Yes' : 'No';

                $options[] = $o;
            }

            $r['options'] = $options;
            $r['optionsType'] = $ao['optionsType'];

            $result[] = $r;
        }


        return $result;
    }




    
}

