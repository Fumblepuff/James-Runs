<?php
namespace App\Actions;

use App\Models\EventRequest;
use App\Models\League;
use App\Models\EventLevel;
use App\Models\Service;

class SetGameRequestForm1Data extends BaseAction
{
    protected $eventRequestId;
    protected $eventRequest;

    protected $leagueId;
    protected $league;

    protected $eventLevelId;
    protected $eventLevel;

    protected $services;
    protected $commitForm;

    protected $availableServices;


    public function __construct(Array $params=[])
    {
        $this->eventRequestId = extractParam($params, 'eventRequestId');

        $this->leagueId = extractParam($params, 'leagueId');
        $this->eventLevelId = extractParam($params, 'eventLevelId');
        $this->services = extractParam($params, 'services', []);
        $this->commitForm = extractParam($params, 'commitForm');
    }


    protected function apiAccessControl()
    {
        if (!$this->eventRequest->isOwnedBy($this->apiLoggedInUser))
        {
            _e('You don\'t have rights to access this event request', 403);
        }
    }


    protected function validateParams()
    {
        if (empty2($this->eventRequestId))
        {
            $this->addError('eventRequestId is required', 'eventRequestId', 422);
        }
        else
        {
            $this->eventRequest = EventRequest::find($this->eventRequestId);

            if (!$this->eventRequest)
            {
                $this->addError('eventRequestId is not found in database', 'eventRequestId', 422);
            }
        }

        if (!empty2($this->leagueId))
        {
            $this->league = League::find($this->leagueId);

            if (!$this->league)
            {
                $this->addError('leagueId is not found in database', 'leagueId', 422);
            }
        }


        if (!empty2($this->eventLevelId))
        {
            $this->eventLevel = EventLevel::find($this->eventLevelId);

            if (!$this->eventLevel)
            {
                $this->addError('eventLevelId is not found in database', 'eventLevelId', 422);
            }
        }


        if (is_array($this->services))
        {
            $this->availableServices = [];

///echo '1111';

            if (!empty2($this->eventLevelId)) // this is needed! 
            {
                $this->eventRequest->eventLevelId = $this->eventLevelId;
            }

            if ($this->eventRequest->eventLevel)
            {
///echo '2222';
                $this->availableServices = $this->eventRequest->eventLevel->getEventLevelServicesArrayIndexedById();
            }

            foreach($this->services as $service)
            {
                $this->validateService($service);
            }
        }


    }

    protected function validateWholeForm()
    {
        if (empty2($this->eventRequest->leagueId))
        {
            $this->addError('League is required', 'leagueId', 422);
        }

        if (empty2($this->eventRequest->eventLevelId))
        {
            $this->addError('Event level is required', 'eventLevelId', 422);
        }

        // must have at least one service
        $items = $this->eventRequest->items;

        if (count($items) == 0)
        {
            $this->addError('At least one service should be selected', 'services', 422);
        }
    }

    public function execute()
    {
        if (!empty2($this->leagueId))
        {
            $this->eventRequest->leagueId = $this->leagueId;
        }

        if (!empty2($this->eventLevelId))
        {
            if ($this->eventRequest->getOriginal('eventLevelId') != $this->eventLevelId)
            {
                $this->eventRequest->removeAllItems();   // this is needed!
            }

            $this->eventRequest->eventLevelId = $this->eventLevelId;
        }

        $this->eventRequest->save();


        if (is_array($this->services))
        {
            foreach($this->services as $service)
            {
                $this->saveServiceToEventRequest($service);
            }
        }


        if ($this->commitForm == 'Yes')
        {
            $this->validateWholeForm();
        }

        if ($this->hasValidationErrors())
        {
            $this->apiReturnValidationErrorsAsResponse();
            return;
        }

        if ($this->commitForm == 'Yes')
        {
            $this->eventRequest->form1Commited = 'Yes';
            $this->eventRequest->save();
        }


        ////////////////////////////////////////////////////////////////////

        $params = [
          'eventRequestId' => $this->eventRequest->id,
          'loggedInUserId' => $this->apiLoggedInUser->id,
        ];

        $obj = new GetGameRequestForm1Data($params);
        $obj->executeCommand();

        $this->result =
        [
          'success' => 'Success',
          'getGameRequestForm1Data' => $obj->getResult()
        ];


    }


/*

    {
      "id": 17,
      "isSelected": "Yes",
      "options": [
        {
          "id": 1,
          "isSelected": "No"
        },
        {
          "id": 2,
          "isSelected": "Yes"
        },
        {
          "id": 3,
          "isSelected": "No"
        }
      ]
    }

*/
    protected function saveServiceToEventRequest(Array $service)
    {
        if ($service['isSelected'] == 'Yes')
        {
            $options = [];

            if (is_array($service['options']))
            {
                foreach($service['options'] as $o)
                {
                    $options[] = (int) $o;
                }
            }

            $eventLevelService = $this->availableServices[$service['id']];

            $this->eventRequest->addEventLevelService($eventLevelService, $options);
        }
        else
        {
            $this->eventRequest->removeServiceById($service['id']);
        }
    }

    protected function validateService(Array $service)
    {
        if ($service['isSelected'] == 'No')
        {
            return; // removing a service doesn't require validation
        }

///echo "#{$service['id']}#";
///print_r($this->availableServices);

        if (!isset($this->availableServices[$service['id']]))
        {
            $this->addError("Service (id={$service['id']}) is not available for this event level", 'services', 422);
        }
        else
        {
            $errors = [];

            $options = [];

            if (is_array($service['options']))
            {
                foreach($service['options'] as $o)
                {
                    $options[] = (int) $o;
                }
            }

            Service::validateOptions($service['id'], $options, $errors);

            if ($errors != [])
            {
                $this->addError($errors[0], 'services', 422);
            }

        }

    }

}

