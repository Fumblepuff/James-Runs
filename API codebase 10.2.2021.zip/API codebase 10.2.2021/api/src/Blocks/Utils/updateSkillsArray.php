<?php

function getSkills($runId = 0)
{
    global $db;
    if ($runId < 1) return [];
    $spots_sql = "SELECT `skillId`, `userId`, `reserve`,`checkIn` FROM `".DB_TABLE_RUN_USER."` WHERE runId = $runId";                
    $spots = $db->selectQuery($spots_sql);
    return updateSkillsArray($spots);
}

function updateSkillsArray(array $data = [])
{
    $ret = [];

    if (!empty($data)){
        foreach ($data as $spots){

            $key = $spots['skillId'];


           if (!array_key_exists($key,$ret)){


                $ret[$key] = [
                    'spots_needed' => 0, 
                    'reserved' => [],
                    'a' => 0
                ];

           } 
           
           $ret[$key]['spots_needed']++;


           if ($spots['userId'] == '-1'){
               $ret[$key]['a']++;     
           } else {
               $ret[$key]['reserved'][] = $spots['userId'];
           }

        }
    }
    return $ret;
}
