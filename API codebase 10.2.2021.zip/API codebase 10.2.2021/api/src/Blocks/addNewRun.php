<?php

defined('IS_API') || die('Access Denied');

$court = (int)$apiRequestData['court'];

if ($court < 1)
{
    _e('Invalid court');
}

$courtData = lookupCourtById($court);

///print_r($courtData);


if (!is_array($courtData))
{
    _e("Court doesn't exist");
}


$schedule = $apiRequestData['schedule'];
$schedule['schedule'] = $schedule;

// NYI Raise an error if schedule is missing or empty


foreach ($schedule['schedule'] as $run)
{
    $date = convertDateTimeToUtc($run['id'], $courtData['timezone']);
    $date = setZeroSecondsOnDateTime($date);

    $type =  $run['type'];


/// vicvk - looks like that either for ($type == 1) or for ($type == 2) 
/// we should set 
///        $setSchedule['ballerLimit'] = 3;
///        $setSchedule['runCost'] = 0;   
///
///
///    if(($live && $type == 1) || (!$live && $type == 2)){
///        $setSchedule['ballerLimit'] = 3;
///        $setSchedule['runCost'] = 0;   
///    }

///    if ($type == 1)
///    {
///        $setSchedule['ballerLimit'] = 3;
///        $setSchedule['runCost'] = 0;   
///    }

    $setSchedule = [];

    $setSchedule['runSchedule'] = $run['id'];
    $setSchedule['runScheduleUtc'] = $date;
    $setSchedule['courtId'] = $court;
    $setSchedule['type'] = $type;

    $db->insertValue('runs', $setSchedule);


    $runId = $db->insert_id;

         
    if (!empty($run['skills'])){
        foreach ($run['skills'] as $skill_id => $spots_needed){
            
            $skill_globally_allowed = $db->selectQuery("SELECT `id`, `reserve`, `longName` FROM `".DB_TABLE_SKILLS."` WHERE `id`= {$skill_id}");

            if ((empty($skill_globally_allowed) || $skill_globally_allowed[0]['reserve'] <= 0))
            {
                _e("Skill '{$skill_globally_allowed[0]['longName']}' (id={$skill_id}) cannot be reserved");
            }

            $skill_id = (int)$skill_id;

            /* deleting only unreserver spots */
            //TODO: maybe notify user somehow? if there are 2 users already reserver, and when editing game I update to 2 - no new spots should be added
            $sql = "DELETE FROM `run_user` WHERE `runId` = {$runId} AND `skillId` = {$skill_id} AND `userId` = -1";
            $db->selectQuery($sql);   

//            # vicvk: ^^^^ the above deletion is meaningless because we are just creating a run and do not yet have any records in run_user
//            # that are associeted with the newely created run.

            if ($spots_needed > 0){
                    
                for ($i = 0; $i < $spots_needed; $i++){
                    $sql = "INSERT INTO `run_user` (runId,skillId,userId) VALUES ({$runId},{$skill_id},-1)";
                    $db->selectQuery($sql);
                }

            } else {
                
                /* if spots not needed, deleting spots, including reserved */
                $sql = "DELETE FROM `run_user` WHERE `runId` = {$runId} AND `skillId` = {$skill_id}";
                $db->selectQuery($sql);

//            # vicvk: ^^^^ the above deletion is meaningless because we are just creating a run and do not yet have any records in run_user
//            # that are associeted with the newely created run.

            }   


        }     
    }
}

_s();    
