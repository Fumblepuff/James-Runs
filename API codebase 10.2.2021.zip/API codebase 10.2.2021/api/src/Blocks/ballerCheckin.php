<?php

defined('IS_API') || die('Access Denied');


$run         = (int)$apiRequestData['run'];
$user         = (int)$apiRequestData['user'];
$checkin     = (int)$apiRequestData['checkin'];

if ($run == 0 ){
    $run = (int)$apiRequestData['runId'];
}

if ($user == 0){
    $user = (int)$apiRequestData['userId'];
}

if (empty($apiRequestData)){
    _e("Data missing");
}

if ($run < 1){
    _e("Game missing");
}

if ($user < 1){
    _e("User missing");
}

$fix_id = $db->selectQuery('SELECT `id`,`checkIn` FROM `'.DB_TABLE_RUN_USER.'` WHERE `userId` = '.$user.' AND `runId` = '.$run.' AND `skillId` = '.BALLER_SKILL_ID.' LIMIT 1');         
if ($fix_id[0]['checkIn'] == $checkin){
    _e('Baller already '.($checkin == 0 ?'un':'').'checked in');
}

$fix_record_id = $fix_id[0]['id'];                

if ($fix_record_id > 0){
    if(!$checkin){                
        $checkin = 0;
        // $db->selectQuery('delete from user_team where runId = '.$run.' and userId = '.$user);
        $db->selectQuery(
            'UPDATE `'.DB_TABLE_RUN_USER.'` 
            SET `checkIn` = '.$checkin.', `bench` = 0, `next` = 0, `active` = 0, `checkOutDate` = NOW()
            WHERE `id` = '.$fix_record_id
        );

    } else {

        $db->selectQuery(
            'UPDATE `'.DB_TABLE_RUN_USER.'` 
            SET `checkIn` = '.$checkin.', `bench` = 1, `checkInDate` = NOW(), `lastGamePlayed` = NOW() 
            WHERE `id` = '.$fix_record_id
        );
    }
} else {
    _e('Baller not found');
}

/* recheck status*/
$check = $db->selectQuery('SELECT `checkIn` FROM `'.DB_TABLE_RUN_USER.'` WHERE `id` = '.$fix_record_id);
if ($check && $check[0]['checkIn'] == $checkin){
    _s();
} else {
    _e('Checkin failed. Please try again');
}