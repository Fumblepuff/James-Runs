<?php

defined('IS_API') || die('Access Denied');

if (empty($apiRequestData['runId'])) {
    _e($required.' is required');            
} else {   
    /* related record from run_game,run_spots,run_spots_reserved is deleted via foreign key */
    if ($db->deleteValue(DB_TABLE_RUNS,'id',(int)$apiRequestData['runId'])){
        _s();
    } else {
        _e();
    }
}
