<?php

defined('IS_API') || die('Access Denied');

$allowedEdit = ['type','runSchedule','skills'];
$required = 'runId';

/* require at least one field to update */
if (count(array_intersect(array_keys($apiRequestData),$allowedEdit)) < 1){
    _e('Update fields missing');
} elseif (empty($apiRequestData[$required])) {
    _e($required.' is required');            
}
else 
{
    $runId = (int) $apiRequestData['runId'];

    $runData = lookupRunById($runId);

    if (!is_array($runData))
    {
        _e("Run with id={$runId} is missing in database");
    }

    $courtData = lookupCourtById($runData['courtId']);

    if (!is_array($courtData))
    {
        _e("Court with courtId={$runData['courtId']} which is associated with this run (runId={$runId}) is missing in database");
    }

    $update = [];

    if (!empty($apiRequestData['type'])){
    
        $update['type'] = (int)$apiRequestData['type'];
       
    }

    if (!empty($apiRequestData['runSchedule']))
    {
        $dt = convertDateTimeToUtc($apiRequestData['runSchedule'], $courtData['timezone']);
        $dt = setZeroSecondsOnDateTime($dt);

        $update['runSchedule'] = $apiRequestData['runSchedule'];
        $update['runScheduleUtc'] = $dt;
    }

    if (!empty($update)){
        if (!$db->updateValues(DB_TABLE_RUNS, $update,array('id' => $runId))){
            _e('Error occuried while updating. Please try again');
        } 
    } 

    if (!empty($apiRequestData['skills'])){

        $skill_ids = array_keys($apiRequestData['skills']);
        $stmt = $db->pdo->prepare("SELECT COUNT(*) FROM `".DB_TABLE_SKILLS."` WHERE `id` IN(".implode(',',$skill_ids).")");
        $stmt->execute();
        $rows = $stmt->fetchColumn();
        if ($rows <> count($skill_ids)){
            _e('Some skill passed does not exist in DB!');
        }
        else 
        {
            foreach ($apiRequestData['skills'] as $skill_id => $spots_needed){
                           
                $skill_globally_allowed = $db->selectQuery("SELECT `id` FROM `".DB_TABLE_SKILLS."` WHERE `id`= {$skill_id} AND `reserve` > 0");
                if (empty($skill_globally_allowed)){
                    _e("Skill ({$skill_id}) cannot be reserved");
                }

                $skill_id = (int)$skill_id;

                /* deleting only unreserver spots */
                //TODO: maybe notify user somehow? if there are 2 users already reserver, and when editing game I update to 2 - no new spots should be added
                $sql = "DELETE FROM `".DB_TABLE_RUN_USER."` WHERE `runId` = {$runId} AND `skillId` = {$skill_id} AND `userId` = -1";
                $db->selectQuery($sql);                  


                // NYI _bug_ vicvk - there is a hidden bug here. This algorythm doesn't handle situation when the number of
                // spots has changed - increased or decreased and we already have spots reserved by users.
                if ($spots_needed > 0)
                {
                    
                    for ($i = 0; $i < $spots_needed; $i++)
                    {
                        $sql = "INSERT INTO `".DB_TABLE_RUN_USER."` (runId,skillId,userId) VALUES ({$runId},{$skill_id},-1)";
                        $db->selectQuery($sql);
                    }

                } else {
                    
                    /* if spots not needed, deleting spots, including reserved */
                    $sql = "DELETE FROM `".DB_TABLE_RUN_USER."` WHERE `runId` = {$runId} AND `skillId` = {$skill_id}";
                    $db->selectQuery($sql);
                }                                              


            }


        }
    }
}

_s();

