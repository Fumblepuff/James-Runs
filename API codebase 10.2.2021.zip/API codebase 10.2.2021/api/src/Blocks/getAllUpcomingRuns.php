<?php

defined('IS_API') || die('Access Denied');


$type = (int)(isset($apiRequestData['type']) ? (int)$apiRequestData['type']:0);


$sql = <<<SQL
SELECT
    courts.*, 
    runs.id as runId, 
    runs.runScheduleUtc as timeStamp, 
    runs.runEnd, 
    runs.runCost, 
    runs.type 

FROM 
    runs 

INNER JOIN courts ON runs.courtId = courts.id 

WHERE 
    DATE(runs.runScheduleUtc) >= DATE(NOW()) 
      AND 
    runs.active = 1 
      AND 
    runs.runEnd = 0

SQL;

if ($type > 0) {  // sql-injection!!
    $sql .= " AND runs.type = {$type}";
}

$sql .= " ORDER BY runs.runScheduleUtc ASC";


$runs = $db->selectQuery($sql);

adjustRunScheduleForAListOfRuns($runs);

if (empty($runs))
{
    if ($type == 1)
    {
        _e('No upcoming games');
    }
    elseif ($type == 2)
    {
        _e('No upcoming runs');
    }
    else
    {
        _e('No upcoming events');
    }
}

/* 
    code block repeating in 
    getUpcomingRuns,
    getUpcomingCourtRuns,
    getAllUpcomingRuns
    TODO: rewrite via i nclude, to avoid repetition

*/


require_once(__DIR__ . '/Utils/updateSkillsArray.php');

$z = 0;
$response = [];

foreach ($runs as $run){
    $response[$z] = $run;
    $response[$z]['skills'] = getSkills($run['runId']);          
    $z++;
}

returnResponseAsJson($response);
die();

