<?php

defined('IS_API') || die('Access Denied');


$user     = (int)$apiRequestData['user'];
$year   = (int)$apiRequestData['y'];
$month  = (int)$apiRequestData['m'];


if (empty($apiRequestData)){
    _e("Data missing");
}

$sql = 'SELECT 
            user_streak.wins,
            user_streak.losses,
            user_streak.streak,
            user_streak.jamesRating, 
            users.*, 
            user_detail.ballerTag 
        FROM `user_streak` 
        INNER JOIN 
                users 
            ON 
                users.id = user_streak.userId 
        INNER JOIN 
                user_detail 
            ON users.id = user_detail.userId';

if ($year > 2017 && $year < date("Y") + 1 && $month > 0 && $month < 13){
    $sql .= ' WHERE YEAR(user_streak.date) = '.$year.' AND MONTH(user_streak.date) = '.$month;
}

$sql .= ' ORDER BY 
            user_streak.jamesRating 
        DESC LIMIT 10';

$ballers = $db->selectQuery($sql);    


returnResponseAsJson($ballers);

die();


//ALTER TABLE `user_streak` ADD INDEX(`date`);
