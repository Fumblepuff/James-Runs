<?php

defined('IS_API') || die('Access Denied');


$run = (int)$apiRequestData['run'];

if ($run < 1){
    _e('Invalid game');
} else {

require_once(__DIR__ . '/Utils/updateSkillsArray.php');

$response = array();
$limit = $db->selectQuery('select * from runs where id = '.$run);    
$response = $limit[0];
$response['skills'] = getSkills($run);


returnResponseAsJson($response);

die();

}
