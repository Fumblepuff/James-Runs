<?php

defined('IS_API') || die('Access Denied');


$court = (int)$apiRequestData['court'];
if ($court < 1){
    _e('Invalid Court');
} else {

$type = (int)(isset($apiRequestData['type']) ? (int)$apiRequestData['type']:0);
    

    $sql = <<<SQL
SELECT
    courts.*, 
    runs.id as runId, 
    runs.runScheduleUtc as timeStamp, 
    runs.runEnd, 
    runs.active, 
    runs.type 
    
FROM 
    runs 

INNER JOIN courts ON runs.courtId = courts.id

WHERE 
    runs.courtId = :court
      AND
    DATE(runs.runScheduleUtc) >= DATE(NOW()) 

SQL;
    
    if ($type > 0) // sql-injection!!
    {
        $sql .= ' AND runs.type = '.($type);
    }

    $sql .= ' ORDER BY runs.runScheduleUtc ASC ';

    $runs = $db->selectQuery($sql, [[':court', $court]]);

    adjustRunScheduleForAListOfRuns($runs);


    if (empty($runs))
    {
        if ($type == 1)
        {
            _e('No upcoming games in this court');
        }
        elseif ($type == 2)
        {
            _e('No upcoming runs in this court');
        }
        else
        {
            _e('No upcoming events in this court');
        }
    }
}

require_once(__DIR__ . '/Utils/updateSkillsArray.php');


$z = 0;
$response = [];
foreach ($runs as $run){
    $response[$z] = $run;
    $response[$z]['skills'] = getSkills($run['runId']);          
    $z++;
}

returnResponseAsJson($response);

die();



