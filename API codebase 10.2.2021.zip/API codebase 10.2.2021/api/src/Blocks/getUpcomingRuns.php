<?php

defined('IS_API') || die('Access Denied');

// vicvk: I suspect user is never actually passed here. there are other endpoints that
// return runs for user. need to check in future.
$user = (int)$apiRequestData['user'];

require_once(__DIR__ . '/Utils/updateSkillsArray.php');

$z = 0;
$type = (int)(isset($apiRequestData['type']) ? (int)$apiRequestData['type']:0);


if ($user > 0)
{
    $byUser = " INNER JOIN run_user ON run_user.runId = runs.id ";
}
else
{
    $byUser = "";
}

$sql = <<<SQL
SELECT 
    courts.*, 
    runs.id AS runId, 
    runs.runScheduleUtc AS timeStamp, 
    runs.runEnd, 
    runs.runCost 

FROM 
    runs 

INNER JOIN courts ON runs.courtId = courts.id 
{$byUser}

WHERE 
    runs.active = 1 
      AND 
    DATE(runs.runScheduleUtc) >= DATE(NOW())
      AND 
    runs.runEnd = 0

SQL;


if ($user > 0)
{
    $sql .= " AND userId = '{$user}'";
}            

if ($type > 0)
{
    $sql .= " AND runs.type = '{$type}'";
}

////vicvk: group by is not needed: $sql .= " GROUP BY `runId` ORDER BY timeStamp ASC";

$sql .= " ORDER BY timeStamp ASC";
     

    $runs = $db->selectQuery($sql);    

    adjustRunScheduleForAListOfRuns($runs);

    $response = array();
    foreach ($runs as $run){
        $response[$z] = $run;
        $run['runId'] = (int)$run['runId'];
        $response[$z]['skills'] = getSkills($run['runId']);  
        $z++;                   
   }

returnResponseAsJson($response);

