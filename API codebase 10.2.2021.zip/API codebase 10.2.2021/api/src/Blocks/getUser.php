<?php

defined('IS_API') || die('Access Denied');

$user = $apiRequestData;
if(empty($user)){
    _e('Data missing');
}                        

$sql = 'SELECT `u`.*, `s`.`memberType` AS skillId 
        FROM `'.DB_TABLE_USERS.'` u 
        LEFT JOIN `'.DB_TABLE_USER_SKILLS.'` s
            ON `s`.`userId` = `u`.`id`  
        WHERE `u`.`id` = '.(int)$user['id'];

$check = $db->selectQuery($sql);        
if (empty($check)){
    _e('No such user');
}
$id = (int)$check[0]['id'];
if ($id > 0){

    $account = $db->selectQuery("SELECT * FROM `".DB_TABLE_USER_ACCOUNT."`  WHERE userID = {$id}");
    $details = $db->selectQuery("SELECT * FROM `".DB_TABLE_USER_DETAIL."`   WHERE userId = {$id}");
    
    if($account){
        $values['account'] = $account[0];
    } else {
        $values['account'] = false;
    }

    $values['details'] = $details[0];
    $values['profile'] = $check[0];

    /* 
        tmp fix for incorrect date of births / age mapping in APP  - shows date field 
        1. return age from users table, if not empty
        2. return dob from user_detail, if age empty 
    */        
    
    if (!empty($values['profile']['age'])) {
        $values['details']['dob'] = $check[0]['age'];
    }

    $values['stats'] = getUserStats($id);


    returnResponseAsJson($values);

    die();


} else {
    _e('Invalid user');
}