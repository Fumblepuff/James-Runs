<?php

defined('IS_API') || die('Access Denied');



if (empty($apiRequestData)){
    _e("No data passed");
}

$userID = (int)$apiRequestData['userId'];

if ($userID < 1){
    _e("User ID not passed");
}


$skills = $db->selectQuery(<<<SQL
SELECT 
    `memberType` as skillId, 
    `default` 

FROM 
    `user_skills` 

WHERE
    `userId` = :userId

SQL
, [[':userId', $userID]]);

if (empty($skills))
{
    _e("User has no permissions assigned");
}


$ret = [];

foreach ($skills as $skill)
{
    $ret[$skill['skillId']] = $skill['default'];
}


returnResponseAsJson($ret);

die();

