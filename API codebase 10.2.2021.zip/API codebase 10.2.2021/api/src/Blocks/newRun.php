<?php

// vicvk: this is probably not a new run but a 'newRunGame'

defined('IS_API') || die('Access Denied');


$run    = (int)$apiRequestData['runId'];
$winner = trim($apiRequestData['winner']);
$game   = (int)$apiRequestData['game'];

if($winner == "Home"){
    $team = "Guest";
}else{
    $team = "Home";
}

$newRun = [];
$newRun['runId'] = $run;

$db->insertValue('run_game', $newRun);
$nextGame = $db->insert_id;

$loser = $db->selectQuery('select * from user_team where gameId = '.$game.' and team != "'.$winner.'"');
$home = $db->selectQuery('select * from user_team where gameId = '.$game.' and team = "'.$winner.'"');

foreach ($home as $homeBaller) {    
    $check = $db->selectQuery('SELECT * FROM `'.DB_TABLE_RUN_USER.'` WHERE `userId` = '.$homeBaller['userId'].' AND `runId` = '.$run.' AND `checkIn` = 0 AND `skillId` = '.BALLER_SKILL_ID);
    if(!$check[0]){
        $newHome['runId'] = $run;
        $newHome['gameId'] = $nextGame;
        $newHome['userId'] = $homeBaller['userId'];
        $newHome['team'] = $winner;
        $db->insertValue('user_team', $newHome);
    }
}

foreach ($loser as $baller) {
    $update = $db->selectQuery('SELECT `id` FROM `'.DB_TABLE_RUN_USER.'` WHERE `runId` = '.$run.' AND  `userId` = '.$baller['userId'].' AND `skillId` = '.BALLER_SKILL_ID);
    if ($update){
        $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 0, `bench` = 1, `lastGamePlayed` = NOW() WHERE `id` = '.$update[0]['id']);
    }
}

//pull 5 more ballers to next. 
$next = $db->selectQuery('SELECT `id` FROM `'.DB_TABLE_RUN_USER.'` WHERE `runId` = '.$run.' AND `bench` = 1 AND `checkIn` = 1 AND `skillId` = '.BALLER_SKILL_ID.' ORDER BY `lastGamePlayed` ASC LIMIT 5');

foreach ($next as $nextBaller) {
    $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 0, `bench` = 0, `next` = 1 WHERE `id` = '.$nextBaller['id']);
}

//move 5 next ballers to the game
$guest = $db->selectQuery('SELECT * FROM  `'.DB_TABLE_RUN_USER.'` WHERE `runId` = '.$run.' AND `next` = 1 AND `checkIn` = 1 AND `skillId` = '.BALLER_SKILL_ID.' ORDER BY `lastGamePlayed` ASC LIMIT 5');

foreach ($guest as $guestBaller) {    
    $newGuest['runId'] = $run;
    $newGuest['gameId'] = $nextGame;
    $newGuest['userId'] = $guestBaller['userId'];
    $newGuest['team'] = $team;

    $db->insertValue('user_team', $newGuest);
    $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 1, `next` = 0 WHERE `id` = '.$guestBaller['id']);
}

//check who's left in next
$check = $db->selectQuery('SELECT COUNT(id) AS cnt FROM `'.DB_TABLE_RUN_USER.'` WHERE `runId` = '.$run.' AND `next` = 1 AND `checkIn` = 1 AND `skillId` = '.BALLER_SKILL_ID.' ORDER BY `lastGamePlayed`, `checkInDate`');

//If there are less than 5 ballers in next then we need to pull more from bench
if($check[0]['cnt'] < 5){
    
    $limit = 5 - $check[0]['cnt'];
    $ballers = $db->selectQuery('SELECT * FROM `'.DB_TABLE_RUN_USER.'` WHERE `runId` = '.$run.' AND `bench` = 1 AND `checkIn` = 1 AND `skillId` = '.BALLER_SKILL_ID.' ORDER BY `lastGamePlayed`, `checkInDate` ASC LIMIT '.$limit);

    foreach ($ballers as $baller) {
        $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 0, `bench` = 0 , `next` = 1 WHERE `id` = '.$baller['id']);
    }
}

//If there are more than 5 ballers in next then we need to remove them
if($check[0]['cnt'] > 5){
    
    $limit = $check[0]['cnt'] - 5;
    $ballers = $db->selectQuery('SELECT * FROM `'.DB_TABLE_RUN_USER.'` WHERE `runId` = '.$run.' AND `next` = 1 AND `checkIn` = 1 AND `skillId` = '.BALLER_SKILL_ID.' ORDER BY `lastGamePlayed`, `checkInDate` DESC LIMIT '.$limit);

    foreach ($ballers as $baller) {
        $db->selectQuery('UPDATE `'.DB_TABLE_RUN_USER.'` SET `active` = 0, `bench` = 1 , `next` = 0 WHERE `id` = '.$baller['id']);
    }
}

returnResponseAsString($nextGame);


