<?php

/*

vicvk: registers user.

Array
(
    [type] => registerUser
    [data] => Array
        (
            [firstName] => Victor
            [lastName] => Klimov
            [email] => victor.klimov@gmail.com
            [password] => 
            [city] => empty
            [state] => empty
            [zipcode] => 000
            [phone] => 000
            [gender] => no
            [type] => 4
            [skillId] => 3
        )

)


*/

defined('IS_API') || die('Access Denied');

$required = array
(
    'firstName', 
    'lastName',
    'email',
    'phone'
);

$notRequired = ["password","city","state","zipcode","gender"];


foreach ($required as $field)
{
    if (empty($apiRequestData[$field]))
    {
        _e($field.' missing');
    } 
    else 
    {
        if ($field != 'email'){
            ${$field} = trim($apiRequestData[$field]);
            if (!${$field}){
                _e("Invalid {$field}");
            }                                                                        
        } else {
            if ($field == 'email'){

                ${$field} = filter_var($apiRequestData['email'],FILTER_VALIDATE_EMAIL);
                if (!${$field}){
                    _e("Invalid {$field}");
                }                    
            }
        }
    }
}
                        
$check = $db->selectQuery('SELECT id FROM `users` WHERE email = "'.$email.'"');

if($check)
{
    _e('User already exists');                              
} 
else
{
    $insert = array();
    $type = !empty($apiRequestData['type']) ? $apiRequestData['type'] : 0;
    $insert['type'] = $type > 0 ? $type : DEFAULT_USER_LEVEL;

    $skillId = !empty($apiRequestData['skillId']) ? $apiRequestData['skillId'] : BALLER_SKILL_ID;

    foreach ($required as $field)
    {
        $insert[$field] = $apiRequestData[$field];
    }


    foreach ($notRequired as $field)
    {
        $v = apiRequestData($field);

        if ($v !== null)
        {
            $insert[$field] = $v;
        }
    }


    $db->insertValue('users', $insert);
    $id = $db->pdo->lastInsertId();            

    if ($id > 0){

        /* default record in run users table, possible will not be needed later*/
        /* 02 March 2021 - commenting out - seems to be unneeded any more */
        //$db->insertValue(DB_TABLE_RUN_USER,['userId' => $id,'runId' => 0 ,'skillId' => -1]);

        /* default record in user skills, to assing skill*/
        $db->selectQuery("INSERT INTO `user_skills` (`userId`,`memberType`,`default`) VALUES({$id},{$skillId},1)");
               
        /* isert user detail record, if needed */
        $check = $db->selectQuery('SELECT id FROM `user_detail` WHERE userId = "'.$id.'"');

        if(empty($check))
        {  
            $db->selectQuery("INSERT INTO `user_detail` (`userId`) VALUES ({$id})");
        }

        returnResponseAsString($id);
        die();

    } else {
        _e("Failed to create user");
    }

}
