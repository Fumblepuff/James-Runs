<?php

defined('IS_API') || die('Access Denied');

$runId = (int)$apiRequestData['runId'];
$uid = (int)$apiRequestData['userId'];
$skill_id = (int)$apiRequestData['skillId'];

if ($runId < 1){
    _e('Game ID must be passed');
} elseif ($uid < 1) {
    _e("User ID must be passed");
}

$allow_game_ended = 1;

/* check if game exists */
$game = $db->selectQuery("SELECT id,runEnd,endDate,runScheduleUtc FROM `".DB_TABLE_RUNS."` WHERE id = {$runId}");

if (empty($game)){
    _e('Game does not exist');
} else {
    /* check if game ended */
    $game = $game[0];

    if (!$allow_game_ended && ($game['runEnd'] == 1 || strtotime($game['runScheduleUtc']) < time()))
    {
        _e('Game already ended');
    } 
    else 
    {
        /* check if user exists */
        $user = $db->selectQuery("SELECT id,type FROM `".DB_TABLE_USERS."` WHERE id = {$uid}");
        if (empty($user)){
            _e('User does not exist');
        } else {

            if ($skill_id  < 1 ){
               $skill_id = $user[0]['type'];
            }


            $check_sql = "SELECT `id`,COUNT(*) AS `total` FROM `".DB_TABLE_RUN_USER."` WHERE `userId`={$uid} AND `skillId`={$skill_id} AND `runId` = {$runId} LIMIT 1";
   
            $check = $db->selectQuery($check_sql);  
            $before_spots = $check[0]['total'];
            
            if ($before_spots == 0){
                _e('You have no such spot reserved'); 
            } else {


                /* delete spot - deleting 1 spot by id */                

                $db->selectQuery("UPDATE `".DB_TABLE_RUN_USER."` SET `userId` = -1, checkIn = 0, reserve = 0 WHERE `id`= {$check[0]['id']}");

                /* recheck if spot has been deleted */        
                $recheck = $db->selectQuery($check_sql);    
                $after_spots = $recheck[0]['total'];
                
                if ($before_spots-1 == $after_spots){
                    _s('Spot has been unreserved');
                } else {
                    _e('Failed to unreserve spot. Please try again');
                }                        
            }


        }
    }
}

/* should not go to this place */
_e("Software error");


