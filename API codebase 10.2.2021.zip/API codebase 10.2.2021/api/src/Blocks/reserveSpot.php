<?php

defined('IS_API') || die('Access Denied');

$runId = (int)$apiRequestData['runId'];
$uid = (int)$apiRequestData['userId'];
$skill_id = (int)$apiRequestData['skillId'];


// implemented later on - we must check against user_skills table that this user actually posesses this skill.

/* temporarily allowing multiple spots for the same user*/
$skip_spot_checks = false;

if ($runId < 1) {
    _e('Game ID required');        
} elseif ($uid < 1){
    _e('User ID required');
} else {
    /* check if game exists */
    $game = $db->selectQuery("SELECT id, runEnd, endDate, runScheduleUtc FROM `runs` WHERE id = {$runId}");
    if (empty($game)){
        _e('Game does not exist');
    } else {
        $game = $game[0];   
        /* 
            check if game ended 
            was endDate, which has no sense, as is automatically CURRENT timestamp,
            so upon adding game, it is already in the past
        */    
        if ($game['runEnd'] == 1 || strtotime($game['runScheduleUtc']) < time()){
            _e('Game already ended');
        } else {

            /* check if user exists */
            $user = $db->selectQuery("SELECT id, type FROM `users` WHERE id = {$uid}");
            if (empty($user)){
                _e('User does not exist');
            } else {

                if ($skill_id > 0){

                    // it is correct that we assign a $skill_id here, but
                    // why we selected user.type if we are not using it?
                    $user[0]['type'] = $skill_id;
                }



                $check = $db->selectQuery("SELECT `run_user`.`id`, `longName` FROM `run_user` INNER JOIN `skills` ON `skills`.`id` = `skillId` WHERE `runId` = {$runId} AND `userId` = {$uid} AND `skillId` = {$user[0]['type']}");


                if (!$skip_spot_checks && !empty($check)){
                    _e('You have already reserved spot '.$check[0]['longName'].' for this game');
                } 
                else 
                {
                    $skillData = lookupSkillById($user[0]['type']);

                    if (!is_array($skillData))
                    {
                        _e("Skill (id={$user[0]['type']}) is not found in database");
                    }

                    $skillNameThatWeAreTryingToReserve = $skillData['longName'];

                    if ($skillData['reserve'] <= 0)
                    {
                        _e("Skill '{$skillNameThatWeAreTryingToReserve}' cannot be reserved");
                    }


                    $skill_allowed_to_user = $db->selectQuery("SELECT `memberType` FROM `user_skills` WHERE `userId` = {$uid} AND `memberType` = {$user[0]['type']}");

                    if (empty($skill_allowed_to_user))
                    {
                        _e("You don't have permission to reserve skill '{$skillNameThatWeAreTryingToReserve}'");
                    }
                        

                    $spots_sql = "SELECT 
                            (SELECT COUNT(*) FROM `run_user` WHERE `runId` = {$runId} AND `skillId` = {$user[0]['type']}  AND `userId` > 0 ) AS used, 
                            (SELECT COUNT(*) FROM `run_user` WHERE `runId` = {$runId} AND `skillId` = {$user[0]['type']}) AS spots_needed 
                        FROM `run_user` 
                        ORDER BY `id` ASC 
                        LIMIT 1";



                        $spots = $db->selectQuery($spots_sql);

                        if (!$skip_spot_checks  &&   (empty($spots) || ($spots[0]['spots_needed'] - $spots[0]['used'] < 1))) {

                            _e("No available spots left for '{$skillNameThatWeAreTryingToReserve}'");

                        } else {


                            /* all checks passed, can reserve spot  - again, use PASSED skill id as priority!! */                                                        
                            $db->selectQuery(<<<SQL
UPDATE 
    `run_user` 

SET 
    `userId` = {$uid}, 
    `reserve` = 1,  
    `reserveDate` = NOW() 

WHERE 
    `runId` = {$runId} 
      AND 
    `skillId` = {$user[0]['type']}
      AND 
    `userId` = -1 

LIMIT 1

SQL
);   
                             
          
                            /* recheck if user has been added */

                            $recheck = $db->selectQuery(<<<SQL
SELECT 
    id 

FROM 
    `run_user` 

WHERE 
    `runId` = {$runId} 
      AND 
    `skillId` = {$user[0]['type']} 
      AND 
    `userid`={$uid}

SQL
);

                            if (!empty($recheck)){
                                _s('Spot has been reserved');
                            } else {
                                _e('Error reserving spot. Please try again');                            
                            }                      
                        }

                }
            }
        }
    }
}

