<?php

/*

vicvk:   updates user  (admin panel, users, select user, edit user)

Array
(
    [type] => updateUser
    [data] => Array
        (
            [id] => 2940
            [firstName] => qqqqq
            [lastName] => wwwww
            [email] => e@cccggg.com
            [password] => Qwerty11
            [zipcode] => 44444
            [phone] => 55896558885
            [type] => 3
        )

)

*/


defined('IS_API') || die('Access Denied');


if (!empty($apiRequestData['skills'])){
    
    foreach ($apiRequestData['skills'] as $uid => $update){
        
        /* check, if user exists */
        $user = $db->selectQuery("SELECT id FROM `".DB_TABLE_USERS."` WHERE id = {$uid}");
        if (empty($user)){
            _e('User does not exist');
        }

        foreach($update as $field => $val){
            if ($field == 'skillId'){
 
                $skill = $db->selectQuery("SELECT id FROM `".DB_TABLE_SKILLS."` WHERE id = {$val}");
                if (empty($skill)){
                    _e('Skill does not exist');
                }                
                            
                $db->selectQuery("UPDATE `".DB_TABLE_USER_SKILLS."` SET `memberType` = {$val} WHERE `userId` = {$uid}");

            /* old compatibility - remove member_type after completing rewriting to prod DB */    
            } elseif ($field == 'member_type' || $field == 'type'){
                
                $type = $db->selectQuery("SELECT id FROM `".DB_TABLE_MEMBER_TYPES."` WHERE id = {$val}");
                if (empty($type)){
                    _e('Type does not exist');
                }                                 
                $db->updateValue(DB_TABLE_USERS, 'type', $val, $uid);               
            } 
         }    
    }        
    _s();
     
} else {

    $id                 = (int)$apiRequestData['id'];
    $skillId            = (int)$apiRequestData['skillId'];

    $update_details = [];
    $update_users   = [];

    if ($id > 0 ) {

        $users_fields = [
            'firstName','lastName','email','phone',
            'city','state','zipcode','type','password',
            'image','imageLocal','imageName','longitude',
            'latitude','age','gender','text','active'
        ];

        $details_fields = [
            'jersey','ballerTag','position','occupation','dob','highestLevelOfPlay',
            'referralSource','message','memberRating','latitude','longtitude',
            'gmtOff','dstOff','timezone'            
        ];

        foreach ($users_fields as $field){
            if (!empty(trim($apiRequestData[$field]))){
                $update_users[$field] = trim($apiRequestData[$field]);
            }
        }

        foreach ($details_fields as $field){
            if (!empty(trim($apiRequestData[$field]))){
                $update_details[$field] = trim($apiRequestData[$field]);
            }
        }

        if (!empty($update_details['dob']) && empty($update_users['age'])){
            $update_users['age'] = $update_details['dob'];
        }

        if (!empty($update_users)){
            $db->updateValues(DB_TABLE_USERS,$update_users,['id' => $id]);
        }
        
        if (!empty($update_details)){
            $db->updateValues(DB_TABLE_USER_DETAIL,$update_details,['userId' => $id]);
        }

        if (!empty($skillId)){
            $db->selectQuery("UPDATE `".DB_TABLE_USER_SKILLS."` SET `memberType` = {$skillId} WHERE `userId` = {$id}");
        }
    } 
}