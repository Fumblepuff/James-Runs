<?php

/*

vicvk:   updates user skills  (admin panel, users, select user, edit user)


Array
(
    [type] => updateUserPermissions
    [data] => Array
        (
            [set] => 2940
            [permissions] => Array
                (
                    [0] => 34
                    [1] => 5
                    [2] => 24
                )

        )

)

*/

/* updates user permissions to reserve specific skills */

defined('IS_API') || die('Access Denied');


if (empty($apiRequestData)){
    _e("No data passed");
}

$set = $apiRequestData['set'];
$unset = $apiRequestData['unset'];

if (!isset($set) && !isset($unset)){
    _e("Set no unset parameter required");
}

$userID = (int)($apiRequestData['set'] ? $apiRequestData['set'] : $apiRequestData['unset']);
if ($userID < 1){
    _e("User ID not passed");
}

$permissions = $apiRequestData['permissions'];
if (empty($permissions)){
    _e("No permissions passed");    
}

/* check if user exists */
$check = $db->selectQuery("SELECT `id` FROM `".DB_TABLE_USERS."` WHERE `id` = {$userID}");
if (empty($check)){
    _e("User does not exist");
}

/* add permissions */
if (isset($apiRequestData['set'])){
    foreach ($permissions as $skillId){

        $skillId = (int)$skillId;    
        if ($skillId < 1) {
            continue;
        }

        $skill_allowed = $db->selectQuery("SELECT id FROM `skills` WHERE `id` = {$skillId} AND `reserve` = 1");

        if (!$skill_allowed)
        {
            _e("You are not allowed to set this skill ({$skillId}) because (skills.reserve != 1) for the given skill");
        }

        $db->selectQuery("INSERT IGNORE INTO `user_skills` (`userId`,`memberType`,`default`) VALUES({$userID},{$skillId},0)");
    }

/* remove permissions */
}
elseif (isset($apiRequestData['unset']))
{
    foreach ($permissions as $skillId) 
    {
        $skillId = (int)$skillId;

        if ($skillId < 1) {
            continue;
        }

        // check that we are not trying to unset default skill

        $r = $db->selectQuery("SELECT * FROM `user_skills` WHERE `userId` = {$userID}  AND `memberType` = {$skillId} AND `default` != 0");

        if (is_array($r))
        {
            foreach($r as $r0)
            {
                $skill = $db->selectQuery("SELECT * FROM `skills` WHERE `id` = {$r0['memberType']}");


                _e("Can't unset permission '{$skill[0]['longName']}' (permissionId={$r0['memberType']}) from user (userId={$r0['userId']}) because this permission is set as default for this user");
            }
        }

        $db->selectQuery("DELETE FROM `user_skills` WHERE `userId` = {$userID}  AND `memberType` = {$skillId} AND `default` = 0");

        $db->selectQuery($query);
    }
}

_s();
