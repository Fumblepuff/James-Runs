<?php
namespace App;

use Exception;

class DataValidationException extends Exception
{

}
