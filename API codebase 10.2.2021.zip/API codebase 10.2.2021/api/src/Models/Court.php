<?php
namespace App\Models;


class Court extends BaseModel
{
    protected $table = 'courts';

    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',
        'image',
        'name',
        'address',
        'city',
        'state',
        'zipcode',
        'longitude',
        'latitude',
        'timezone',
    ];


    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    //protected $appends = ['is_admin'];
    //protected $appends = ['image'];



    // https://laravel.com/docs/8.x/eloquent-serialization#date-serialization


    public function runs()
    {
        return $this->hasMany(Run::class, 'courtId', 'id');
    }


// when doing joins we must retrieve a court even if its not active, so these scopes shouldn't be global
//
//    protected static function booted()
//    {
//        static::addGlobalScope('isActiveAndHasAName', function (Builder $builder)
//        {
//            $builder->where('active', '=', 1)->where('name', '!=', '');
//        });
//    }



    public function scopeByName($query, String $searchInName)
    {
        if (strlen($searchInName) <= 2)
        {
            // search from name beginning if 2 characters or less
            return $query->where('name', 'LIKE', "{$searchInName}%");
        }
        else
        {
            return $query->where('name', 'LIKE', "%{$searchInName}%");
        }
    }


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }

    public function scopeHasAName($query)
    {
        return $query->where('name', '!=', '');
    }



    // NYI - temporary
    //public function getIsAdminAttribute()
    //{
    //    //return $this->attributes['admin'] === 'yes';
    //    return 'yes';
    //}


    public function getTimezoneAttribute()
    {
        // if timezone for any reason is null, we don't want other logic to fail.
        return ($this->attributes['timezone'] === null) ? 'America/New_York' : $this->attributes['timezone'];
    }






}
