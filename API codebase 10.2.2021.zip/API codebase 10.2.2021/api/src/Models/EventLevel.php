<?php
namespace App\Models;

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Eloquent\Collection;

class EventLevel extends BaseModel
{
    protected $table = 'game_level';


    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',
        'name',
        'shortName',
    ];


    #
    # returns a collection of EventLevelService objects. Each object already has 'service' relation eager loaded, access it like this:
    # $gls = $eventLevel->getEventLevelServices();
    # print_r($gls[0]->service->name);  // service is an object of Service class
    # all services are selected with service_game_level.active=1 AND service.active=1
    #
    public function getEventLevelServices(): Collection   //tested
    {
        //Capsule::connection()->enableQueryLog();

        $r = $this->eventLevelServices()
                  ->isActive()
                  ->with(['service' => function ($query) { $query->isActive(); }])
                  ->orderBy('serviceId', 'asc')
                  ->get();

        //$queries = Capsule::getQueryLog();
        //print_r($queries);

        return $r;
    }

    public function getEventLevelServicesArrayIndexedById(): Array
    {
        $services = $this->getEventLevelServices();

        $result = [];

        foreach($services as $service)
        {
            $result[$service->serviceId] = $service;
        }

        return $result;
    }

    public function eventLevelServices()   //tested
    {
        return $this->hasMany(EventLevelService::class, 'gameLevelId', 'id');
    }


    public function scopeIsActive($query)
    {
        return $query->where('id', '>', 0);
    }


    public static function getAllActive()
    {
        return self::isActive()->get();
    }

}

