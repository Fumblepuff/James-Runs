<?php
namespace App\Models;


class EventLevelService extends BaseModel
{
    protected $table = 'service_game_level';

    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        // 'id',  <-- this is just a service_game_level.id we do not use at anywhere. We use "service.id" for services being ordered.
        'price',
        'payRate',
        'service',
    ];


    public function service()  //tested
    {
        return $this->belongsTo(Service::class, 'serviceId', 'id');
    }


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }

}

