<?php
namespace App\Models;


class EventRequest extends BaseModel
{
    const FULFILLMENT_STATUS_NO_STAFFERS = 'NoStaffers';
    const FULFILLMENT_STATUS_CREATING = 'Creating';
    const FULFILLMENT_STATUS_CREATED = 'Created';
    const FULFILLMENT_STATUS_FULFILLED = 'Fulfilled';
    const FULFILLMENT_STATUS_CANCELLED = 'Cancelled';


    protected $table = 'event_requests';



/*
    public function run()
    {
        return $this->belongsTo(Run::class, 'runId', 'id');
    }
*/

    public function items()
    {
        return $this->hasMany(EventRequestItem::class, 'eventRequestId', 'id');
    }

    public function ownerUser()
    {
        return $this->belongsTo(User::class, 'ownerUserId', 'id');
    }

    public function homeTeamScoreBookFile()
    {
        return $this->belongsTo(File::class, 'homeTeamScoreBookFileId', 'id');
    }

    public function guestTeamScoreBookFile()
    {
        return $this->belongsTo(File::class, 'guestTeamScoreBookFileId', 'id');
    }



    public function eventType()
    {
        return $this->belongsTo(EventType::class, 'eventTypeId', 'id');
    }


    public function court()
    {
        return $this->belongsTo(Court::class, 'courtId', 'id');
    }


    public function league()
    {
        return $this->belongsTo(League::class, 'leagueId', 'id');
    }


    public function eventLevel()
    {
        return $this->belongsTo(EventLevel::class, 'gameLevelId', 'id');
    }

    public function homeTeam()
    {
        return $this->belongsTo(Team::class, 'homeTeamId', 'id');
    }

    public function guestTeam()
    {
        return $this->belongsTo(Team::class, 'guestTeamId', 'id');
    }


    public function run()
    {
        return $this->hasOne(Run::class, 'id', 'runId');
    }


    public function isOwnedBy(User $user)
    {
        return ($this->ownerUserId === $user->id);
    }


    public function scopeIsActive($query)
    {
        return $query->where('id', '>', 0);
    }


    public function calculateOrderTotalsWithAllServices()
    {
        $result = [];

        $subTotal = 0;

        foreach($this->items as $item)
        {
            $subTotal += $item->price * $item->quantity;
        }

        $result['subTotal'] = $subTotal;
        $result['discount'] = 0;
        $result['tax'] = 0;
        $result['grandTotal'] = $result['subTotal'] - $result['discount'] + $result['tax'];

        return $result;
    }


    public function calculateOrderTotalsWithActuallyReservedServices()
    {
        // NYI
    }


    // accepts integer $serviceId because a service model may not exist, but we still should be able to 
    // remove associated record from event_request_items.serviceId == $serviceId
    public function removeServiceById(int $serviceId)
    {
        $this->items()->where('serviceId', '=', $serviceId)->delete();
    }

    public function removeAllItems()
    {
        $this->items()->delete();
    }


    // accepts an object $service because the EventService model must exist to be able to add it to event request
    // and we also need price from the EventService model
    public function addEventLevelService(EventLevelService $gls, Array $options)
    {
        $item = $this->items()->where('serviceId', '=', $gls->service->id)->first();

        if (!$item)
        {
            $item = new EventRequestItem;
            $item->serviceId = $gls->service->id;
        }

        $item->options = $options;

        $price = $gls->price;
        $quantity = 1;

        Service::adjustPriceAndQuantityForSelectedOptions($item->serviceId, $options, $price, $quantity);

        $item->price = $price;
        $item->quantity = $quantity;

        $this->items()->save($item);
    }


    public function getEventLevelIdAttribute()
    {
        return $this->attributes['gameLevelId'];
    }

    public function setEventLevelIdAttribute($value)
    {
        $this->attributes['gameLevelId'] = $value;
    }


}
