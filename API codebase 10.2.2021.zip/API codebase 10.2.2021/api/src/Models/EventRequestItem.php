<?php
namespace App\Models;


class EventRequestItem extends BaseModel
{
    protected $table = 'event_request_items';



    public function getOptionsAttribute()
    {
        if ($this->attributes['optionsJson'] == '')
        {
            return [];
        }

        $r = json_decode($this->attributes['optionsJson'], true);

        if (!is_array($r) || empty($r))
        {
            return [];
        }

        return $r;
    }

    public function setOptionsAttribute($value)
    {
        $this->attributes['optionsJson'] = json_encode($value);
    }

}

