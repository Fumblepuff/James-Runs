<?php
namespace App\Models;


class EventType extends BaseModel
{
    protected $table = 'event_type';


    public function scopeIsActive($query)
    {
        return $query->where('id', '>', 0);
    }

}

