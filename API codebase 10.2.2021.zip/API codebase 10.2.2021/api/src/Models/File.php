<?php
namespace App\Models;

use Exception;

class File extends BaseModel
{
    protected $table = 'files';

    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',

        #'ownerUserId',

        'uploadType',
        'size',

        'url',
    ];


    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['url'];


    public function ownerUser()
    {
        return $this->belongsTo(User::class, 'ownerUserId', 'id');
    }


    public function getUrlAttribute()
    {
        return $this->attributes['localUrl'];
    }




    ##############################################################################################################
    ##############################################################################################################
    ##############################################################################################################

    public static function createFromUpload(String $uploadType, int $ownerUserId)
    {
        global $config;

        $f = new self;

        $f->ownerUserId = $ownerUserId;
        $f->uploadType = $uploadType;
        $f->originalName = basename($_FILES['file']['name']);
        $f->originalType = $_FILES['file']['type'];
        $f->size = $_FILES['file']['size'];
        $f->storedAsName = '';
        $f->localUrl = '';
        $f->remoteUrl = '';

        $f->save(); // because we need id

        $extension = extractFileExtension($_FILES['file']['name']);
        if ($extension != '')
        {
            $extension = '.' . $extension;
        }

        $storedAsName = $f->id . '-' . mt_rand(0, 1000000000000) . '-' . mt_rand(0, 1000000000000) . $extension;

        # NYI - must create subdirectories with 10000 files per subdirectory
        $newFilePath = $config['uploads']['root_dir'];


        if (move_uploaded_file($_FILES['file']['tmp_name'], $newFilePath.$storedAsName))
        {
            //echo "File is valid, and was successfully uploaded.\n";

            $f->storedAsName = $storedAsName;
            $f->localUrl = $f->calculateLocalUrl();
            $f->remoteUrl = '';

            $f->save();
        }
        else
        {
            //echo "Possible file upload attack!\n";

            $f->delete();

            throw new Exception('Failed to move uploaded file to permanent location');
        }

        // remove from temp location - probably not needed but just in case
        @unlink($_FILES['file']['tmp_name']);

        return $f;
    }


    protected function calculateLocalUrl()
    {
        global $config;

        return $config['uploads']['url'] . $this->storedAsName;
    }

    protected function reCacheLocalUrl()
    {
// NYI

// $f->localUrl

    }


    public function isOwnedBy(User $user)
    {
        return ($this->ownerUserId === $user->id);
    }

    public function isOfUploadType(String $uploadType)
    {
        return ($this->uploadType === $uploadType);
    }


}

