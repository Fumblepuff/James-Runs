<?php
namespace App\Models;


class League extends BaseModel
{
    protected $table = 'league';


    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',
        'name',
        'shortName',
        'eventLevelId',
    ];



    public function scopeIsActive($query)
    {
        return $query->where('id', '>', 0);
    }

    public static function getAllActive()
    {
        return self::isActive()->get();
    }




    public function getEventLevelIdAttribute()
    {
        return $this->attributes['gameLevelId'];
    }

    public function setEventLevelIdAttribute($value)
    {
        $this->attributes['gameLevelId'] = $value;
    }


}

