<?php
namespace App\Models;


class PotentialStafferReferral extends BaseModel
{
    protected $table = 'potential_staffer_referrals';


    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',
        'referrerUserId',
        'eventRequestId',
        'firstName',
        'lastName',
        'email',
        'phoneNumber',
    ];



}
