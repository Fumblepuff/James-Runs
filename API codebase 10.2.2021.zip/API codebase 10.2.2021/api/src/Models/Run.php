<?php
namespace App\Models;


// NYI - must be renamed to Event
class Run extends BaseModel
{
    protected $table = 'runs';


    public static function createNewRun(Court $court, String $dateTimeInCourtTimeZone, $runType=1): self
    {
        $dt = convertDateTimeToUtc($dateTimeInCourtTimeZone, $court->timezone);
        $dt = setZeroSecondsOnDateTime($dt);

        $run = new static;

        $run->runSchedule = $dateTimeInCourtTimeZone;
        $run->runScheduleUtc = $dt;

        $court->runs()->save($run);

        return $run;
    }


    public function court()
    {
        return $this->belongsTo(Court::class, 'courtId', 'id');
    }


    public function runGames()
    {
        return $this->hasMany(RunGame::class, 'runId', 'id');
    }


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }

}

