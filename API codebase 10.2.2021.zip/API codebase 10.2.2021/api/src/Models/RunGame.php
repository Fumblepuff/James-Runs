<?php
namespace App\Models;


class RunGame extends BaseModel
{
    protected $table = 'run_game';



    public function run()
    {
        return $this->belongsTo(Run::class, 'runId', 'id');
    }


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }



}
