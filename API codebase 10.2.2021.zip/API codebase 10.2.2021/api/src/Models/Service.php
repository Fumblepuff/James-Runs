<?php
namespace App\Models;


class Service extends BaseModel
{
    protected $table = 'service';


    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',
        'name',

///        "serviceTypeId": 2,
///        "skillId": 20,
    ];


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }


    public function skill()  //tested
    {
        return $this->belongsTo(Skill::class, 'skillId', 'id');
    }


    public static function getAvailableOptions(int $serviceId)
    {
        $result = [];
        $result['options'] = [];
        $result['optionsType'] = null;

        if (($serviceId == 17) || ($serviceId == 20))
        {
            $result['options'] = [
                ['id' => 1, 'name' => 'Home'],
                ['id' => 2, 'name' => 'Guest'],
                ['id' => 3, 'name' => 'Both'],
            ];

            $result['optionsType'] = 'radio';
        }

        return $result;
    }


    // possible values for $options = [],  $options = [1], $options = [1,3]
    public static function adjustPriceAndQuantityForSelectedOptions(int $serviceId, Array $options, &$price, &$quantity)
    {
        if (($serviceId == 17) || ($serviceId == 20))
        {
            # for this $serviceId $options should be an array with a single value: 1 (Home), 2 (Guest), 3 (Both)

            if (isset($options[0]) && ($options[0] == 3))
            {
                $quantity = 2;
            }
        }
    }

    public static function validateOptions(int $serviceId, Array $options, Array &$errors)
    {
//echo "#{$serviceId}#";
//print_r($options);

        if (($serviceId == 17) || ($serviceId == 20))
        {
            # for this $serviceId $options should be an array with a single value: 1 (Home), 2 (Guest), 3 (Both)

            if ($options == [])
            {
                $errors[] = "For service '" . Service::find($serviceId)->name  . "' (id={$serviceId}) an option is required";
            }
            elseif (($options == [1]) || ($options == [2]) || ($options == [3]))
            {
                // all ok
            }
            else
            {
                $errors[] = "For service '" . Service::find($serviceId)->name  . "' (id={$serviceId}) valid option values are: 1, 2, 3. Only one selected option is allowed.";
            }
        }
        elseif ($options != [])
        {
            $errors[] = "For service '" . Service::find($serviceId)->name  . "' (id={$serviceId}) no options are allowed";
        }
    }

}


