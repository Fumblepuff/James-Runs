<?php
namespace App\Models;


class Skill extends BaseModel
{
    protected $table = 'skills';

    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',
        'longName',
    ];


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }

}
