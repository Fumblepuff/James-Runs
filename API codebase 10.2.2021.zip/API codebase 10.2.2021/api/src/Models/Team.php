<?php
namespace App\Models;


class Team extends BaseModel
{
    protected $table = 'team';


    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',
        'name',
        'shortName',
    ];


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }

    public function scopeByName($query, String $searchInName)
    {
        if (strlen($searchInName) <= 3)
        {
            // search from name beginning if 3 characters or less
            return $query->where('name', 'LIKE', "{$searchInName}%");
        }
        else
        {
            return $query->where('name', 'LIKE', "%{$searchInName}%");
        }
    }

    public function scopeByExactNameCaseInsensitive($query, String $s)
    {
        return $query->where('name', '=', $s);
    }

    public function scopeHasAName($query)
    {
        return $query->where('name', '!=', '');
    }


}

