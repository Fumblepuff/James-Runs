<?php
namespace App\Models;

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Eloquent\Collection;
use Stripe\Customer as StripeCustomer;


class User extends BaseModel
{
    protected $table = 'users';

    /**
     * The attributes that should be visible in arrays.
     *
     * @var array
     */
    protected $visible = [
        'id',

        'firstName',
        'lastName',

        'city',
        'state',
        'zipcode',

        'email',
        'phone',
    ];


    // NYI functions:   grantSkill()    revokeSkill()



    #
    # returns a collection of UserSkill objects. Each object already has 'skill' relation eager loaded, access it like this:
    # $us = $user->getUserSkills();
    # print_r($us[0]->skill->longName);  // skill is an object of Skill class
    # all skills are selected with user_skills.active=1 AND skills.active=1
    #
    public function getUserSkills(): Collection   //tested
    {
        //Capsule::connection()->enableQueryLog();

        $r = $this->userSkills()
                  ->isActive()
                  ->with(['skill' => function ($query) { $query->isActive(); }])
                  ->orderBy('skillId', 'asc')
                  ->get();

        //$queries = Capsule::getQueryLog();
        //print_r($queries);

        return $r;
    }


    public function userSkills()  //tested
    {
        return $this->hasMany(UserSkill::class, 'userId', 'id');
    }


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }


    #// $skills is an array of objects of Skill class
    #// maybe not much needed yet. Will try to use hasSkill()
    #public function hasAnyOfTheseSkills(Array $skills): boolean
    #{
    #    // NYI
    #    return true;
    #}
   
    public function hasSkill(Skill $skill): bool  //tested
    {
        $userSkillsCollection = $this->getUserSkills();

        //return $userSkillsCollection->contains($skill); <- this won't work

        foreach($userSkillsCollection as $us)
        {
            if ($us->skill->id == $skill->id)
            {
                return true;
            }
        }

        return false;
    }

    public function canUploadFiles()
    {
        // NYI
        return true;
    }


    public static function staffersExistWithinMilesRadius(Array $latLong, $radiusMiles)
    {
        // NYI
        //staffersExistWithinMilesRadius(['latitude' => $this->court->latitude, 'longitude' => $this->court->longitude], $radiusMiles);

        return true;
    }




    public function getStripeCustomer() :StripeCustomer
    {
        $stripe = my_app('stripe');

        if (empty($this->stripeCustomerId))
        {
            $customer = $stripe->customers->create([
                'metadata' => [
                    'userId' => "{$this->id}",
                ],
            ]);

            $this->stripeCustomerId = $customer->id;
            $this->save();
        }
        else
        {
            $customer = $stripe->customers->retrieve($this->stripeCustomerId, []);

            if (empty($customer))
            {
                $customer = $stripe->customers->create([
                    'metadata' => [
                        'userId' => "{$this->id}",
                    ],
                ]);

                $this->stripeCustomerId = $customer->id;
                $this->save();
            }
        }

        return $customer;
    }



    public function savePaymentMethod(String $paymentMethod): void
    {
        $this->stripePaymentMethod = $paymentMethod;
        $this->save();
    }

}
