<?php
namespace App\Models;


class UserSkill extends BaseModel
{
    protected $table = 'user_skills';



    public function skill()   //tested
    {
        return $this->belongsTo(Skill::class, 'skillId', 'id');
    }


    public function scopeIsActive($query)
    {
        return $query->where('active', '=', 1)->where('id', '>', 0);
    }

}

