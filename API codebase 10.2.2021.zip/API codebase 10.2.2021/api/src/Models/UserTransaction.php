<?php
namespace App\Models;

use Stripe\Event as StripeEvent;


class UserTransaction extends BaseModel
{
    protected $table = 'user_transactions';


    public static function findByPurchase(String $whatIsPurchased, Array $purchaseDetails)
    {
        return static::where('whatIsPurchased', '=', $whatIsPurchased)
                     ->where('purchaseDetailsJson', '=', static::encodePurchaseDetailsToJson($whatIsPurchased, $purchaseDetails))
                     ->first();
    }

    protected static function encodePurchaseDetailsToJson(String $whatIsPurchased, Array $purchaseDetails)
    {
        $data = [];

        switch ($whatIsPurchased)
        {
            case 'GameRequest':
            case 'RunRequest':
                $data['eventRequestId'] = isset($purchaseDetails['eventRequestId']) ? $purchaseDetails['eventRequestId'] : null;
                break;

            default:
                throw new Exception("whatIsPurchased doesn't have a supported value");
        }

        return json_encode($data);
    }

    public function setPurchaseDetailsAttribute(Array $purchaseDetails)
    {
        $this->attributes['purchaseDetailsJson'] = static::encodePurchaseDetailsToJson($this->attributes['whatIsPurchased'], $purchaseDetails);
    }

    public function getPurchaseDetailsAttribute()
    {
        return json_decode($this->attributes['purchaseDetailsJson'], true);
    }



    public static function handleStripeEvent(StripeEvent $event)
    {
apiLogMessage('handleStripeEvent');

        // we are only interested to process these event types:
        if (!in_array($event->type, [
            'payment_intent.succeeded', 
            'payment_intent.amount_capturable_updated', 
            'payment_intent.canceled',

            'charge.refunded',  // data.object is a charge. Occurs whenever a charge is refunded, including partial refunds.
        ]))
        {
            returnResponseAsString("Not handled: {$event->type}", 200);
            return;
        }


        $obj = $event->data->object; // contains a \Stripe\PaymentIntent or \Stripe\Charge

        # metadata is present both on \Stripe\PaymentIntent and \Stripe\Charge
        $eventUserId = $obj->metadata['userId'];
        $eventWhatIsPurchased = $obj->metadata['whatIsPurchased'];
        $eventPurchaseDetailsJson = $obj->metadata['purchaseDetailsJson'];

        if ($obj['object'] == 'payment_intent')
        {
            $eventPaymentIntentId = $obj->id;
        }
        elseif ($obj['object'] == 'charge')
        {
            $eventPaymentIntentId = $obj->payment_intent;
        }


apiLogMessage('1111');

        // only save payment method to user profile once, when payment succeeds
        if (($event->type == 'payment_intent.succeeded') && isset($obj->payment_method) && !empty2($obj->payment_method))
        {
            $user = User::find($eventUserId);

            if ($user)
            {
                $user->savePaymentMethod($obj->payment_method);
            }
        }




        $purchaseDetails = json_decode($eventPurchaseDetailsJson, true);

        $ut = static::findByPurchase($eventWhatIsPurchased, $purchaseDetails);

apiLogMessage('2222');

        if ($ut)
        {
apiLogMessage('3333');

            if ($ut->lastEventUnixtime > $event->created)
            {
apiLogMessage('4444');

                // the event that was already recorded to `user_transactions` is newer than event we just received
                return;
            }

            if (in_array($ut->status, ['Captured', 'Refunded']))
            {
apiLogMessage('5555');

                // these statuses are final and cannot be updated
                return;
            }
        }
        else
        {
apiLogMessage('6666');

            $ut = new UserTransaction;

            $ut->whatIsPurchased = $eventWhatIsPurchased;
            $ut->purchaseDetails = $purchaseDetails;
        }


        $ut->lastEventId = $event->id;
        $ut->lastEventUnixtime = $event->created;
        $ut->lastEventJson = $event->toJSON();  ///$event->toArray();

        $ut->userId = $eventUserId;

        $ut->paymentIntentId = $eventPaymentIntentId;

apiLogMessage('7777');

        switch ($event->type) 
        {
            case 'payment_intent.succeeded':

apiLogMessage('payment_intent.succeeded');

                $ut->status = 'Captured';
                $ut->amountCapturable = 0;
                $ut->amountReceived = $obj->amount_received / 100; // !! should be amount_received
                //$ut->amountRefunded
                break;


            case 'payment_intent.amount_capturable_updated':

apiLogMessage('payment_intent.amount_capturable_updated');

                if ($obj->amount_capturable > 0)
                {
                    $ut->status = 'Capturable';
                    $ut->amountCapturable = $obj->amount_capturable / 100;
                    //$ut->amountReceived
                    //$ut->amountRefunded
                }
                break;


            case 'payment_intent.canceled':

apiLogMessage('payment_intent.canceled');

                $ut->status = 'Canceled';
                $ut->amountCapturable = 0;
                //$ut->amountReceived
                //$ut->amountRefunded

                break;


            case 'charge.refunded':
                $ut->status = 'Refunded';
                $ut->amountCapturable = 0;
                //$ut->amountReceived
                $ut->amountRefunded = $obj->amount_refunded / 100;

                break;
        }

apiLogMessage('8888');

        $savedOriginalValues = $ut->getOriginal();
        $ut->save();
        $ut->dispatchEvents($savedOriginalValues);

apiLogMessage('9999');

        returnResponseAsString("Handled: {$event->type}", 200);
    }


/*
getWhatObjAttribute  returns EventRequest obj that was paid in this user transaction
getOrderedObj

*/


/*

on saved event:

function onEventRequestHoldSucceeded <- to EventRequest? yes. Use laravel Events?
^^^^  probably just EventRequest::find()->onEventRequestHoldSucceeded($userTransaction)


function onEventRequestHoldCaptured

function onEventRequestHoldCanceled


function onEventRequestPaid
*/


    public function dispatchEvents(Array $savedOriginalValues)
    {
apiLogMessage('dispatchEvents');

        $model = $this;

        $paymentHandlerClass = $model->getPaymentHandlerClass();
 
        if ($model->wasRecentlyCreated)
        {
            apiLogMessage('wasRecentlyCreated');

            switch ($model->status)
            {
                case 'Capturable':
                    $paymentHandlerClass::onPaymentCapturable($model);
                    break;

                case 'Captured':
                    $paymentHandlerClass::onPaymentCaptured($model);
                    break;

                case 'Canceled':
                    // if we just created this `user_transaction` record this means we haven't yet done any
                    // processing of this transaction. And if the transaction is already canceled, no further
                    // processing is needed.
                    break;

                case 'Refunded':
                    // if we just created this `user_transaction` record this means we haven't yet done any
                    // processing of this transaction. And if the transaction is already refunded, no further
                    // processing is needed.
                    break;
            }
        }
        else
        {
            apiLogMessage('wasUpdated');

            # 'Capturable' ==> 'Captured'
            if (($savedOriginalValues['status'] == 'Capturable') && ($model->status == 'Captured'))
            {
                $paymentHandlerClass::onPaymentCapturableToCaptured($model);
            }
            # 'Capturable' ==> 'Canceled'
            elseif (($savedOriginalValues['status'] == 'Capturable') && ($model->status == 'Canceled'))
            {
                $paymentHandlerClass::onPaymentCapturableToCanceled($model);
            }
            # 'Captured' ==> 'Refunded'
            elseif (($savedOriginalValues['status'] == 'Captured') && ($model->status == 'Refunded'))
            {
                $paymentHandlerClass::onPaymentCapturedToRefunded($model);
            }
        }
    }

    protected function getPaymentHandlerClass()
    {
        if ($this->whatIsPurchased == 'GameRequest')
        {
            return '\App\PaymentHandlers\GameRequestPayment';
        }
        elseif ($this->whatIsPurchased == 'RunRequest')
        {
            return '\App\PaymentHandlers\RunRequestPayment';
        }
        else
        {
            throw new Exception("whatIsPurchased={$this->whatIsPurchased} is not supported");
        }
    }


    public function capturePayment($amountToCapture=null)
    {
// NYI - make necessary checks before making a capture

        $stripe = my_app('stripe');

        $paymentIntent = $stripe->paymentIntents->retrieve($this->paymentIntentId);

        if ($amountToCapture === null)
        {
            $paymentIntent->capture();
        }
        else
        {
            $paymentIntent->capture(['amount_to_capture' => $amountToCapture * 100]);  // multiply amount by 100???
        }

/*
\Stripe\Stripe::setApiKey('sk_test_51InPZ0CGjKmUtmBDGd8auAiuhJzsWoq2jWRPSxRYHhbGitq6YfacM7GMkD9upefdAz2IeKninlgGt0mbUvRuIQPb00jxunFHSh');

$intent = \Stripe\PaymentIntent::retrieve('pi_ANipwO3zNfjeWODtRPIg');


*/

    }



}

