<?php

namespace App;
 
class Mysql {
    
    public $pdo;
    public $insert_id;
    
    public function __construct($host,$database,$user,$pass)
    {
        try{
            $pdo = new \PDO("mysql:host=$host;dbname=$database", 
                            $user, 
                            $pass
                        );
        }catch (\PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
        $this->pdo = $pdo;
    }
    
    public function selectQuery($query, $params=null)
    {
///echo '####';
///echo $query;
///echo '####';

        $stmt = $this->pdo->prepare($query);

        if (is_array($params))
        {
            foreach($params as $p)
            {
                $pname = $p[0];
                $pval = $p[1];
                $ptype = isset($p[2]) ? $p[2] : \PDO::PARAM_STR;

//echo "bindParam({$pname}, {$pval}, {$ptype});";

                $stmt->bindParam($pname, $pval, $ptype);
            }
        }

        $stmt->execute();

        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        return $result;  
    }
    
    /**
     * multiple deletions
     * transactions wrapped
     * @returns boolean or debug message
     */
    final public function deleteValues(array $deletes, bool $debug = false)
    {
        if (empty($deletes)) return false;

        /* require all fields */
        foreach ($deletes as $delete){
            if (empty($delete['table']) || empty($delete['key']) || empty($delete['key_value'])){
                return false;
            }
        } 

        try {

            $this->pdo->beginTransaction();           
            foreach ($deletes as $delete){
                $stmt = $this->pdo->prepare("DELETE FROM `{$delete['table']}` WHERE `{$delete['key']}` = ?");
                $stmt->execute([$delete['key_value']]);
            } 

            $this->pdo->commit();
            return true;

        } catch (\PDOException $e) {     
            $this->pdo->rollback();       
            return $debug ? $e->getMessage() : false;
        }
    }

    public function deleteValue($table, $row, $value)
    { 
        try{
            $exec = $this->pdo->prepare('DELETE FROM ' .$table. ' WHERE '.$row.' = :value');
            $exec->execute(array(':value' => $value));

        }catch (\PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    }

    /* update single value */
    public function updateValue($table, $row, $value, $id)
    { 
        try{
            $exec = $this->pdo->prepare('UPDATE ' .$table. ' SET '.$row.' = :value WHERE id = :id');
            $exec->execute(array(':value' => $value, ':id' => $id));
            
        }catch (\PDOException $e) {
               echo 'Connection failed: ' . $e->getMessage();
        }
    }
    
    /* update multiple values */
    final public function updateValues($table='',$update=array(),$id=array())
    {   
        if (empty($id) || empty($update) || empty($table)){
            return false;
        }        
        $keys   = array_keys($update);
        $upd = null;        
        $id_field = key($id);
        $id_val = $id[$id_field];
        
        foreach ($keys as $field){
            $upd[] = $field.'=?';
        }
        
        $upd = implode(',',$upd);        
        try {        
            $stmt = $this->pdo->prepare("UPDATE `{$table}` SET {$upd} WHERE `{$id_field}`=?");
            $stmt->execute(
                array_merge(
                    array_values($update),                    
                    array($id_val)
                )
            );     
            //$stmt->debugDumpParams(); 
            return true;   
            
        } catch (\PDOException $e) {
            //TODO: log? 
            return false;                       
        }
    }
    
    public function insertValue($table, $array)
    {
        $key = array_keys($array);
        $value = array_values($array);
        $column = implode(',',$key);
        $stmt = ':'.implode(',:',$key);
        
        try{

            $exec = $this->pdo->prepare('INSERT INTO ' .$table. ' ('.$column.') VALUES ('.$stmt.')');
            $exec->execute($array);
            $this->insert_id = $this->pdo->lastInsertId();

        }catch (\PDOException $e) {
            print_r("error");
            echo 'Connection failed: ' . $e->getMessage();
        }
    }
    
    public function transport($table, $query)
    {          
        try{
            $exec = $this->pdo->prepare('INSERT ' .$table. ' '.$query);
            $exec->execute();

        }catch (\PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    }
}
