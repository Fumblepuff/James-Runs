<?php
namespace App\PaymentHandlers;

use App\Models\UserTransaction;

abstract class BasePayment
{
    abstract public static function onPaymentCapturable(UserTransaction $userTransaction);

    abstract public static function onPaymentCaptured(UserTransaction $userTransaction);



    abstract public static function onPaymentCapturableToCaptured(UserTransaction $userTransaction);

    abstract public static function onPaymentCapturableToCanceled(UserTransaction $userTransaction);

    abstract public static function onPaymentCapturedToRefunded(UserTransaction $userTransaction);
}

