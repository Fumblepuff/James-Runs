<?php
namespace App\PaymentHandlers;

use App\Models\UserTransaction;

class GameRequestPayment extends BasePayment
{

public static function onPaymentCapturable(UserTransaction $userTransaction)
{
    apiLogMessage('GameRequestPayment.onPaymentCapturable');
}

public static function onPaymentCaptured(UserTransaction $userTransaction)
{
    apiLogMessage('GameRequestPayment.onPaymentCaptured');
}



public static function onPaymentCapturableToCaptured(UserTransaction $userTransaction)
{
    apiLogMessage('GameRequestPayment.onPaymentCapturableToCaptured');
}

public static function onPaymentCapturableToCanceled(UserTransaction $userTransaction)
{
    apiLogMessage('GameRequestPayment.onPaymentCapturableToCanceled');
}

public static function onPaymentCapturedToRefunded(UserTransaction $userTransaction)
{
    apiLogMessage('GameRequestPayment.onPaymentCapturedToRefunded');
}


}

