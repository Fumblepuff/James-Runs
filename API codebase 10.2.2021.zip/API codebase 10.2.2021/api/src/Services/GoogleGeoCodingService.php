<?php
namespace Helpers;

/*
 * The whole purpose of parsing the address string is to identify
 * buildings that have multiple units within it. And for such buildings
 * we want to correctly identify their street address (building number+street name)
 *
 */
class GoogleGeoCodingService {

    public $overall_status;
    public $http_status;
    public $google_api_status; # OK,  ZERO_RESULTS,  REQUEST_DENIED
    public $google_api_error_message;
    public $lat;
    public $lng;

    protected $curl;

    public function __construct()
    {
///echo 'GoogleGeoCodingService::construct';

        $this->resetResults();

        $this->curl = curl_init();

        curl_setopt($this->curl, CURLOPT_AUTOREFERER, true); # TRUE to automatically set the Referer: field in requests where it follows a Location: redirect.
        curl_setopt($this->curl, CURLOPT_MAXREDIRS, 10);
        curl_setopt($this->curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.52 Safari/537.36 OPR/15.0.1147.100");
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false);
    }

///    public function __destruct()
///    {
///        echo 'GoogleGeoCodingService::destruct';
///    }

    protected function resetResults()
    {
        $this->overall_status = null;

        $this->http_status = null;
        $this->google_api_status = null;
        $this->google_api_error_message = null;

        $this->lat = null;
        $this->lng = null;
    }


    protected function generateApiUrlForAddress($address)
    {
        return 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBR_caoqX-2qwya8iPcIGOiIXz4I9HOrvQ&address=' . urlencode($address);
////        return 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzSyBR_caoqX-2qwya8iPcIGOiIXz4I9HOrvQ&address=' . urlencode($address);
    }

    public function codeAddressString($address)
    {
        $this->resetResults();

        $this->overall_status = 'Failed';

//echo 'here';

        curl_setopt($this->curl, CURLOPT_URL, $this->generateApiUrlForAddress($address));

        curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, true);

        $output = curl_exec($this->curl);
        $info = curl_getinfo($this->curl);

        $this->http_status = $info['http_code'];

        if ($info['http_code'] == 200) {

            $x = json_decode($output);
//print_r($x);

            $this->google_api_status = $x->status;
            $this->google_api_error_message = isset($x->error_message) ? $x->error_message : '';

            if (($x->status == 'OK') && (count($x->results) > 0)) {

                $this->overall_status = 'Success';

                $location = $x->results[0]->geometry->location;

                $this->lat = $location->lat;
                $this->lng = $location->lng;

//print_r($location);

            }
        }

//print_r($this);

/*

Helpers\GoogleGeoCodingService Object
(
    [overall_status] => Success
    [http_status] => 200
    [google_api_status] => OK
    [google_api_error_message] => 
    [lat] => 38.8232814
    [lng] => -77.3171701
)

*/

//print_r($output);
//print_r($info);



//    if ($output === false)

//    if ($info['http_code'] == 200)

    }


}
