<?php

namespace App;

class Square {
    public $access_token;
    public $customer;
    public $location;
    
    public function __construct(){
        $access_token = 'sq0atp-JcJuiAl34G5KeMXMuCSdag';
        $location = 'MSJ3TJ079DZAX';
        # setup authorization
        \SquareConnect\Configuration::getDefaultConfiguration()->setAccessToken($access_token);

        $this->access_token = $access_token;
        $this->location = $location;
        
    }
    
    public function locations(){
        $locations_api = new \SquareConnect\Api\LocationsApi();

        try {

            $locations = $locations_api->listLocations();


            returnResponseAsJson($locations->getLocations());

        } catch (\SquareConnect\ApiException $e) {

            returnResponseAsString('Exception: ' . $e->getResponseBody());

            exit(1);
        }  
    }

    public function newCustomer($user){

        $api_instance = new SquareConnect\Api\CustomersApi();
        $body = new \SquareConnect\Model\CreateCustomerRequest();

        $body->setIdempotencyKey($user['id']);
        $body->setGivenName($user['firstName']);
        $body->setFamilyName($user['lastName']);
        $body->setEmailAddress($user['email']);

        try {
            
            $result = $api_instance->createCustomer($body);
            return $result->getCustomer()->getId();

        } catch (Exception $e) {

            returnResponseAsString('Exception when calling CustomersApi->createCustomer: ', $e->getMessage(), PHP_EOL);

        }  
    }

    public function newCard($id, $card){

        $newCard = [];

        $api_instance = new SquareConnect\Api\CustomersApi();
        $body = new \SquareConnect\Model\CreateCustomerCardRequest();

        $body->setCardNonce($card);

        try {
            
            $result = $api_instance->createCustomerCard($id, $body);

            $newCard['customerCard'] = $result->getCard()->getId();
            $newCard['cardBrand'] = $result->getCard()->getCardBrand();
            $newCard['last4'] = $result->getCard()->getLast4();

            return $newCard;

        } catch (Exception $e) {

            returnResponseAsString('Exception when calling CustomersApi->createCustomerCard: ', $e->getMessage(), PHP_EOL);


        }  
    }

    public function chargeCard($card, $amount, $run, $user, $customer, $key){

        $newCharge = [];

        $api_instance = new SquareConnect\Api\TransactionsApi();
        $body = new \SquareConnect\Model\ChargeRequest();

        $amount_money["amount"] = $amount;
        $amount_money["currency"] = "USD";

        $body->setIdempotencyKey($key);
        $body->setCustomerCardId($card);
        $body->setCustomerId($customer);
        $body->setAmountMoney($amount_money);
        $body->setNote("User:".$user." Run ID:".$run);

        try {
            
            $result = $api_instance->charge($this->location, $body);

            $newCharge['transactionID'] = $result->getTransaction()->getId();
            $newCharge['runID'] = $run;
            $newCharge['userID'] = $user;
            $newCharge['amount'] = $amount;

            return $newCharge;

        } catch (Exception $e) {
            $message = str_replace("[HTTP/1.1 400 Bad Request] ", "", $e->getMessage());
            $quotes = str_replace("\"", "", $message);

            $error['error'] = true;
            $error['message'] = $quotes;
            
            return $error;

        }  
    }

    public function deleteCard($customerID, $cardID){

        $api_instance = new SquareConnect\Api\CustomersApi();
        try {
            
            $result = $api_instance->deleteCustomerCard($customerID, $cardID);
            
        } catch (Exception $e) {
            
            return $e->getMessage();

        }

    }

}

