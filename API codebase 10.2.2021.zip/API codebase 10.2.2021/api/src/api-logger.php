<?php

global $apiLogger;


function apiLogRequest()
{
    global $apiLogger;

    $apiLogger = [];

    try
    {
        $db = my_app('db');

        $unixtime = time();

        $dt = new \DateTime();
        $dt->setTimestamp($unixtime);
        $dt->setTimezone(new \DateTimeZone('UTC'));

        $request_content = trim(file_get_contents("php://input"));

        if (preg_match('/^\/api\//i', $_SERVER['REQUEST_URI']))
        {
            $env = 'prod';
        }
        else
        {
            $env = 'dev';
        }

        $type = 'n/a';

        $request_array = json_decode($request_content, true);

        if (is_array($request_array))
        {
            if (isset($request_array['type']))
            {
                $type = (String) $request_array['type'];
            }
        }


        $r = [];

        $r['unixtime'] = $unixtime;
        $r['datetime_utc'] = $dt->format('Y-m-d H:i:s');

        $r['remote_addr'] = $_SERVER['REMOTE_ADDR'];
        $r['request_uri'] = $_SERVER['REQUEST_URI'];
        $r['request_scheme'] = $_SERVER['REQUEST_SCHEME'];
        $r['request_method'] = $_SERVER['REQUEST_METHOD'];

        // trim at 16777215 bytes (max size for medium text)
        $r['request_content'] = substr($request_content, 0, 16777215-1);

        $r['env'] = $env;

        $r['type'] = $type;

        $r['message'] = '';

        //$r['response_http_code'] = ;
        //$r['response_content'] = ;


        $db->insertValue('api_log', $r);
        $apiLogger['api_log_id'] = $db->insert_id;
    }
    catch (\Exception $e) 
    {
        // ignore any errors and continue execution
    }
}


/*

function apiLogMessage
trim at 16777215 bytes (max size for medium text)

function apiLogMessageLine
*/

function apiLogResponse($responseContent, $responseHttpCode=200)
{
    global $apiLogger;

    if (isset($apiLogger['api_log_id']))
    {
        try
        {
            $db = my_app('db');

            $r = [];

            $r['response_http_code'] = $responseHttpCode;

            // trim at 16777215 bytes (max size for medium text)
            $r['response_content'] = substr($responseContent, 0, 16777215-1);
 
            $db->updateValues('api_log', $r, ['id' => $apiLogger['api_log_id']]);

        }
        catch (\Exception $e) 
        {
            // ignore any errors and continue execution
        }
    }
}



function apiLogMessage($msg)
{
    global $apiLogger;

    if (isset($apiLogger['api_log_id']))
    {
        try
        {
            $db = my_app('db');

            $query = <<<SQL
UPDATE `api_log` SET `message` = CONCAT(`message`, :msg, "\r\n\r\n") WHERE id = '{$apiLogger['api_log_id']}'
SQL;

            $db->selectQuery($query, [[':msg', $msg]]);
        }
        catch (\Exception $e) 
        {
            // ignore any errors and continue execution
        }
    }
}
