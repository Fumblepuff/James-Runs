<?php

use App\Mysql;
///use App\RequestDataException;
use Illuminate\Database\Capsule\Manager as Capsule;
use Stripe\StripeClient;


init_application();


// NYI - must specify type for all function arguments and all function return values


function init_application()
{
    global $config;
    global $runtime;

    $runtime = [];


    ###########################################################################
    #  set up illuminate/database


    $capsule = new Capsule;

    $capsule->addConnection([
        'driver'    => 'mysql',
        'host'      => $config['db_host'],
        'database'  => $config['db_database'],
        'username'  => $config['db_user'],
        'password'  => $config['db_pass'],

        'charset'   => 'utf8',
        ///'collation' => 'utf8_unicode_ci',
        'collation' => 'utf8_general_ci', // as in prod database

        'prefix'    => '',
    ]);

    // Set the event dispatcher used by Eloquent models... (optional)
    #use Illuminate\Events\Dispatcher;
    #use Illuminate\Container\Container;
    #$capsule->setEventDispatcher(new Dispatcher(new Container));

    // Make this Capsule instance available globally via static methods... (optional)
    $capsule->setAsGlobal();

    // Setup the Eloquent ORM... (optional; unless you've used setEventDispatcher())
    $capsule->bootEloquent();


} // function init_application()

function my_app($what, $param1=null)
{
    global $config;
    global $runtime;

    if (($what == 'db') && !isset($runtime[$what]))
    {
        $runtime['db'] = new Mysql($config['db_host'], $config['db_database'], $config['db_user'], $config['db_pass']);
    }
    elseif (($what == 'stripe') && !isset($runtime[$what]))
    {
        $runtime['stripe'] = new StripeClient($config['stripe_api_key_secret']);
    }


    if (isset($runtime[$what]))
    {
        return $runtime[$what];
    }
    else
    {
        throw new \Exception("my_app('{$what}') is not found in dependancy container");
    }
}


function resolveGeoCoordinatesToTimeZone($latitude, $longitude) :String
{
    if (($latitude === null) || ($longitude === null))
    {
        return 'UTC';
    }

    $location = "{$latitude},{$longitude}";

    $timestamp = time();

    global $config;

    $url = "https://maps.googleapis.com/maps/api/timezone/json?location={$location}&timestamp={$timestamp}&key=" . $config['google_api_key'];

    $s = @file_get_contents($url);

    if ($s === false)
    {
        // failed to open url;
        return 'UTC';
    }
    else
    {
        $t = json_decode($s, true);

        if (is_array($t) && isset($t['timeZoneId']))
        {
            return $t['timeZoneId'];
        }
        else
        {
            // something is wrong with response from Google Time Zone API
            return 'UTC';
        }
    }
}

function convertDateTimeToAnotherTimeZone(String $originalDateTime, String $originalTimeZone, String $convertToTimeZone) :String
{
    $originalTz = new \DateTimeZone($originalTimeZone);
    $convertToTz = new \DateTimeZone($convertToTimeZone);

    $dt = \DateTime::createFromFormat('Y-m-d H:i:s', $originalDateTime, $originalTz);

    if ($dt === false)
    {
        throw new \Exception("convertDateTimeToAnotherTimeZone: failed to convert '{$originalDateTime}' from '{$originalTimeZone}' to '{$convertToTimeZone}' time zone");
    }

    $dt->setTimezone($convertToTz);

    return $dt->format('Y-m-d H:i:s');
}

function convertDateTimeToUtc(String $originalDateTime, String $originalTimeZone) :String
{
    $convertToTimeZone = 'UTC';

    return convertDateTimeToAnotherTimeZone($originalDateTime, $originalTimeZone, $convertToTimeZone);
}

function convertDateTimeToAnotherTimeZoneForAListOfRecords(
    Array &$listOfRecords,

    // input
    String $originalDateTimeArrayKey,  // which array key contains the original DateTime
    String $originalTimeZoneArrayKey,  // which array key contains the Time Zone for original DateTime

    String $convertToTimeZoneArrayKey, // which array key contains the Time Zone to which we are converting

    // required output
    String $putConvertedDateTimeAtArrayKey, // at what array key the converted DateTime should be put

    // optional output
    String $putOriginalDateTimeAtArrayKey=null  // at what array key the original DateTime should be put
) :void
{
    foreach($listOfRecords as $idx => $rec)
    {
        if (isset($rec[$originalDateTimeArrayKey]))
        {
            $originalDateTime = $rec[$originalDateTimeArrayKey];
        }
        else
        {
            throw new \Exception("convertDateTimeToAnotherTimeZoneForAListOfRecords: '{$originalDateTimeArrayKey}' array key doesn't exist for record with idx = {$idx}");
        }

        if (isset($rec[$originalTimeZoneArrayKey]))
        {
            $originalTimeZone = $rec[$originalTimeZoneArrayKey];
        }
        else
        {
            throw new \Exception("convertDateTimeToAnotherTimeZoneForAListOfRecords: '{$originalTimeZoneArrayKey}' array key doesn't exist for record with idx = {$idx}");
        }


        if (isset($rec[$convertToTimeZoneArrayKey]))
        {
            $convertToTimeZone = $rec[$convertToTimeZoneArrayKey];
        }
        else
        {
            throw new \Exception("convertDateTimeToAnotherTimeZoneForAListOfRecords: '{$convertToTimeZoneArrayKey}' array key doesn't exist for record with idx = {$idx}");
        }

        $convertedDateTime = convertDateTimeToAnotherTimeZone($originalDateTime, $originalTimeZone, $convertToTimeZone);

        $listOfRecords[$idx][$putConvertedDateTimeAtArrayKey] = $convertedDateTime;

        if ($putOriginalDateTimeAtArrayKey !== null)
        {
            $listOfRecords[$idx][$putOriginalDateTimeAtArrayKey] = $originalDateTime;
        }
    }
}



function convertDateTimeFromUtcToAnotherTimeZoneForAListOfRecords(
    Array &$listOfRecords,

    // input
    String $originalDateTimeArrayKey,  // which array key contains the original DateTime in UTC
    String $convertToTimeZoneArrayKey, // which array key contains the Time Zone to which we are converting

    // required output
    String $putConvertedDateTimeAtArrayKey, // at what array key the converted DateTime should be put

    // optional output
    String $putOriginalDateTimeAtArrayKey=null  // at what array key the original DateTime should be put
) :void
{

    $originalTimeZoneArrayKey = '~~~~~tmp73636erdrr5e34w2FieldWithUtc';

    insertKeyValuePairsForAllRecords($listOfRecords, $originalTimeZoneArrayKey, 'UTC');


    convertDateTimeToAnotherTimeZoneForAListOfRecords(
        $listOfRecords,

        // input
        $originalDateTimeArrayKey,  // which array key contains the original DateTime
        
        $originalTimeZoneArrayKey,  // which array key contains the Time Zone for original DateTime

        $convertToTimeZoneArrayKey, // which array key contains the Time Zone to which we are converting

        // required output
        $putConvertedDateTimeAtArrayKey, // at what array key the converted DateTime should be put

        // optional output
        $putOriginalDateTimeAtArrayKey  // at what array key the original DateTime should be put
    );

    removeKeyForAllRecords($listOfRecords, $originalTimeZoneArrayKey);

}

function adjustRunScheduleForAListOfRuns(Array &$listOfRecords)
{
    convertDateTimeFromUtcToAnotherTimeZoneForAListOfRecords(
        $listOfRecords,

        // input
        'timeStamp',  // which array key contains the original DateTime in UTC
        'timezone', // which array key contains the Time Zone to which we are converting

        // required output
        'timeStamp', // at what array key the converted DateTime should be put

        // optional output
        'timeStampUtc'  // at what array key the original DateTime should be put
    );
}


function insertKeyValuePairsForAllRecords(Array &$ar, $key, $value)
{
    foreach($ar as $i => $v)
    {
        $ar[$i][$key] = $value;
    }
}

function removeKeyForAllRecords(Array &$ar, $key)
{
    $res = [];

    foreach($ar as $i => $v)
    {
        unset($v[$key]);

        $res[$i] = $v;
    }

    $ar = $res;
}

function lookupCourtById(int $id): ?array
{
    $db = my_app('db');

    $r = $db->selectQuery('SELECT * FROM courts WHERE id = :id', [[':id', $id]]);

    if (($r == []) || (!$r))
    {
        $r = null;
    }

    return $r[0];
}

function lookupRunById(int $id): ?array
{
    $db = my_app('db');

    $r = $db->selectQuery('SELECT * FROM runs WHERE id = :id', [['id', $id]]);

    if (($r == []) || (!$r))
    {
        $r = null;
    }

    return $r[0];
}

function lookupSkillById(int $id): ?array
{
    $db = my_app('db');

    $r = $db->selectQuery('SELECT * FROM skills WHERE id = :id', [['id', $id]]);

    if (($r == []) || (!$r))
    {
        $r = null;
    }

    return $r[0];
}


function convertUnixTimeToDateTimeUtc($unixtime)
{
    $dt = new \DateTime;

    $dt->setTimestamp($unixtime);

    $dt->setTimezone(new \DateTimeZone('UTC'));

    return $dt->format('Y-m-d H:i:s');
}

function getCurrentDateTimeUtc()
{
    return convertUnixTimeToDateTimeUtc(time());
}

function setZeroSecondsOnDateTime($datetime)
{
    // 2021-04-05 23:58:59  ==>  2021-04-05 23:58:00

    return substr($datetime, 0, 17) . '00';
}



function getUserStats($id){

    $db = my_app('db');

    $streak = $db->selectQuery('select * from user_streak where userId = '.$id);

    if($streak){

        $runs = $db->selectQuery('select runId from run_user where userId = '.$id);
        $totalGames = 0;

        foreach ($runs as $run) {
            $gameID = $run['runId'];

            $userGames = $db->selectQuery('select count(id) as cnt from run_game where runId = '.$gameID);
            $count = $userGames[0]['cnt'];

            $totalGames += $count;
        }

        $stats['totalGames'] = $totalGames;

        $wins = $streak[0]['wins'];
        $losses = $streak[0]['losses'];
        $streak = $streak[0]['streak'];
        $games = $wins + $losses;

        if($wins){
            $calc = $wins / $games;
            $winPercentage = $calc * 100;
        }else{
            $winPercentage = 0;
        }

        if($wins){

            $divideGames = $totalGames / $games;
            $gamePercentage = 100 / $divideGames;
            $jamesWinPercetage = round($winPercentage, 1);
            $jamesWins = 70 * $jamesWinPercetage;
            $jamesDepth = 30 * $gamePercentage;
            $jamesTotal = $jamesWins + $jamesDepth;

            $jamesRating = $jamesTotal / 100;

        }else{

            $jamesRating = 0;
        
        }

        $stats['gameCount'] = $games;
        $stats['wins'] = $wins;
        $stats['winPercentage'] = round($winPercentage, 0);
        $stats['losses'] = $losses;
        $stats['streak'] = $streak;
        $stats['jamesRating'] = round($jamesRating, 0);

        return $stats;

    }else{

        $stats['totalGames'] = 0;
        $stats['gameCount'] = 0;
        $stats['wins'] = 0;
        $stats['winPercentage'] = 0;
        $stats['losses'] = 0;
        $stats['streak'] = 0;
        $stats['jamesRating'] = 0;

        return $stats;
    }
    

}


function apiRequest($paramName, $defaultValue=null)
{
    global $apiRequest;

    if (isset($apiRequest[$paramName]))
    {
        return $apiRequest[$paramName];
    }

    if ($defaultValue !== null)
    {
        return $defaultValue;
    }

    return null;
}

function apiRequestData($paramName, $defaultValue=null)
{
    global $apiRequestData;

    if (isset($apiRequestData[$paramName]))
    {
        return $apiRequestData[$paramName];
    }

    if ($defaultValue !== null)
    {
        return $defaultValue;
    }

    return null;
}


function apiRequestType()
{
    global $apiRequestType;

    return $apiRequestType;
}

///function throwRequestDataException($msg)
///{
///    throw new RequestDataException($msg);
///}

function requestTypeToActionClassName($type)
{
    return ucfirst($type);
}


function returnResponseAsString($responseString, $responseHttpCode=200)
{
    echo $responseString;

    // NYI - must also send response http code
    # http_response_code($responseHttpCode); <- I don't know how mobile application will behave if it receives response
    # code other than 200

    apiLogResponse($responseString, $responseHttpCode);
}

function returnResponseAsJson($responseData, $responseHttpCode=200)
{
    $json = json_encode($responseData);

    header("Content-Type: application/json;charset=utf-8");

    returnResponseAsString($json, $responseHttpCode);
}




function _e($msg='', $httpStatus=200)
{
    $str = json_encode(['error' => $msg ? $msg : 'Unspecified error']);

    returnResponseAsString($str, $httpStatus);

    die();
}    

function _s($msg='', $httpStatus=200)
{
    $str = json_encode(['success' => $msg ? $msg : 'Success']);

    returnResponseAsString($str, $httpStatus);

    die();
}    


// but integer 0 is not empty
function empty2($value)
{
    if (($value === null) || ($value === '') || ($value === false))
    {
        return true;
    }
    else
    {
        return false;
    }
}


function extractParam(Array $params, String $paramName, $paramDefaultValue=null)
{
    return isset($params[$paramName]) ? $params[$paramName] : $paramDefaultValue;
}


///function assignObjPropertiesIfNotEmpty2(object $objAssignTo, object $objAssignFrom, Array $properties)
///{
///    foreach($properties as $property)
///    {
///        if (!empty2($objAssignFrom->$property))
///        {
///            $objAssignTo->$property = $objAssignFrom->$property;
///        }
///    }
///}


function validWebUrl($value)
{
    # NYI:  this regexp is not complete
    $regex = '/^https?\:\/\/[^\s]+$/';
    $passed = preg_match($regex, $value);

    return $passed;
}

function validEmail($value)
{
    $email_regex = '/^([\-\_a-zA-Z0-9\.]+\@[\-\_a-zA-Z0-9]+(\.[\-\_a-zA-Z0-9]+){0,3}){1}$/';
    $passed = preg_match($email_regex, $value);

    return $passed;
}


function extractFileExtension($path)
{
    $baseName = basename($path);

    $parts = explode('.', $baseName);

    if (count($parts) > 1)
    {
        return array_pop($parts);
    }
    else
    {
        return '';
    }
}


