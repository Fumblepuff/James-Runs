<?php
// http://35.224.164.208/dev/stripeWebHook.php

require_once(__DIR__ . '/vendor/autoload.php');

apiLogRequest();

use Stripe\Webhook;
use Stripe\Exception\SignatureVerificationException;
use App\Models\UserTransaction;


global $config;

$stripe = my_app('stripe'); // needed in order to Stripe::setApiKey

$payload = @file_get_contents('php://input');
$event = null;

try
{
    $event = Webhook::constructEvent(
        $payload, $_SERVER['HTTP_STRIPE_SIGNATURE'], $config['stripe_webhook_secret']
    );
}
catch (UnexpectedValueException $e)
{
    returnResponseAsString('Invalid payload', 400);
    exit();
}
catch(SignatureVerificationException $e)
{
    returnResponseAsString('Invalid signature', 400);
    exit();
}


UserTransaction::handleStripeEvent($event);


http_response_code(200);

