<?php
require_once(__DIR__ . '/vendor/autoload.php');

# From Dainius: 
# 
# Most likely not used, unless it's used as callback via Lambda functions via Cognito 
# - it should insert new user.
#


apiLogRequest();


//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    returnResponseAsString('Request method must be POST!', 400);
    exit;
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    returnResponseAsString('Content type must be: application/json', 400);
    exit;
}
 
//Receive the RAW post data.
$content = trim(file_get_contents("php://input"));


 
//Attempt to decode the incoming RAW post data from JSON.
$apiRequest = json_decode($content, true);
 
//If json_decode failed, the JSON is invalid.
if(!is_array($apiRequest)){
    returnResponseAsString('Received content contained invalid JSON!', 400);
    exit;
}

if($apiRequest['profile']){
    $profile = $apiRequest['profile'];

    $db = my_app('db');

    $db->insertValue('user', $profile);
    
}

