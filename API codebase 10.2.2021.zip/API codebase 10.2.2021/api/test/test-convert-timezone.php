<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test-convert-timezone.php

*/


$originalDateTime = '2021-03-29 15:39:02';
$originalTimeZone = 'Europe/Kiev';
$convertToTimeZone = 'UTC';

$originalDateTime = '';
$originalTimeZone = 'Europe/Kiev';
$convertToTimeZone = 'UTC';

$r = convertDateTimeToAnotherTimeZone($originalDateTime, $originalTimeZone, $convertToTimeZone);

echo $r;
