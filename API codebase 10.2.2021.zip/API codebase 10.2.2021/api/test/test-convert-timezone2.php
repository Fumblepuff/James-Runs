<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test-convert-timezone2.php

*/


$originalDateTime = '2021-03-29 15:39:02';
$originalTimeZone = 'Europe/Kiev';
$convertToTimeZone = 'UTC';

//$originalDateTime = '';
//$originalTimeZone = 'Europe/Kiev';
//$convertToTimeZone = 'UTC';

$listOfRecords = [];

$listOfRecords[] = 
[
    'originalDateTime' => '2021-03-29 15:39:02',
    'originalTimeZone' => 'Europe/Kiev',

    'toTimeZone' => 'UTC',
];


convertDateTimeToAnotherTimeZoneForAListOfRecords(
    $listOfRecords,

    'originalDateTime',  // which array key contains the original DateTime
    'originalTimeZone',  // which array key contains the Time Zone for original DateTime

    'toTimeZone',         // to which TimeZone we are converting

    'to', // at what array key the converted DateTime should be put

    'fromOriginalDateTime'  // at what array key the original DateTime should be put
);


print_r($listOfRecords);

