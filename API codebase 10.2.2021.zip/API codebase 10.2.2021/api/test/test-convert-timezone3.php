<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test-convert-timezone3.php

*/

$db = my_app('db');

            $runs = $db->selectQuery(<<<SQL
SELECT 
    courts.*, 
    runs.id as runId, 
    runs.runSchedule as timeStamp, 
    runs.runEnd 

FROM RUNS 
    inner join courts on runs.courtId = courts.id 

ORDER BY 
    runs.runSchedule asc
SQL
);

            convertDateTimeFromUtcToAnotherTimeZoneForAListOfRecords(
                $runs,

                // input
                'timeStamp',  // which array key contains the original DateTime in UTC
                'timezone', // which array key contains the Time Zone to which we are converting

                // required output
                'timeStamp', // at what array key the converted DateTime should be put

                // optional output
                'timeStampUtc'  // at what array key the original DateTime should be put
            );


print_r($runs);


