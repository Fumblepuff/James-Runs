<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test1.php

*/


$datetime = '2021-04-05 23:58:59';

echo setZeroSecondsOnDateTime($datetime);



