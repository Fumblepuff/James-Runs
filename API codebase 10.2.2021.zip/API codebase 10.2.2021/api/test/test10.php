<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test10.php

*/

use App\Models\GameLevel;
use App\Models\Service;

use Illuminate\Database\Capsule\Manager as Capsule;


$gl = GameLevel::find(2);

//print_r($gl);


Capsule::connection()->enableQueryLog();

$gls = $gl->gameLevelServices()->isActive()->with(['service' => function ($query) { $query->isActive(); }])->orderBy('serviceId', 'asc')->get();

//print_r($gls[0]->service);


$queries = Capsule::getQueryLog();

//print_r($queries);


print_r($gls);


