<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test11.php

*/


use App\Models\Service;

use Illuminate\Database\Capsule\Manager as Capsule;


$gl = Service::find(24);

//print_r($gl);


Capsule::connection()->enableQueryLog();



print_r($gl->skill);


$queries = Capsule::getQueryLog();

//print_r($queries);



