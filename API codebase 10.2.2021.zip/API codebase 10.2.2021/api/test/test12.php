<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test12.php

*/


use App\Models\User;
use App\Models\Skill;



$u = User::find(65);

//print_r($u);


//$us = $u->getUserSkills();

$r = $u->hasSkill(Skill::find(23));

if ($r)
{
  echo 'yes';
}
else
{
  echo 'no';
}

//print_r($r);

