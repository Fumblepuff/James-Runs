<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test13.php

*/

use App\Models\GameLevel;
use App\Models\Service;




$gl = GameLevel::find(2);

//print_r($gl);




$gls = $gl->getGameLevelServices();

//print_r($gls[0]->service);



print_r($gls);


