<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test14.php
http://35.224.164.208/dev/test/test14.php

*/

use App\Models\UserTransaction;


$ut = UserTransaction::find(13);


$ut->capturePayment(3);


echo 'captured';

