<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test2.php

*/

use Illuminate\Database\Capsule\Manager as Capsule;


$r = Capsule::table('courts')->get();

print_r($r);


