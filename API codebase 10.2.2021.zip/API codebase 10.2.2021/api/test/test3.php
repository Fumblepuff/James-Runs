<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test3.php

*/

use App\Models\Court;


/*
->orderBy('name')
             ->take(10)
*/

$r = Court::byName('epi')
    ->orderBy('name', 'ASC')
    ->skip(0)
    ->take(10)
    ->get()
    ->toArray();


print_r($r);


