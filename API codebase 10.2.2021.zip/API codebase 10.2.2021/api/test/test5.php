<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test5.php

*/

use App\Models\Court;


$court = Court::find(113);


$runs = $court->runs;


print_r($runs);


