<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test6.php

*/

use App\Models\Run;


$run = Run::find(829);


$court = $run->court;


print_r($court);


