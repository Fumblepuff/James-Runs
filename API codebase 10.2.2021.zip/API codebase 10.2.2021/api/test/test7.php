<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test7.php

*/

use App\Models\Run;


$run = Run::find(829);


$games = $run->runGames;


print_r($games);


