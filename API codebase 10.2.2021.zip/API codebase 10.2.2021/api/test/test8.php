<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test8.php

*/

use App\Models\RunGame;


$game = RunGame::find(977);


$run = $game->run;


print_r($run);


