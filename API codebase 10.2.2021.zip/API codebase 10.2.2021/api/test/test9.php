<?php
require_once(__DIR__ . '/../vendor/autoload.php');

/*

http://james/api/test/test9.php

*/

use App\Models\EventRequest;


$r = EventRequest::find(1);


$q = $r->run;


print_r($q);


