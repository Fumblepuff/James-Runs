<?php
namespace Tests;

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client as GuzzleHttpClient;
use Psr\Http\Message\ResponseInterface;

class ApiBaseTest extends TestCase
{
    protected $client;

    public function setUp() :void
    {
        global $config;
        $this->client = new GuzzleHttpClient(['base_uri' => $config['tests']['base_uri']]);


        global $courts;

        if (!is_array($courts))
        {
            $courts = [];
        }
    }

    public function postJames(String $type, Array $params): Array
    {
        $body = $params;
        $body['type'] = $type;

        $response = $this->client->post('james.php', ['body' => json_encode($body)]);

        $bodyStr = (string) $response->getBody(); // cast it to string, otherwise it will be returned as stream

        $bodyData = json_decode($bodyStr, true);

        return [$response, $bodyStr, $bodyData];
    }

    public function postJamesData(String $type, Array $data): Array
    {
        return $this->postJames($type, ['data' => $data]);
    }


    public function tearDown() :void
    {
        $this->client = null;
    }
}
