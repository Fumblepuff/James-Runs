<?php
namespace Tests;

class CourtsTest extends ApiBaseTest
{

    public function test_addNewCourt()  // NYI
    {
        global $courts;

        $run1DateTime = convertUnixTimeToDateTimeUtc(time()+86400);


        $courtName = 'test-court-' . microtime(true) . '-' . mt_rand(0,1000000000);

        $data = 
        [
           'court' => 
               [
//                   'adminId' => '',

                   'name' => $courtName,

//                   'address' => '',

                   'latitude' => 33.76249637241594,
                   'longitude' => -84.57030450720536,


//                   'city' => '',
//                   'state' => '',
//                   'zipcode' => '',
//                   'imageType' => '',
//                   'imageName' => '',
//                   'placeId' => '',
//                   'active' => '',


                   'schedule' => 
                   [  
                       ['id' => $run1DateTime]  
                   ]
               ],

           'userId' => 2512,
        ];

        list($response, $bodyStr, $bodyData) = $this->postJamesData('addNewCourt', $data);


        $this->assertStringMatchesFormat('%d', $bodyStr);  // unsigned integer value


        $courts['courtOne'] = 
        [
           'id' => $bodyStr,
           'name' => $courtName,

           'timezone' => 'America/New_York',
           
           'runs' =>
           [
               ['runSchedule' => $run1DateTime, 'type' => 1]
           ]
        ];
    }



    public function test_searchCourts()  // NYI
    {
        global $courts;

        $run1DateTime = convertUnixTimeToDateTimeUtc(time()+86400);

        $whatToSearch = 'epi';

        $data = 
        [
           'search' => $whatToSearch,   // nyi - search for court that has been added by test
           'userId' => 2512,
        ];

        list($response, $bodyStr, $bodyData) = $this->postJamesData('searchCourts', $data);

        $this->assertIsArray($bodyData);

        $this->assertArrayHasKey(0, $bodyData);

        $this->assertArrayHasKey('id', $bodyData[0]);
        $this->assertArrayHasKey('name', $bodyData[0]);

        $this->assertStringContainsStringIgnoringCase($whatToSearch, $bodyData[0]['name']);


///        $courts['courtOne'] = 
///        [
///           'id' => $bodyStr,
///           'timezone' => 'America/New_York',
///           
///           'runs' =>
///           [
///               ['runSchedule' => $run1DateTime, 'type' => 1]
///           ]
///        ];

    }

}

