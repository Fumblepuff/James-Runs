<?php
namespace Tests;


class RunsTest extends ApiBaseTest
{
    public function test_addNewRun()
    {
        global $courts;

        $data = 
        [
           'court' => $courts['courtOne']['id'],
           'schedule' => [],
        ];

        list($response, $bodyStr, $bodyData) = $this->postJamesData('addNewRun', $data);

        $this->assertEquals(['success'=>'Success'], $bodyData);
    }

}

