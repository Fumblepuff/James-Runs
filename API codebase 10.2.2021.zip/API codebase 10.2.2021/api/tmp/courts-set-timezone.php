<?php
require_once(__DIR__ . '/../vendor/autoload.php');

//exit;

/*

http://james/api/tmp/courts-set-timezone.php
http://35.224.164.208/api/tmp/courts-set-timezone.php


///http://james/api/tmp/tmp-assign-timezone.php

///http://35.224.164.208/dev/tmp/tmp-assign-timezone.php

///http://35.224.164.208/staging/tmp/tmp-assign-timezone.php

*/

$db = my_app('db');

$rAll = $db->selectQuery('SELECT * FROM `courts` WHERE `timezone` IS NULL ORDER BY id');

foreach($rAll as $r)
{
    $courtId = $r['id'];

    $address = $r['address']; // => 875 Riverside Pkwy, Austell, GA 30168, USA

    $latitude = $r['latitude'];
    $longitude = $r['longitude'];

    echo "address: {$address} / latitude: {$latitude} / longitude: {$longitude}";
    echo '<br/>';



    $timeZone = resolveGeoCoordinatesToTimeZone($latitude, $longitude);

    print_r($timeZone);


//    if ($timeZone == 'Antarctica/South_Pole')
//    {
//        $timeZone = 'UTC';  // we must be able to idenify courts with problematic timezone
//    }

    $update = ['timezone' => $timeZone];

    $db->updateValues('courts', $update, ['id' => $courtId]);


    echo "\r\n\r\n";
    echo '<br/><br/><br/><br/><br/><br/>';
    echo "\r\n\r\n";

//exit;

}

echo "all done";

