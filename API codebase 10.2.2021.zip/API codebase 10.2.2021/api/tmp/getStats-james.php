function getStats($id){

    $db = my_app('db');

    $streak = $db->selectQuery('select * from user_streak where userId = '.$id);

    if($streak){

        $runs = $db->selectQuery('select runId from run_user where userId = '.$id);
        $totalGames = 0;

        foreach ($runs as $run) {
            $gameID = $run['runId'];

            $userGames = $db->selectQuery('select count(id) as cnt from run_game where runId = '.$gameID);
            $count = $userGames[0]['cnt'];

            $totalGames += $count;
        }

        $stats['totalGames'] = $totalGames;

        $wins = $streak[0]['wins'];
        $losses = $streak[0]['losses'];
        $streak = $streak[0]['streak'];
        $games = $wins + $losses;

        if($wins){
            $calc = $wins / $games;
            $winPercentage = $calc * 100;
        }else{
            $winPercentage = 0;
        }

        if($wins){

            $divideGames = $totalGames / $games;
            $gamePercentage = 100 / $divideGames;
            $jamesWinPercetage = round($winPercentage, 1);
            $jamesWins = 70 * $jamesWinPercetage;
            $jamesDepth = 30 * $gamePercentage;
            $jamesTotal = $jamesWins + $jamesDepth;

            $jamesRating = $jamesTotal / 100;

        }else{

            $jamesRating = 0;
        
        }

        $stats['gameCount'] = $games;
        $stats['wins'] = $wins;
        $stats['winPercentage'] = round($winPercentage, 0);
        $stats['losses'] = $losses;
        $stats['streak'] = $streak;
        $stats['jamesRating'] = round($jamesRating, 0);

        return $stats;

    }else{

        $stats['totalGames'] = 0;
        $stats['gameCount'] = 0;
        $stats['wins'] = 0;
        $stats['winPercentage'] = 0;
        $stats['losses'] = 0;
        $stats['streak'] = 0;
        $stats['jamesRating'] = 0;

        return $stats;
    }
    

}
