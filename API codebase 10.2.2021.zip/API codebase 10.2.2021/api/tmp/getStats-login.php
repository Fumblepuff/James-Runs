function getStats($id){

    $db = my_app('db');

    $streak = $db->selectQuery('select * from user_streak where userId = '.$id);

    if($streak){
        $wins = $streak[0]['wins'];
        $losses = $streak[0]['losses'];
        $streak = $streak[0]['streak'];
        $games = $wins + $losses;

        if($wins){
            $calc = $wins / $games;
            $winPercentage = $calc * 100;
        }else{
            $winPercentage = 0;
        }    

        $stats['gameCount'] = $games;
        $stats['wins'] = $wins;
        $stats['winPercentage'] = round($winPercentage, 1);
        $stats['losses'] = $losses;
        $stats['streak'] = $streak;

        return $stats;

    }else{

        $stats['gameCount'] = 0;
        $stats['wins'] = 0;
        $stats['winPercentage'] = 0;
        $stats['losses'] = 0;
        $stats['streak'] = 0;

        return $stats;
    }
    

}
