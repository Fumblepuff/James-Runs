<?php
require_once(__DIR__ . '/../vendor/autoload.php');

///exit;

/*

http://james/api/tmp/runs-set-runScheduled.php
http://35.224.164.208/api/tmp/runs-set-runScheduled.php


///http://35.224.164.208/dev/tmp/tmp-adjust-runScheduled.php

///http://35.224.164.208/staging/tmp/tmp-adjust-runScheduled.php

!!!run strictly once!!!   then disable

////ALTER TABLE `runs` ADD `__runSchedule__backup` DATETIME NULL DEFAULT NULL AFTER `runSchedule`;


*/

$db = my_app('db');

$sql = <<<SQL

SELECT 
    courts.id, 
    courts.timezone, 

    runs.id as runId, 
    runs.runSchedule, 

    runs.runEnd 

FROM 
    runs 

INNER JOIN 

    courts on runs.courtId = courts.id 

WHERE
    (runs.runScheduleUtc IS NULL)
    AND
    (courts.timezone IS NOT NULL)

SQL;

$rAll = $db->selectQuery($sql);

foreach($rAll as $r)
{
    $courtId = $r['id'];
    $runId = $r['runId'];

    $runSchedule = $r['runSchedule'];
    $timezone = $r['timezone'];


    $runScheduleNew = convertDateTimeToAnotherTimeZone($runSchedule, $timezone, 'UTC');


    $update = 
    [
        'runScheduleUtc' => $runScheduleNew,
    ];


    $db->updateValues('runs', $update, ['id' => $runId]);


//    echo "\r\n\r\n";
//    echo '<br/><br/><br/><br/><br/><br/>';
//    echo "\r\n\r\n";

//exit;

}

echo 'the end';

