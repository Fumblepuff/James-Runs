<?php
require_once(__DIR__ . '/vendor/autoload.php');

# From Dainius: 
# 
# used. Updates user data.
#

apiLogRequest();


use Aws\S3\S3Client;
use Aws\Exception\AwsException;
use Aws\S3\Exception\S3Exception;
//Please remember to set this up correctly

//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    returnResponseAsString('Request method must be POST!', 400);
    exit;
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';

 
//Receive the RAW post data.
$content = trim(file_get_contents("php://input"));

 
//Attempt to decode the incoming RAW post data from JSON.
$apiRequest = json_decode($content, true);
 
//If json_decode failed, the JSON is invalid.
if(!is_array($apiRequest)){
    returnResponseAsString('Received content contained invalid JSON!', 400);
    exit;
}

if($apiRequest['userUpdate']){

    $user = $apiRequest['userUpdate'];

    $db = my_app('db');

    $db->updateValue('users', 'image', $user['image'], $user['id']);
    $db->updateValue('users', 'imageName', $user['imageName'], $user['id']);
    $db->updateValue('users', 'imageLocal', $user['imageLocal'], $user['id']);

    $check = $db->selectQuery('select * from users where id = "'.$user['id'].'"');
    
    if($check){
        
        $values['profile'] = $check;

        returnResponseAsJson($values);


    }else{

        $values['profile'] = false;

        returnResponseAsJson($values);
    }

}


