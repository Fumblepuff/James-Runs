<?php
require_once(__DIR__ . '/../vendor/autoload.php');

use App\Models\File;
use App\Models\User;

define('IS_API', true);

apiLogRequest();


//print_r($_SERVER);


$uf = new UploadFile;
$uf->execute();



class UploadFile
{
    protected $uploadType = '';
    protected $loggedInUserId = null;
    protected $loggedInUser;

    protected $validationErrors = [];


    protected function validateUpload()
    {
//print_r($_FILES);
//exit;


        global $config;

        $this->uploadType = isset($_POST['uploadType']) ? $_POST['uploadType'] : null;
        $this->loggedInUserId = isset($_POST['loggedInUserId']) ? $_POST['loggedInUserId'] : null;

        // uploadType must be present and be one of existing upload types

        if (empty2($this->uploadType))
        {
            $this->addError('uploadType is required');
        }
        else
        {
            if (!isset($config['uploads']['types'][$this->uploadType]))
            {
                $this->addError("uploadType={$this->uploadType} doesn't exist");
            }
        }


        // loggedInUserId must be present and existing user and has permission to upload files

        if (empty2($this->loggedInUserId))
        {
            $this->addError('loggedInUserId is required');
        }

        $this->loggedInUser = User::find($this->loggedInUserId);

        if ($this->loggedInUser)
        {
            if (!$this->loggedInUser->canUploadFiles())
            {
                $this->addError('This loggedInUserId doesn\'t have permissions to upload files');
            }
        }
        else
        {
            $this->addError('loggedInUserId is not found in database');
        }


        // check that only a single file is uploaded
        if ( isset($_FILES['file']['name']) && is_array($_FILES['file']['name']) )
        {
            $this->addError('Only single file upload is allowed at a time');
        }

        if (isset($_FILES['file']))
        {
            if (($_FILES['file']['tmp_name'] !== null)  &&  ($_FILES['file']['size'] > 0)  &&  ($_FILES['file']['error'] == UPLOAD_ERR_OK))
            {
                // all ok
                // file was uploaded
            }
            elseif ($_FILES['file']['error'] == UPLOAD_ERR_INI_SIZE)
            {
                $this->addError('The uploaded file is too large');
            }
            else
            {
                $this->addError('No file was uploaded');
            }
        }
        else
        {
            $this->addError('No file was uploaded');
        }

//print_r($_FILES);


    }

    protected function addError($errorMsg, $paramName='', $httpStatus=400)
    {
        $this->validationErrors[] = ['errorMsg' => $errorMsg, 'paramName' => $paramName, 'httpStatus' => $httpStatus];
    }

    public function hasValidationErrors()
    {
        return (count($this->validationErrors) > 0);
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }


    public function execute()
    {
        $this->validateUpload();

        if ($this->hasValidationErrors())
        {
            $validationErrors = $this->getValidationErrors();

            _e($validationErrors[0]['errorMsg'], $validationErrors[0]['httpStatus']);
            return;
        }


        $f = File::createFromUpload($this->uploadType, $this->loggedInUserId);

        $result = 
        [
            'success' => 'Success',
            'file' => $f->toArray()
        ];

        returnResponseAsJson($result);
    }
}

