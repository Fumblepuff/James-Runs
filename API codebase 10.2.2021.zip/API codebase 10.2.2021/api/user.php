<?php
require_once(__DIR__ . '/vendor/autoload.php');

# From Dainius: 
# 
# used. Gets user game stats
#

apiLogRequest();


//Please remember to set this up correctly

//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    returnResponseAsString('Request method must be POST!', 400);
    exit;
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';

 
//Receive the RAW post data.
$content = trim(file_get_contents("php://input"));


//Attempt to decode the incoming RAW post data from JSON.
$apiRequest = json_decode($content, true);

 
//If json_decode failed, the JSON is invalid.
if(!is_array($apiRequest)){
    returnResponseAsString('Received content contained invalid JSON!', 400);
    exit;
} 

if($apiRequest['data'])
{
    $user = $apiRequest['data'];

    $db = my_app('db');

    $check = $db->selectQuery('select * from users where id = "'.$user['id'].'"');
    
    if ($check)
    {
        $id = $check[0]['id'];

///        $getSquad = $db->selectQuery('select squadId from squad_user where userId = '.$check[0]['id']);

        $getDetail = $db->selectQuery('select * from user_detail where userId = '.$id);

///        foreach ($getSquad as $squad) {
///            $find = $db->selectQuery('select * from squads where id = '.$squad['squadId']);
///            
///            $court = $db->selectQuery('select * from courts where id = '.$find[0]['courtId']);
///            $ballers = $db->selectQuery('select * from users, squad_user where users.id = squad_user.userId and squad_user.squadId = '.$squad['squadId']);
///            $schedule = $db->selectQuery('select id, runScheduleUtc, runEnd  from runs where squadId = '.$squad['squadId']);
///
///            $listSquads['id'] = $find[0]['id'];
///            $listSquads['name'] = $find[0]['name'];
///            $listSquads['city'] = $find[0]['city'];
///            $listSquads['state'] = $find[0]['state'];
///            $listSquads['zipcode'] = $find[0]['zipcode'];
///            $listSquads['court'] = $court;
///            $listSquads['ballers'] = $ballers;
///            $listSquads['schedule'] = $schedule;
///
///            $squads[] = $listSquads;
///        }
        
        $values['profile'] = $check[0];
        $values['detail'] = $detail[0];

        $values['squads'] = []; // $squads;  maybe the mobile application expects this value

        $values['stats'] = getUserStats($id);

        returnResponseAsJson($values);

    }

}


