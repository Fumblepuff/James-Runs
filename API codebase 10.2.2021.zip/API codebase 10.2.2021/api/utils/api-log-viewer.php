<?php

if (!preg_match('/^\/dev\//i',$_SERVER['REQUEST_URI']))
{
    exit;
}

require_once(__DIR__ . '/../vendor/autoload.php');

$params = [];

$params['env']     = $_GET['env']     ?? 'dev';

$params['ip']      = $_GET['ip']      ?? '';
$params['firstId'] = $_GET['firstId'] ?? '';
$params['lastId']  = $_GET['lastId']  ?? '';
$params['requestUri'] = $_GET['requestUri']  ?? '';
$params['type']    = $_GET['type']    ?? '';


if (!in_array($params['env'], ['local', 'dev', 'prod']))
{
    echo 'Invalid value for parameter env';
    exit;
}

if ($params['env'] != $config['env'])
{
    require_once(__DIR__ . "/../config/config.{$params['env']}.php");
}

global $config;

try
{
    $host     = $config['db_host'];
    $database = $config['db_database'];
    $user     = $config['db_user'];
    $pass     = $config['db_pass'];

    $db = new \PDO("mysql:host=$host;dbname=$database", $user, $pass);
}
catch (PDOException $e)
{
    echo 'Connection failed: ' . $e->getMessage();
}


$where = [];

if (isset($_GET['ip']) && ($_GET['ip'] != ''))
{
    $where[] = " (remote_addr LIKE " . $db->quote($_GET['ip']) . ") ";
}

if (isset($_GET['firstId']) && ($_GET['firstId'] != ''))
{
    $where[] = " (id >= " . $db->quote($_GET['firstId']) . ") ";
}

if (isset($_GET['lastId']) && ($_GET['lastId'] != ''))
{
    $where[] = " (id <= " . $db->quote($_GET['lastId']) . ") ";
}


if (isset($_GET['requestUri']) && ($_GET['requestUri'] != ''))
{
    $where[] = " (request_uri LIKE " . $db->quote('%'.$_GET['requestUri'].'%') . ") ";
}


if (isset($_GET['type']) && ($_GET['type'] != ''))
{
    $where[] = " (type LIKE " . $db->quote($_GET['type']) . ") ";
}

// instead of alert - use toastr

// large output - truncate and open full in new window
// if output is an array and has [0] element and the whole array is lengthy then truncate it
// if output is an array and is not a list of items but an associative array - then the limit before we truncate it can be bigger
// we can count not just the number of characters but - better count lines of text in the output of print_r() command


// NYI also search by requestUri, response_http_code, type
// !and! inside request_content, message, response_content
// and return 50 records before and 50 records after a given id, to see what happened 
// at around that request




if (count($where) > 0)
{
    $where = ' WHERE ' . implode($where, ' AND ');
}
else
{
    $where = '';
}

$sql = "SELECT * FROM (SELECT * FROM `api_log` {$where} ORDER BY `id` DESC LIMIT 100) sq ORDER BY `id` ASC";

///echo $sql;

$query = $db->prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

$query->execute([
//    ':st'           => $st,
]);

?>

<html>
<head>

    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/copyTextToClipboard.js"></script>

</head>

<body>

<style>

table.data-table td {
    padding: 3px;
    vertical-align: top;
    /*border: 1px solid #0000EE;*/
}

table.data-table .td-class-1 {
    background-color: #F6EAEA;
}

table.data-table .td-class-2 {
    background-color: #E9F9E7;
}

</style>

<form method="GET" target="_blank">

Env: <input type="text" name="env" value="<?php echo htmlspecialchars($params['env']) ?>" style="width: 50px;"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
IP: <input type="text" name="ip" value="<?php echo htmlspecialchars($params['ip']) ?>" style="width: 150px;"/>
<a href="#" onclick="setIp('<?php echo htmlspecialchars($config['dev_ip']) ?>');">devIP</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
firstId: <input type="text" name="firstId" value="<?php echo htmlspecialchars($params['firstId']) ?>" style="width: 70px;"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
lastId: <input type="text" name="lastId" value="<?php echo htmlspecialchars($params['lastId']) ?>" style="width: 70px;"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
requestUri: <input type="text" name="requestUri" value="<?php echo htmlspecialchars($params['requestUri']) ?>" style="width: 150px;"/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
type: <input type="text" name="type" value="<?php echo htmlspecialchars($params['type']) ?>" style="width: 150px;"/>

<input type="submit" >
</form>

<table class="data-table">


<tr>

<td>id</td>
<td>datetime</td>
<td>remote_addr</td>
<td>request_method</td>
<td>request_uri</td>
<td>request_content</td>
<td>type</td>
<td>message</td>
<td>http_code</td>
<td>response</td>

</tr>



<?php

$recCounter = 0;

while ($row = $query->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT))
{
    $recCounter++;

    switch($recCounter % 2)
    {
        case 0: $tdClass = 'td-class-1'; break;
        case 1: $tdClass = 'td-class-2'; break;
    }

    echo "<tr id=\"rowId{$row['id']}\">";

    echo "<td class=\"{$tdClass}\"><pre>{$row['id']}
<a href=\"#\" onclick=\"setFirstId({$row['id']}); return false;\">first</a>
<a href=\"#\" onclick=\"setMiddleId({$row['id']}); return false;\">middle</a>
<a href=\"#\" onclick=\"setLastId({$row['id']}); return false;\">last</a>

<a href=\"api-log-viewer.php?firstId={$row['id']}&lastId={$row['id']}\" target=\"_blank\">&gt;&gt;</a>
</pre></td>";

    $dt = new \DateTime();
    $dt->setTimestamp($row['unixtime']);

    $dt->setTimezone(new \DateTimeZone('UTC'));
    $datetime_utc = $dt->format('Y-m-d H:i:s') . ' UTC';

    $dt->setTimezone(new \DateTimeZone('Europe/Kiev'));
    $datetime_ua = $dt->format('Y-m-d H:i:s') . ' Europe/Kiev';

    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\"><pre>{$datetime_utc}<br/>{$datetime_ua}<br/>{$row['unixtime']} unixtime</pre></td>";


    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\"><pre>{$row['remote_addr']}</pre></td>";
    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\"><pre>{$row['request_method']}</pre></td>";
    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\"><pre>{$row['request_uri']}</pre></td>";



    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\">";
    printContent($row['request_content'], $row['id'], 'request-content');
    echo "</td>";

//    echo "<td class=\"{$tdClass} request-content\">" . htmlspecialchars($row['request_content']) . "</td>";


    echo "<td class=\"{$tdClass} type\" title=\"id = {$row['id']}\"><pre><a href=\"#\" onclick=\"setType({$row['id']}); return false;\">" . (($row['type']===null) ? "<u>NULL</u>" : $row['type']) . "</a></pre></td>";


    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\"><pre>{$row['message']}</pre></td>";

    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\"><pre>" . (($row['response_http_code']===null) ? "<u>NULL</u>" : $row['response_http_code']) . "</pre></td>";


    echo "<td class=\"{$tdClass}\" title=\"id = {$row['id']}\">";
    printContent($row['response_content'], $row['id']);
    echo "</td>";



    echo "</tr>";
}
?>
</table>




<?php

function printContent($s, $id, $contentClass='')
{
    $linkBegin = "";
    $linkEnd = "";
    $content = "";

    if ($contentClass != '')
    {
        $content = "<span class=\"{$contentClass}\" style=\"display:none;\">" . htmlspecialchars($s) . "</span>";

        $linkBegin = "<a href=\"#\" onclick=\"copyContentToClipboard({$id}, 'td span.{$contentClass}'); return false;\">";
        $linkEnd = "</a>";
    }

    echo "<pre>";

    if ($s === null)
    {
        echo "<u>not JSON:</u> NULL value";
    }
    else
    {
        $s_json = json_decode($s, true);

        if ($s_json === null)
        {
            echo "<u>{$linkBegin}not JSON:{$linkEnd}</u><br/>" . $s;
        }
        else
        {
            echo "<u>{$linkBegin}JSON:{$linkEnd}</u><br/>";
            $q = print_r($s_json, true);
            echo $q;
        }
    }

    echo "</pre>";

    echo $content;
}

?>

<script>

function setFirstId(id)
{
    $("input[name=firstId]").val(id);
    alert("firstId = " + id);
}

function setMiddleId(id)
{
    $("input[name=firstId]").val(id-50);
    $("input[name=lastId]").val(id+50);

    alert("middleId = " + id);
}

function setLastId(id)
{
    $("input[name=lastId]").val(id);
    alert("lastId = " + id);
}

function setType(id)
{
    var t = $("#rowId"+id+" td.type").text();

    $("input[name=type]").val(t);
    alert("type = " + t);
}

function setIp(ip)
{
    $("input[name=ip]").val(ip);
    alert("ip = " + ip);
}


function copyContentToClipboard(id, contentSelector)
{
    var t = $("#rowId"+id+" "+contentSelector).text();

    copyTextToClipboard(t);

    alert('Copied to clipboard');
}


</script>

</body>
</html>
